/*
File Name:- wellService.js
Summary:- This files works as a config file for spatial data, layers and services.
*/
angular.module('TGSApp').service('WellService', function (Common) {
    this.communicateValue = '';
    this.pdfFilterStr = "&pdfFilterStr=";
    this.urlValue = Common.urlValue;
    this.allWellInfoService = 'getWellInfoFilterService';
    this.allWellMapService = 'getWellMapInfo';
    this.homeUrl = 'getWellInfoFilterService';

    this.wellLastaburl = "getDetailInfo";
    this.wellProductiontaburl = "getDetailInfo?tabName=Production&module=Well&pageNumber=0&pageSize=20";
    this.wellRastertaburl = "getDetailInfo?tabName=Raster&module=Well&pageNumber=0&pageSize=20";
    this.wellVWHtaburl = "getDetailInfo?tabName=VWH&module=Well&pageNumber=0&pageSize=20";
    this.wellWFtaburl = "getDetailInfo?tabName=WellFile&module=Well&pageNumber=0&pageSize=20";

    this.allWellFilter = '';
    this.wellQueryBuilder = '';
    this.allWellSelectedFields = 'UWI,WellID,Wellname,StateName,CompletionDate,CountyName,Township,Range,SurfArea,SurfaceLatitudeWGS84,SurfaceLongitudeWGS84';
    this.allGeographyData = 'getWellMetaDataGeographyFilters';
    this.allWellDetails = 'getWellMetaDetailFilters';
    this.uuid = "&uuid=";
    this.EntitlementWellurl = "getEntitlementDetails";
    this.wellCacheLayerId = "WellLocationCacheService";
    this.seismicCacheLayerId = "CachedSeismicService";
    this.wellMetadataLayerId = "WellMetadata";
    this.seismicMetadataLayerId = "SeismicFilterService";
    this.seismicHighlightLayerId = "SeismicHighlightService";
    this.seismicSelectionLayerId = "SeismicSelectionService";
    this.wellSymbolImage = "iVBORw0KGgoAAAANSUhEUgAAAAYAAAAGCAYAAADgzO9IAAAAAXNSR0IB2cksfwAAAAlwSFlzAAAOxAAADsQBlSsOGwAAAGlJREFUCJlNzLENglAARdGj/gITevcwFtJARckIJg5g7B2BAZyAxi0MCzCBY1gQE4TiK+F2Lyd5AVT1ztbd6ICnd38NINEYlWJnaSL8RmHZSv6HDscZBl2EzfdkWDfYo/VxifC4vZAt3ybPXxMxz1zbRgAAAABJRU5ErkJggg==";
    this.wellMapServiceBaseUrl = "https://gisprod01.tgsr360.com/arcgis/rest/services/";
    this.wellExtentService = this.wellMapServiceBaseUrl + "DataLake/WellsMetadataExt/MapServer/0";        
    this.projectShapeServiceUrl = "https://r360gisdev01.tgsr360.com/arcgis-proxy/entitlement/"; // DEV URL
    //this.projectShapeServiceUrl = "https://gisprod01.tgsr360.com/datalake/entitlement/"; // PROD URL
    this.surveyUrl = "https://map.tgs.com/arcgis/rest/services/web/selection/MapServer/";
    this.wellRenderer = {
        type: "simple",
        symbol: {
            type: "esriSMS",
            style: "esriSMSCircle",
            color: [0, 46, 161, 255],
            size: "4",
            outline: {
                color: [255, 255, 0, 0],
                width: 0,
                type: "esriSLS",
                style: "esriSLSSolid"
            }
        }
    };
    this.getSubLayer = function (query) {
        return {
            id: 0,
            definitionExpression: "",
            renderer: this.wellRenderer,
            source: {
                type: "dataLayer",
                dataSource: {
                    type: "queryTable",
                    workspaceId: "DynamicWorkspace",
                    query: "SELECT * FROM sde." + query,
                    spatialReference: { wkid: 4326 },
                    geometryType: "point",
                    oidFields: "OBJECTID"
                }
            }
        };
    };
    // Generic symbology for line
    this.getSimpleLineSymbolJson = function (outlineColor, outlineWidth) {
        return {
            type: "esriSLS",
            style: "esriSLSSolid",
            color: outlineColor,
            width: outlineWidth
        };
    };
    // Generic symbology for polygon
    this.getSimpleFillSymbolJson = function (fillColor, outlineColor, outlineWidth) {
        return {
            type: "esriSFS",
            color: fillColor,
            style: "esriSFSSolid",
            outline: this.getSimpleLineSymbolJson(outlineColor, outlineWidth)
        };
    };
    // Generic symbology for Text
    this.getTextSymbolJson = function (textColor, haloSize, haloColor, fontSize) {
        return {
            "type": "esriTS",
            "color": textColor,
            "haloSize": haloSize,
            "haloColor": haloColor,
            "verticalAlignment": "bottom",
            "horizontalAlignment": "left",
            "rightToLeft": false,
            "angle": 0,
            "xoffset": 0,
            "yoffset": 0,
            "kerning": true,
            "font": {
                "family": "Verdana",
                "size": fontSize,
                "style": "normal",
                "weight": "bold",
                "decoration": "none"
            }
        };
    };

    // Proxy settings for map service urls
    this.mapServicesProxyDetails = [{
        urls: [
            this.wellMapServiceBaseUrl + "R360Standard",
            this.wellMapServiceBaseUrl + "DataLake",
            "https://r360gisdev01.tgsr360.com/arcgis/rest/services/Private_TGS/TGS_DataCatalog_and_DataLicense_NoGrouping/MapServer"      
        ],
        proxyUrl: "https://r360gisdev01.tgsr360.com/arcgis-proxy/proxy.ashx"
    },
    {
        urls: [
            "https://map.tgs.com/arcgis/rest/services"
        ],
        proxyUrl: "https://gisprod01.tgsr360.com/arcgis-proxy/proxy.ashx"
    }
    ];

    // Map services and its definitions being used in application
    this.mapServiceDetails = {
        "WellLocationCacheService": {
            url: this.wellMapServiceBaseUrl + "R360Standard/WellLocationCacheMultiLayer/MapServer",
            index: 1,
            opacity: 0.9,
            type: "TileLayer",
            visible: true
        },
        "CachedSeismicService": {
            url: "https://map.tgs.com/arcgis/rest/services/web/Map_NoWells/MapServer",
            index: 0,
            type: "TileLayer",
            opacity: 0.9,
            visible: true
        }
    };
    this.filterMapServiceDetails = {
        "WellMetadata": [{
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P1/MapServer",
            index: 4,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P01")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P2/MapServer",
            index: 5,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P02")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P3/MapServer",
            index: 6,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P03")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P4/MapServer",
            index: 7,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P04")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P5/MapServer",
            index: 8,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P05")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P6/MapServer",
            index: 9,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P06")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P7/MapServer",
            index: 10,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P07")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P8/MapServer",
            index: 11,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P08")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P9/MapServer",
            index: 12,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P09")]
        }, {
            url: this.wellMapServiceBaseUrl + "DataLake/WellsMetaData_P10/MapServer",
            index: 13,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0],
            sublayers: [this.getSubLayer("DL_WELL_METADATA_P10")]
        }],
        "SeismicFilterService": [{
            url: "https://map.tgs.com/arcgis/rest/services/web/selection/MapServer",
            index: 2,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0, 1],
            sublayers: [
                {
                    id: 0,
                    definitionExpression: "1!=1"
                },
                {
                    id: 1,
                    definitionExpression: "1!=1"
                }
            ]
        }],
        "SeismicSelectionService": [{
            url: "https://map.tgs.com/arcgis/rest/services/web/selection/MapServer",
            index: 3,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0, 1, 2, 3, 4, 5],
            sublayers: [
                {
                    id: 0,
                    definitionExpression: "SurveyStatus IN ('In Progress','Planned') AND ShowOnMap = 1 AND  NOT(SurveyID in ('01058','00270','00788')) AND SurveyTypeCat = '3D' AND ProjectSubTypes <> 'Aero Gravity and Magnetics' AND ProjectSubTypes <> 'Interpretation and Reports'",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleFillSymbolJson([255, 255, 255, 0], [34, 197, 95, 255], 3)
                    },
                    source: {
                        type: "mapLayer",
                        mapLayerId: 1
                    }
                }, {
                    id: 1,
                    definitionExpression: "SurveyStatus <> 'Retired' AND ShowOnMap = 1 AND  NOT(SurveyID in ('01058','00270','00788')) AND SurveyTypeCat = '3D' AND ProjectSubTypes LIKE '%3D Seismic%' AND ProjectSubTypes <> 'Aero Gravity and Magnetics' AND ProjectSubTypes <> 'Interpretation and Reports'",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleFillSymbolJson([255, 103, 4, 255], [168, 0, 0, 255], 1.5)
                    },
                    source: {
                        type: "mapLayer",
                        mapLayerId: 1
                    }
                }, {
                    id: 2,
                    definitionExpression: "SurveyStatus <> 'Retired' AND ShowOnMap = 1 AND  NOT(SurveyID in ('01058','00270','00788')) AND SurveyTypeCat = '3D' AND ProjectSubTypes LIKE '%3D Seismic%' AND ProjectSubTypes <> 'Aero Gravity and Magnetics' AND ProjectSubTypes <> 'Interpretation and Reports'",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleFillSymbolJson([255, 103, 4, 255], [168, 0, 0, 255], 1.5)
                    },
                    labelingInfo: [{
                        labelExpression: "[SurveyName]",
                        labelPlacement: "always-horizontal",
                        verticalAlignment: "bottom",
                        horizontalAlignment: "left",
                        angle: 0,
                        symbol: this.getTextSymbolJson([255, 255, 255, 0.85], 1, "gray", 9),
                        minScale: 53957190.948944
                    }],
                    source: {
                        type: "mapLayer",
                        mapLayerId: 1
                    }
                }, {
                    id: 3,
                    definitionExpression: "SurveyStatus <> 'Retired' AND NOT(SurveyID in ('01058','00270','00788')) AND ShowOnMap = 1 AND SurveyTypeCat = '3D' AND ProjectSubTypes = 'Multibeam and Electromag'",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleFillSymbolJson([255, 103, 4, 255], [85, 201, 235, 0], 0)
                    },
                    labelingInfo: [{
                        labelExpression: "[SurveyName]",
                        labelPlacement: "always-horizontal",
                        verticalAlignment: "bottom",
                        horizontalAlignment: "left",
                        angle: 0,
                        symbol: this.getTextSymbolJson([255, 255, 255, 0.85], 1, "gray", 9),
                        minScale: 53957190.948944
                    }],
                    source: {
                        type: "mapLayer",
                        mapLayerId: 1
                    }
                }, {
                    id: 4,
                    definitionExpression: "SurveyStatus  IN ('In Progress','Planned') AND ShowOnMap = 1 AND SurveyTypeCat = '2D' AND ProjectSubTypes <> 'Aero Gravity and Magnetics' AND ProjectSubTypes <> 'Interpretation and Reports'",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleLineSymbolJson([34, 197, 95, 255], 1.5)
                    },
                    source: {
                        type: "mapLayer",
                        mapLayerId: 0
                    }
                }, {
                    id: 5,
                    definitionExpression: "SurveyStatus = 'Completed' AND ShowOnMap = 1 AND SurveyTypeCat = '2D' AND ProjectSubTypes <> 'Aero Gravity and Magnetics' AND ProjectSubTypes <> 'Interpretation and Reports'",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleLineSymbolJson([102, 102, 102, 255], 0.6)
                    },
                    source: {
                        type: "mapLayer",
                        mapLayerId: 0
                    }
                }
            ]
        }],
        "SeismicHighlightService": [{
            url: "https://map.tgs.com/arcgis/rest/services/web/selection/MapServer",
            index: 14,
            type: "MapImageLayer",
            visible: false,
            visibleSubLayers: [0, 1],
            sublayers: [
                {
                    id: 0,
                    definitionExpression: "",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleLineSymbolJson([255, 194, 1, 255], 1)
                    },
                    labelingInfo: [{
                        labelExpression: "[SurveyName]",
                        labelPlacement: "always-horizontal",
                        verticalAlignment: "bottom",
                        horizontalAlignment: "left",
                        angle: 0,
                        symbol: this.getTextSymbolJson([255, 255, 255, 0.85], 1, "gray", 9),
                        minScale: 53957190.948944
                    }]
                }, {
                    id: 1,
                    definitionExpression: "",
                    renderer: {
                        type: "simple",  // autocasts as new SimpleRenderer()
                        symbol: this.getSimpleFillSymbolJson([255, 194, 1, 255], [100, 75, 0, 255], 1)
                    },
                    labelingInfo: [{
                        labelExpression: "[SurveyName]",
                        labelPlacement: "always-horizontal",
                        verticalAlignment: "bottom",
                        horizontalAlignment: "left",
                        angle: 0,
                        symbol: this.getTextSymbolJson([255, 255, 255, 0.85], 1, "gray", 9),
                        minScale: 53957190.948944
                    }]
                }
            ]
        }]
    };
    this.definitionExpression = "1!=1";
    this.WellMetadataFields = {
        "WellID": "Number",
        "UWI": "String",
        "CountryName": "String",
        "StateName": "String",
        "CountyName": "String",
        "Wellname": "String",
        "WellnbrTxt": "String",
        "Operator": "String",
        "GeoSection": "Number",
        "Township": "Number",
        "Range": "Number",
        "SurfArea": "String",
        "SurfBlock": "String",
        "BotmArea": "String",
        "BotmBlock": "String",
        "SurfaceLatitudeWGS84": "Number",
        "SurfaceLongitudeWGS84": "Number",
        "SpudDate": "Date",
        "TDdate": "Date",
        "CompletionDate": "Date"
    };
});

