angular.module('TGSApp').service('Common', function ($rootScope, __env) {

    this.urlValue = __env.apiUrl;
    this.getDetailInfo = "getDetailInfo"
    this.getMapDetailInfo = "getMapDetailInfo" // Map Detail info
    this.getMapCentroidForCountry = "getMapCentroidForCountry"  // Map Centroid 
    this.getDetailInfoForSwitch = "getDetailInfoForSwitch" //Switch 
    this.getWellDetailInfoCsvDownload = "getWellDetailInfoCsvDownload"  // CSV download Url

    this.getquerybuilderfilter = function (tmArr) {
        var queryBuilderStr = "";
        for (var i = 0; i < tmArr.length; i++) {
            var value = tmArr[i];
            var fieldValue = "";
            var arr = value.split(":");
            if (arr[0] == "LocationOrg")
                fieldValue = arr[2] + ":" + arr[3];
            else if (arr[0] == "LASTriple" || arr[0] == "LASQuad") {
                fieldValue = arr[2] == "1" ? "true" : "false";
            }
            else if (arr[0] == "ProductType" && arr.length > 3)
                fieldValue = arr[2] + ":" + arr[3];
            else
                fieldValue = arr[2];

            var finalValue = "";
            if (fieldValue.indexOf(" to ") >= 0 && arr[1] == 'btw') {
                var tempArr = fieldValue.split(" to ");
                if (this.isValidDate(tempArr[0]) && this.isValidDate(tempArr[1])) {
                    finalValue = tempArr[0] + " 00:00:00.0" + "<<" + tempArr[1] + " 00:00:00.0";
                }
                else{
                    finalValue = tempArr[0] + "<<" + tempArr[1];
                }
            }
            else if (fieldValue.indexOf("-") >= 0) {
                var tempArr = fieldValue.split("-");
                if (tempArr.length == 3 && this.isValidDate(arr[2])) {
                    finalValue = fieldValue + " 00:00:00.0";
                }
                else {
                    finalValue = fieldValue;
                }
            }
            else {
                finalValue = fieldValue;
            }
            //var fieldVal = finalValue.includes("&")? finalValue.replace("&", "%26"):finalValue; 
            if (arr[0] == "BottomLatLong") {
                var fieldVal = finalValue;
            }
            else {
                var fieldVal = finalValue.includes(",") ? finalValue.split(',').join("~~") : finalValue;
            }
            var fieldVal1 = fieldVal;
            finalValue = arr[0] + ":" + arr[1] + ":" + fieldVal1;
            if (i == 0) {
                queryBuilderStr = finalValue;
            }
            else {
                queryBuilderStr = queryBuilderStr + " AND " + finalValue;
            }
        }
        return queryBuilderStr;
    }

    this.isValidDate = function (dateString) {
        var regEx = /^\d{4}-\d{2}-\d{2}$/;
        return dateString.match(regEx) != null;
    }

    //Detail Poligon
    this.getGeoSpatialFilter = function (allSurveyFilter) {
        var geoSpatialFilter = "";

        if (allSurveyFilter != "") {
            geoSpatialFilter = " AND ProjectGeoShape:" + window.geocoorinates;
        }
        else {
            geoSpatialFilter = "ProjectGeoShape:" + window.geocoorinates;
        }
        //geoSpatialFilter = encodeURI(geoSpatialFilter);
        return geoSpatialFilter;
    };

    this.getTraceGeoSpatialFilter = function () {
        var geoSpatialFilter = "LatLongGeoShape:" + window.geocoorinates;
        return (geoSpatialFilter);
    }

    this.getLatLongGeoShapeFilter = function () {
        var segyLatLongShapeFilter = " AND LatLongGeoShape:" + window.geocoorinates;
        // var segyLatLongShapeFilter = " AND LatLong:" + window.geocoorinates.substring(0, window.geocoorinates.lastIndexOf("[")-1) + "]]";
        // return(encodeURI(segyLatLongShapeFilter));
        return (segyLatLongShapeFilter);
    }
    this.getSurveyGeoShape = function (allSurveyFilter, isSurveySummary) {
        var geoSpatialFilter = "";
        if (isSurveySummary) {
            geoSpatialFilter = " AND SurveyGeoShape:" + window.geocoorinates;
        }
        else if (allSurveyFilter != "") {
            geoSpatialFilter = " AND SurveyGeoShape:" + window.geocoorinates;
        }
        else {
            geoSpatialFilter = "SurveyGeoShape:" + window.geocoorinates;

        }       

        return geoSpatialFilter;
    }
    //Well Details
    this.getWellgeoSpatialFilter = function (filterString) {
        if (filterString != "") {
            geoSpatialFilter = " AND LatLongGeoShape:" + window.geocoorinates;

        }
        else {
            geoSpatialFilter = "LatLongGeoShape:" + window.geocoorinates;
        }
        // geoSpatialFilter = encodeURI(geoSpatialFilter);
        return geoSpatialFilter;
    }

    this.getSegySelectedFields = function () {
        var selectedSegyFieldsurl = "";
        if ($rootScope.segySelected !== undefined && $rootScope.segySelected !== "")
            selectedSegyFieldsurl = $rootScope.segySelected;

        return selectedSegyFieldsurl;
    }
    this.getHorizonSelectedFields = function () {
        var selectedHorizonFieldsurl = "";
        if ($rootScope.horizonSelected !== undefined && $rootScope.horizonSelected !== "")
            selectedHorizonFieldsurl = $rootScope.horizonSelected;

        return selectedHorizonFieldsurl;
    }

    this.getVelocitySelectedFields = function () {
        var selectedVelocityFieldsurl = "";
        if ($rootScope.velocitySelected !== undefined && $rootScope.velocitySelected !== "")
            selectedVelocityFieldsurl = $rootScope.velocitySelected;

        return selectedVelocityFieldsurl;
    }

    this.getSpecSheetSelectedFields = function () {
        var selectedSpecFieldsurl = "";
        if ($rootScope.specSheetSelected !== undefined && $rootScope.specSheetSelected !== "")
            selectedSpecFieldsurl = $rootScope.specSheetSelected;
        return selectedSpecFieldsurl;
    }

    this.getAeroMagSelectedFields = function () {
        var selectedAeroMagFieldsurl = "";
        if ($rootScope.aeroMagSelected !== undefined && $rootScope.aeroMagSelected !== "")
            selectedAeroMagFieldsurl = $rootScope.aeroMagSelected;
        return selectedAeroMagFieldsurl;
    }

    this.getGravMagSelectedFields = function () {
        var selectedGravMagFieldsurl = "";
        if ($rootScope.gravMagSelected !== undefined && $rootScope.gravMagSelected !== "")
            selectedGravMagFieldsurl = $rootScope.gravMagSelected;
        return selectedGravMagFieldsurl;
    }

    this.getWellFileSelectedFields = function () {
        var selectedWellFileFieldsurl = "";
        if ($rootScope.wellFileSelected !== undefined && $rootScope.wellFileSelected !== "")
            selectedWellFileFieldsurl = $rootScope.wellFileSelected;
        return selectedWellFileFieldsurl;
    }

    this.getUuid = function () {
        var uuid = "";
        if ($rootScope.isSeismicClicked) {
            if ($rootScope.uuid !== undefined && $rootScope.uuid !== "")
                uuid = $rootScope.welluuid;
        }
        else {
            if ($rootScope.filterNameGroup !== "interpretive") {
                if ($rootScope.uuid !== undefined && $rootScope.uuid !== "") {
                    uuid = $rootScope.uuid;
                }
            }
            else {
                $rootScope.uuid = undefined;
            }
        }
        return uuid;
    }

    this.getSurveyEntitlementUrl = function () {
        var surveyEntitlementUrl = "";
        if ($rootScope.isExternalUser) {
            surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
        }
        return surveyEntitlementUrl;
    }
    this.getAdminEntitlementUrl = function () {
        var surveyEntitlementUrl = "";
        if ($rootScope.surveyCustomer !== undefined && $rootScope.surveyCustomer !== "") {
            surveyEntitlementUrl = $rootScope.surveyCustomer.customerId;
        }
        return surveyEntitlementUrl;

    }

    this.getSurveyHorizonEntitlementUrl = function () {
        var surveyEntitlementUrl = "";
        var surveyTypeFilterExist = false;

        if ($rootScope.surveyselectedValArr !== undefined && $rootScope.surveyselectedValArr.length > 0) {
            for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                var QBObj = $rootScope.surveyselectedValArr[i].value;
                for (var j = 0; j < QBObj.length; j++) {
                    if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                        || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                        surveyTypeFilterExist = true;
                        $rootScope.filterSurveyType = QBObj[j].substring(QBObj[j].length - 2);
                        break;
                    }
                }
            }
        }

        if ($rootScope.surveyselectedFieldsDetails !== undefined && $rootScope.surveyselectedFieldsDetails.length > 0) {
            for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType") {
                    surveyTypeFilterExist = true;
                    $rootScope.filterSurveyType = $rootScope.surveyselectedFieldsDetails[i].fieldValue;
                    break;
                }
            }
        }
        if (surveyTypeFilterExist) {
            surveyEntitlementUrl = this.getSurveyEntitlementUrl();
        }
        else {
            if ($rootScope.isExternalUser) {
                if ($rootScope.horizonsurveyType == "2D" || $rootScope.horizonsurveyType == undefined || $rootScope.horizonsurveyType == "") {
                    surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    $rootScope.horizonsurveyType = "2D"
                }
                else {
                    surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    $rootScope.horizonsurveyType = "3D"
                }
            }
            $rootScope.filterSurveyType = "";
        }
        return surveyEntitlementUrl;
    }
    this.getAdminHorizonEntUrl = function () {
        var surveyEntitlementUrl = "";
        if ($rootScope.surveyCustomer !== undefined && $rootScope.surveyCustomer !== "") {
            surveyEntitlementUrl = $rootScope.surveyCustomer.customerId;
        }
        return surveyEntitlementUrl;
    }

    this.getSurveyAeroMagEntitlementUrl = function () {
        var surveyEntitlementUrl = "";
        var surveyTypeFilterExist = false;

        if ($rootScope.surveyselectedValArr !== undefined && $rootScope.surveyselectedValArr.length > 0) {
            for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                var QBObj = $rootScope.surveyselectedValArr[i].value;
                for (var j = 0; j < QBObj.length; j++) {
                    if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                        || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                        surveyTypeFilterExist = true;
                        $rootScope.filterSurveyType = QBObj[j].substring(QBObj[j].length - 2);
                        break;
                    }
                }
            }
        }

        if ($rootScope.surveyselectedFieldsDetails !== undefined && $rootScope.surveyselectedFieldsDetails.length > 0) {
            for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType") {
                    surveyTypeFilterExist = true;
                    $rootScope.filterSurveyType = $rootScope.surveyselectedFieldsDetails[i].fieldValue;
                    break;
                }
            }
        }
        if (surveyTypeFilterExist) {
            surveyEntitlementUrl = this.getSurveyEntitlementUrl();
        }
        else {
            if ($rootScope.isExternalUser) {
                if ($rootScope.AeroMagSurveyType == "2D" || $rootScope.AeroMagSurveyType == undefined || $rootScope.AeroMagSurveyType == "") {
                    surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    $rootScope.AeroMagSurveyType = "2D"
                }
                else {
                    surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    $rootScope.AeroMagSurveyType = "3D"
                }
            }         
            $rootScope.filterSurveyType = "";
        }
        return surveyEntitlementUrl;
    }
    this.getAdminAeroMagEntUrl = function () {
        var surveyEntitlementUrl = "";
        if ($rootScope.surveyCustomer !== undefined && $rootScope.surveyCustomer !== "") {
            surveyEntitlementUrl = $rootScope.surveyCustomer.customerId;
        }
        return surveyEntitlementUrl;
    }

    this.getSurveyGravMagEntitlementUrl = function () {
        var surveyEntitlementUrl = "";
        var surveyTypeFilterExist = false;
        if ($rootScope.surveyselectedValArr !== undefined && $rootScope.surveyselectedValArr.length > 0) {
            for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                var QBObj = $rootScope.surveyselectedValArr[i].value;
                for (var j = 0; j < QBObj.length; j++) {
                    if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                        || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                        surveyTypeFilterExist = true;
                        $rootScope.filterSurveyType = QBObj[j].substring(QBObj[j].length - 2);
                        break;
                    }
                }
            }
        }
        if ($rootScope.surveyselectedFieldsDetails !== undefined && $rootScope.surveyselectedFieldsDetails.length > 0 && !surveyTypeFilterExist) {
            for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType") {
                    surveyTypeFilterExist = true;
                    $rootScope.filterSurveyType = $rootScope.surveyselectedFieldsDetails[i].fieldValue;
                    break;
                }
            }
        }

        if (surveyTypeFilterExist) {
            surveyEntitlementUrl = this.getSurveyEntitlementUrl();
        }
        else {
            if ($rootScope.isExternalUser) {
                if ($rootScope.GravMagSurveyType == "2D" || $rootScope.GravMagSurveyType == undefined || $rootScope.GravMagSurveyType == "") {
                    surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    $rootScope.GravMagSurveyType = "2D"
                }
                else {
                    surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    $rootScope.GravMagSurveyType = "3D"
                }

            }            
            $rootScope.filterSurveyType = "";
        }
        return surveyEntitlementUrl;
    }

    this.getAdminGravMagEntUrl = function () {
        var surveyEntitlementUrl = "";
        if ($rootScope.surveyCustomer !== undefined && $rootScope.surveyCustomer !== "") {
            surveyEntitlementUrl = $rootScope.surveyCustomer.customerId;
        }
        return surveyEntitlementUrl;
    }

    this.getSurveyEntUserForMap = function () {
        var surveyEntitlementUrl = "";
        if ($rootScope.isExternalUser) {
            surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
        }
        return surveyEntitlementUrl;
    }
    this.getAdminEntUserForMap = function () {
        var surveyEntitlementUrl = "";
        if ($rootScope.surveyCustomer !== undefined && $rootScope.surveyCustomer !== "") {
            surveyEntitlementUrl = $rootScope.surveyCustomer.customerId;
        }
        return surveyEntitlementUrl;
    }

    this.getWellEntitlementUrl = function () {
        var entitlementUrl = "";
        if ($rootScope.isExternalUser) {
            entitlementUrl = $rootScope.externalUser.wellCustomerID;
        }
        return entitlementUrl;
    }
    this.getWellAdminEntitlementUrl = function () {
        var entitlementUrl = "";
        if ($rootScope.wellCustomer !== undefined && $rootScope.wellCustomer !== "") {
            entitlementUrl = $rootScope.wellCustomer.customerId;
        }
        return entitlementUrl;
    }

    this.getSurveyNameFor3DEntitle = function (surveyNamelist) {
        var surveyNameFilter = "";
        if (surveyNamelist !== undefined && surveyNamelist.length > 0) {
            for (var i = 0; i < surveyNamelist.length; i++) {
                if (i == 0)
                    surveyNameFilter = surveyNamelist[i];
                else
                    surveyNameFilter = surveyNameFilter + " &SurveyName=" + surveyNamelist[i];
            }
        }
        return surveyNameFilter;
    }

    this.getProjectNameFor3DEntitle = function (projectNamelist) {
        var projectNameFilter = "";
        if (projectNamelist !== undefined && projectNamelist.length > 0) {
            for (var i = 0; i < projectNamelist.length; i++) {
                if (i == 0)
                    projectNameFilter = projectNamelist[i];
                else
                    projectNameFilter = projectNameFilter + " &ProjectName=" + projectNamelist[i];
            }
        }
        return projectNameFilter;
    }

    this.getSpecpdfFilterUrl = function (title) {

        let selectedSearchTxt = "";
        if (title !== "" && title !== undefined) {
            selectedSearchTxt = title;
            setTimeout(function () {
                angular.element(document).find('[data-column-val="Page Number"]').removeClass('hide');
                angular.element(document).find('[data-column-val="Page Number"]').addClass('settingApplied')
            }, 1000)
        }
        else {
            setTimeout(function () {
                angular.element(document).find('[data-column-val="Page Number"]').addClass('hide');
                angular.element(document).find('[data-column-val="Page Number"]').removeClass('settingApplied')
            }, 1000)

        }

        return selectedSearchTxt;
    }

    this.getWellFilterUrl = function (title) {

        let selectedSearchTxt = "";
        if (title !== "" && title !== undefined) {
            selectedSearchTxt = title;
        }
        return selectedSearchTxt;
    }

    this.getSeismicPostRequest = function (source, filterStr, value) {
        var serviceUrl = "getSeismicFieldDistinctValuesFilter";
        var filterStrVal = "";

        if (filterStr == "" && value == "") {
            filterStrVal = "";
        }
        else {
            filterStrVal = filterStr + value;
        }
        //Form paramInfo
        var paramInfo = {
            source: source,
            filterStr: filterStrVal,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);
        //Form post request
        var request = {
            method: 'POST',
            url: this.urlValue + serviceUrl,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
        return request;
    }

    this.getWellPostRequest = function (source, filterStr, value) {
        var serviceUrl = "getFieldDistinctValuesFilter";
        var filterStrVal = "";

        if (filterStr == "" && value == "") {
            filterStrVal = "";
        }
        else {
            filterStrVal = filterStr + value;
        }
        //Form paramInfo
        var paramInfo = {
            source: source,
            filterStr: filterStrVal,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);
        //Form post request
        var request = {
            method: 'POST',
            url: this.urlValue + serviceUrl,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
        return request;
    }

    this.getWellCTSPostRequest = function (source, filterStr, value) {
        var serviceUrl = "getCountyAndGeoSectionAndTownShipByState";
        var filterStrVal = "";

        if (filterStr == "" && value == "") {
            filterStrVal = "";
        }
        else {
            filterStrVal = filterStr + value;
        }
        //Form paramInfo
        var paramInfo = {
            source: source,
            filterStr: filterStrVal,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);
        //Form post request
        var request = {
            method: 'POST',
            url: this.urlValue + serviceUrl,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
        return request;
    }

    //Frame the post request for CSV download(Survet/Well) in home screen and return the request object
    this.getHomeCSVDownload = function (metaDataFilter, geoSpaFilter, tabName, customerFilter) {
        var downloadCSVUrl = "downloadCSVFile";

        var filterStringInfo = "";
        if (metaDataFilter !== "" && geoSpaFilter == "")
            filterStringInfo = metaDataFilter
        else if (metaDataFilter == "" && geoSpaFilter !== "") {
            filterStringInfo = geoSpaFilter;
        }
        else if (geoSpaFilter !== "" && metaDataFilter !== "")
            filterStringInfo = metaDataFilter + geoSpaFilter;

        //CSV download params info
        var paramInfo = {
            tabName: tabName,
            filterStr: filterStringInfo,
            customerId: customerFilter,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }
        //Remove empty prameters
        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);

        //Form request object
        var request = {
            method: 'POST',
            url: this.urlValue + downloadCSVUrl,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
        return request;
    }

    //Frame the post request and return the request object    
    this.getPostReqParams = function (metaDataFilter, geoSpaFilter, LatLongFilter, qbFilter, selectedFields, uuid, customerFilter,
        moduleName, tabName, pageNumber, pageSize, orderStr, is2Dor3D, pdfFilterStr, cardinalityInfo) {
        
        var filterStringInfo = "";
        if (metaDataFilter !== "" && geoSpaFilter == "")
            filterStringInfo = metaDataFilter
        else if (metaDataFilter == "" && geoSpaFilter !== "") {
            filterStringInfo = geoSpaFilter + LatLongFilter;
        }
        else if (geoSpaFilter !== "" && metaDataFilter !== "")
            filterStringInfo = metaDataFilter + geoSpaFilter + LatLongFilter;

        var paramInfo = {
            module: moduleName,
            tabName: tabName,
            pageNumber: pageNumber.toString(),
            pageSize: pageSize,
            orderStr: orderStr,
            filterStr: filterStringInfo,
            queryBuilderStr: qbFilter,
            selectedFields: selectedFields,
            uuid: uuid,
            customerId: customerFilter,
            surveyType: is2Dor3D,
            pdfFilterStr: pdfFilterStr,
            cardinalityInfo: cardinalityInfo ? cardinalityInfo.toString() : "",
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.orderStr == "" ? delete paramInfo.orderStr : paramInfo.orderStr;
        paramInfo.pageNumber == "" ? delete paramInfo.pageNumber : paramInfo.pageNumber;
        paramInfo.pageSize == "" ? delete paramInfo.pageSize : paramInfo.pageSize;
        paramInfo.module == "" ? delete paramInfo.module : paramInfo.module;
        paramInfo.tabName == "" ? delete paramInfo.tabName : paramInfo.tabName;
        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.queryBuilderStr == "" || paramInfo.queryBuilderStr == undefined ? delete paramInfo.queryBuilderStr : paramInfo.queryBuilderStr;
        paramInfo.selectedFields == "" || paramInfo.selectedFields == undefined ? delete paramInfo.selectedFields : paramInfo.selectedFields;
        paramInfo.uuid == "" || paramInfo.uuid == undefined ? delete paramInfo.uuid : paramInfo.uuid;
        paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
        paramInfo.surveyType == "" || paramInfo.surveyType == undefined ? delete paramInfo.surveyType : paramInfo.surveyType;
        paramInfo.pdfFilterStr == "" || paramInfo.pdfFilterStr == undefined ? delete paramInfo.pdfFilterStr : paramInfo.pdfFilterStr;
        paramInfo.cardinalityInfo == "" || paramInfo.cardinalityInfo == undefined ? delete paramInfo.cardinalityInfo : paramInfo.cardinalityInfo;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent        

        var request = {
            method: 'POST',
            url: this.urlValue + this.getDetailInfo,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
        return request
    }


    //Frame the post request and return the request object for switch functionality
    this.getSwitchPostReqParams = function (metaDataFilter, geoSpaFilter, qbFilter, uuid, moduleName, previousTabName, customerFilter) {

        var filterStringInfo = "";
        if (metaDataFilter !== "" && geoSpaFilter == "")
            filterStringInfo = metaDataFilter
        else if (metaDataFilter == "" && geoSpaFilter !== "") {
            filterStringInfo = geoSpaFilter;
        }
        else if (geoSpaFilter !== "" && metaDataFilter !== "")
            filterStringInfo = metaDataFilter + geoSpaFilter;

        var paramInfo = {
            module: moduleName,
            tabName: previousTabName[0],
            filterStr: filterStringInfo,
            queryBuilderStr: qbFilter,
            uuid: uuid,
            customerId: customerFilter,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.module == "" ? delete paramInfo.module : paramInfo.module;
        paramInfo.tabName == "" ? delete paramInfo.tabName : paramInfo.tabName;
        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.queryBuilderStr == "" || paramInfo.queryBuilderStr == undefined ? delete paramInfo.queryBuilderStr : paramInfo.queryBuilderStr;
        paramInfo.uuid == "" || paramInfo.uuid == undefined ? delete paramInfo.uuid : paramInfo.uuid;
        paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent
        var request = {
            method: 'POST',
            url: this.urlValue + this.getDetailInfoForSwitch,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
        return request;
    }

    //Frame the post request and return the request object for  Trace level csv download   
    this.getTraceLevelCSVDownload = function (downloadTraceInfoObj, metaDataFilter, geoSpaFilter, qbFilter) {

        var filterStringInfo = "";
        if (metaDataFilter !== "")
            filterStringInfo = metaDataFilter

        //Form paramInfo
        var paramInfo = {
            tabName: downloadTraceInfoObj.tabName,
            ProjectID: downloadTraceInfoObj.ProjectID,
            LineNumber: downloadTraceInfoObj.LineNumber,
            surveyType: downloadTraceInfoObj.surveyType,
            S3FileName: downloadTraceInfoObj.S3FileName,
            S3VelocityFileName: downloadTraceInfoObj.S3VelocityFileName,
            customerId: downloadTraceInfoObj.customerId,
            filterStr: filterStringInfo,
            shapeFilterStr: geoSpaFilter,
            queryBuilderStr: qbFilter,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.tabName == "" ? delete paramInfo.tabName : paramInfo.tabName;
        paramInfo.ProjectID == "" || paramInfo.ProjectID == undefined ? delete paramInfo.ProjectID : paramInfo.ProjectID;
        paramInfo.LineNumber == "" || paramInfo.LineNumber == undefined ? delete paramInfo.LineNumber : paramInfo.LineNumber;
        paramInfo.surveyType == "" || paramInfo.surveyType == undefined ? delete paramInfo.surveyType : paramInfo.surveyType;
        paramInfo.S3FileName == "" || paramInfo.S3FileName == undefined ? delete paramInfo.S3FileName : paramInfo.S3FileName;
        paramInfo.S3VelocityFileName == "" || paramInfo.S3VelocityFileName == undefined ? delete paramInfo.S3VelocityFileName : paramInfo.S3VelocityFileName;
        paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.shapeFilterStr == "" || paramInfo.shapeFilterStr == undefined ? delete paramInfo.shapeFilterStr : paramInfo.shapeFilterStr;
        paramInfo.queryBuilderStr == "" || paramInfo.queryBuilderStr == undefined ? delete paramInfo.queryBuilderStr : paramInfo.queryBuilderStr;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);

        //Form request object
        var request = {
            method: 'POST',
            url: this.urlValue + "getTraces",
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }

        }
        return request;
    }

    this.getDetailCSVDownload = function (moduleName, tabName, metaDataFilter, geoSpaFilter, LatLongFilter, qbFilter, customerFilter, surveyType, uuid) {
        var filterStringInfo = "";
        if (metaDataFilter !== "" && geoSpaFilter == "")
            filterStringInfo = metaDataFilter
        else if (metaDataFilter == "" && geoSpaFilter !== "") {
            filterStringInfo = geoSpaFilter + LatLongFilter;
        }
        else if (geoSpaFilter !== "" && metaDataFilter !== "")
            filterStringInfo = metaDataFilter + geoSpaFilter + LatLongFilter;
        //Form paramInfo
        var paramInfo = {
            module: moduleName,
            tabName: tabName,
            filterStr: filterStringInfo,
            queryBuilderStr: qbFilter,
            surveyType: surveyType,
            customerId: customerFilter,
            uuid: uuid,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.module == "" ? delete paramInfo.module : paramInfo.module;
        paramInfo.tabName == "" ? delete paramInfo.tabName : paramInfo.tabName;
        paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
        paramInfo.queryBuilderStr == "" || paramInfo.queryBuilderStr == undefined ? delete paramInfo.queryBuilderStr : paramInfo.queryBuilderStr;
        paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
        paramInfo.surveyType == "" || paramInfo.surveyType == undefined ? delete paramInfo.surveyType : paramInfo.surveyType;
        paramInfo.uuid == "" || paramInfo.uuid == undefined ? delete paramInfo.uuid : paramInfo.uuid;
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);

        //Form request object
        var request = {
            method: 'POST',
            url: this.urlValue + this.getWellDetailInfoCsvDownload,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }

        }
        return request;
    }

    //Create UI log request and return the request object
    this.createUILog = function (controllerName, methodName, serviceCalled, applicationName, loggedInUser, status,
        metaDataFilter, QBFilter, polygonFilter, entitlementFilter, timeStamp, duration, failReason) {
        var serviceUrl = "storeUILogs";

        var paramInfo = {
            loggingControllerName: controllerName,
            loggingMethodName: methodName,
            serviceCalled: serviceCalled,
            loggedInUser: loggedInUser,
            status: status,
            loggingApplicationName: applicationName,
            metaDataFilter: metaDataFilter,
            querybuilderFilter: QBFilter,
            polygonFilter: polygonFilter,
            entitlementFilter: entitlementFilter,
            transactionId: this.generateGUID(),
            timeStamp: timeStamp,
            duration: duration,
            failReason: failReason,
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }

        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
        var paramInfoList = $.param(paramInfo);

        //Form request object
        var request = {
            method: 'POST',
            url: this.urlValue + serviceUrl,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }

        }
        return request;
    }
    //Form Survey Summary request object
    this.getSurveySummaryRequest = function (surveyName) {
        var paramInfo = {
            source: "SurveyName",
            size: 1000,
            filterStr: "SurveyName:" + surveyName,
            requestTimestamp: this.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
        }
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

        var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent

        var request = {
            method: 'POST',
            url: this.urlValue + "getSurveySummaryFilter",
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        }
        return request;
    }

    //Get the current time in milliseconds
    this.getCurrentTime = function () {
        return new Date().getTime();
    }

    //Get the current Date and time
    this.getCurrentDateTime = function () {
        return new Date().toLocaleString();
    }

    //Get the Start and End time difference in seconds
    this.getTimeDifferenceInSeconds = function (startTime, endTime) {
        var timeDiff = (endTime - startTime) / 1000; // Devide milliseconds with 1000 to convert in seconds
        return timeDiff;
    }
    
    //get date from MM-DD-YYYY to YYYY-MM-DD format fro ES compatable
    this.getFiletrDateFormat = function(filterDate)
    {
        return moment(filterDate, 'MM-DD-YYYY').format('YYYY-MM-DD');
    }
    
    //Redirects the user to big Decisions core for unauthirised user access
    this.redirectToCore = function (response) {
        this.enableTabs();
        if (response.status == 401 || response.status == -1) {
            $.alertable.alert("You are unauthorised or your session has been timed Out\nPlease Login again to continue")
            window.location.assign(this.urlValue);
        }
    }

    //Generated the unique GUID
    this.generateGUID = function () {
        var dt = new Date().getTime();
        var guid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (dt + Math.random() * 16) % 16 | 0;
            dt = Math.floor(dt / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return guid;
    }

    this.enableTabs = function () {
        angular.element(document).find('.nav.nav-tabs').find('.isTabDisable').addClass('hide');
    }

    //Survey Summary add filter
    this.addFilterValue = function (fieldName, fieldValue, titleName) {
        if ($rootScope.surveyselectedFieldsDetails.length > 0) {
            var isExist = this.isDuplicateFieldExist(fieldName, fieldValue)
            if (isExist) {
                if (fieldName == "ProjectName") {
                    $.alertable.alert("Project name with '" + fieldValue + "' is already exist in applied filter.");
                }
                else if (fieldName == "SurveyName") {
                    //Show duplicate message poppup if same project is added
                    $.alertable.alert("Survey name with '" + fieldValue + "' is already exist in applied filter.");
                }

                return false;
            }
            var flag = true;
            for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                if ($rootScope.surveyselectedFieldsDetails[i].fieldName == fieldName) {
                    if ($rootScope.surveyselectedFieldsDetails[i].fieldValue != "") {
                        $rootScope.surveyselectedFieldsDetails[i].fieldValue = $rootScope.surveyselectedFieldsDetails[i].fieldValue + "," + fieldValue;
                        $rootScope.surveyselectedFieldsDetails[i].displayName = $rootScope.surveyselectedFieldsDetails[i].displayName + "," + fieldValue;
                    }
                    flag = false;
                }
            }

            if (flag) {
                var obj = new Object();
                obj.fieldName = fieldName;
                obj.fieldValue = fieldValue;
                obj.titleName = titleName;
                obj.displayName = fieldValue;
                $rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
            }
        }
        else {
            var obj = new Object();
            obj.fieldName = fieldName;
            obj.fieldValue = fieldValue;
            obj.titleName = titleName;
            obj.displayName = fieldValue;
            $rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
        }
        $rootScope.applyFilterAction(true);
    }

    this.isDuplicateFieldExist = function (fieldName, selectedValue) {
        for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
            var arr = $rootScope.surveyselectedValArr[i].value;
            var title = $rootScope.surveyselectedValArr[i].title;
            for (var j = 0; j < arr.length; j++) {
                if (arr[j] == selectedValue && title == fieldName) {
                    return true;
                }
            }
        }
        return false;
    }


});
