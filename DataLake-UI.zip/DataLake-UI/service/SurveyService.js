angular.module('TGSApp').service('SurveyService', function (Common) {    
    this.urlValue = Common.urlValue;
    this.allSurveyInfoService = 'getSurveyNameFilter';
    this.allSurveyFilter = '';
    this.surveyQueryBuilder = '';
    this.SEGYSelectedFields = '&selectedFields=';     
    this.VelocitySelectedFields = '&selectedFields=';    
    this.SpecSheetSelectedFields = '&selectedFields=';
    this.allFilterDataService = 'getSeismicMetaDataFilters';
    this.uuid = "&uuid=";
    this.pdfFilterStr="&pdfFilterStr=";
    this.allCustomer = "getEntitlementDetails";//Entitlement
    this.SeismicGeographyMetaDataFilters = "getSeismicGeographyMetaDataFilters";
    this.SeismicSurveyMetaDataFilters = "getSeismicSurveyMetaDataFilters";
    this.SeismicProjectMetaDataFilters = "getSeismicProjectMetaDataFilters";
    this.SeismicProductMetaDataFilters = "getSeismicProductMetaDataFilters";
    this.getDetailInfo="getDetailInfo" // Seismic
    this.seismicSegYtaburl = "getDetailInfo?module=Seismic&tabName=SEGY&pageSize=20&pageNumber=0";
    this.seismicHorizontaburl = "getDetailInfo?module=Seismic&tabName=Horizon&pageSize=20&pageNumber=0";
    this.seismicVelocitytaburl = "getDetailInfo?module=Seismic&tabName=Velocity&pageSize=20&pageNumber=0";
    this.seismicAeroMagtaburl = "getDetailInfo?module=Seismic&tabName=AeroMag&pageSize=20&pageNumber=0";
    this.seismicGravMagtaburl = "getDetailInfo?module=Seismic&tabName=GravMag&pageSize=20&pageNumber=0";
    this.seismicSpecSheettaburl = "getDetailInfo?module=Seismic&tabName=SpecSheet&pageSize=20&pageNumber=0";
    
});


