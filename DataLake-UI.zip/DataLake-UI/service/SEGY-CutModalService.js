angular.module('TGSApp').service('SEGYCUTService', function () {
    // this.SEGYCutData = [
    //             { "name": "File Name", "value": "Line Name", "disable": "20.2" },
    //             { "name": "Line Number", "value": "Line Name", "disable": "4.12" },

    //             { "name": "Survey", "value": "Survey", "disable": "6.23" },
    //             { "name": "Project Name", "value": "Project Name", "disable": "5.24" },
    //             { "name": "Project Type", "value": "Project Type", "disable": "81.56" },
    //             // { "name": "Product Name", "value": "Product Name", "disable": "23.54" },
    //             // { "name": "Product Type", "value": "Product Type", "disable": "1.26" },
    //             // { "name": "Area", "value": "Area", "disable": "5.12" },
    //             // { "name": "Survey Size", "value": "Survey Size", "disable": "20.15" },
    //             // { "name": "Survey Status", "value": "Survey Status", "disable": "4.87" },
    //             // { "name": "S3 File Size", "value": "S3 File Size", "disable": "2.58" },
    //             { "name": "S3 File Path", "value": "S3 File Path", "disable": "4.68" }],
    //         this.projectNames= [
    //             {"name":"PSTM"},
    //             {"name":"Near Angle 1.0"},
    //             {"name":"Near Angle 2.0"},
    //             {"name":"FAR ANGEL Stack 1.0"},
    //             {"name":"FAR ANGEL Stack 2.0"}
    //    ]
        });