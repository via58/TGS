angular.module('TGSApp').service('InterpretiveService', function (Common) {    
    this.urlValue = Common.urlValue;   
    this.ipQueryBuilder = '';  
});


