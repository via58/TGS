angular.module('TGSApp').service('Constants', function () {

    this.MAP_CTRL = "mapViewCtrl";
    this.APPLY_WELL_FILTERS = "applyWellFilters";
    this.SUCCESS = "Success";
    this.ZOOM_TO_SURVEY = "zoomToSurvey";
    this.FAILED = "Failed";
    this.GET_SURVEY_IN_POLYGON = "getSurveysInPolygon";
    this.APPLY_PROJECT_FILTERS = "applyProjectFilters";
    this.APPLICATION_NAME = "Datalake UI";


    this.SURVEY_NAME = "SurveyName";
    this.SHOW_SURVEY_SUMMARY_PANEL= "surveySummaryPanel";
    this.HIDE_SURVEY_SUMMARY_PANEL= "surveySummaryPanel surveySummaryhidePanel";

    this.GLIFICON_LEFT = "glyphicon glyphicon-chevron-left";
    this.GLIFICON_RIGHT = "glyphicon glyphicon-chevron-right";

    this.GLIFICON_DOWN = "glyphicon glyphicon-chevron-down";
    this.GLIFICON_UP = "glyphicon glyphicon-chevron-up";

});
