(function (window) {    
    window.__env = window.__env || {} ;
    // API url           
    window.__env.apiUrl = "https://uitest.datalake.tgs.com/"; 
    //window.__env.apiUrl = "https://dev-api.datalake.tgs.com/";       
    //window.__env.apiUrl = "https://dev-orientdb.datalake.tgs.com:8888/"; 
    //window.__env.apiUrl = "https://uat-ui.datalake.tgs.com:8888/"; 
    //window.__env.apiUrl = "https://ui.datalake.tgs.com/";
    
}(this));