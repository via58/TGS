(function (angular) {
    'use strict';
    var env = {};
// Import variables if present (from env.js)
if(window){  
  Object.assign(env, window.__env);
}
    var app = angular.module('TGSApp', ['ui.bootstrap', 'ngRoute', 'ui.multiselect', "bw.paging"]);
    
    // Register environment in AngularJS as constant
    app.constant('__env', env);
    //console.log(__env);
    app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {

        //var redirectURL = "https://ui.datalake.tgs.com";
        var redirectURL = "https://uitest.datalake.tgs.com";
        //var redirectURL = "https://dev-api.datalake.tgs.com";

        $routeProvider.when('/homeView', {
            templateUrl: "views/homeView.html",
            resolve: {
                tables: function ($location) {
                    if (window.access) {
                        $location.path('/homeView');
                    } else {
                        window.access = false;
                        //$.alertable.alert("You don't have access here");
                        window.location.assign(redirectURL);
                    }
                }
            }
        })

            .when('/home/:usrrole', {
                controller: "accessCtrl",
                template: '<div id="overlay"><div class="spinner"></div></div>'

            })

            .when('/detail', {
                templateUrl: "views/detailView.html",
                resolve: {
                    tables: function ($location) {
                        if (window.access) {
                            $location.path('/detail');
                        } else {
                            window.access = false;
                            //$.alertable.alert("You don't have access here");
                            window.location.assign(redirectURL);
                        }
                    }
                },
                controller: "wellLasTabCtrl"

            })

            .when('/', {
                template: '<div id="overlay"><div class="spinner"></div></div>',
                resolve: {
                    tables: function ($location) {
                        window.access = false;
                        //$.alertable.alert("You don't have access here");
                        window.location.assign(redirectURL);
                    }
                }
            })
            .otherwise({ redirectTo: '/' });

            //$locationProvider.html5Mode(true);

    }]);
})(window.angular);

