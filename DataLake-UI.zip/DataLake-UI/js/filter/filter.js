angular.module('TGSApp').filter("stringToDate", function ($filter) {
    return function (dateVal){
        if(dateVal !== null && dateVal !== undefined && dateVal !== "")
        {
        return $filter('date')(new Date(dateVal),"MM/dd/yyyy");       
        }       
     }
})
.filter("stringToDateMMYYYY", function ($filter) {
    return function (dateVal){
        if(dateVal !== null && dateVal !== undefined && dateVal !== "")
        {
        return $filter('date')(new Date(dateVal),"MM/yyyy");       
        }
                
     }
});
