/*
File Name:- ipqbCtrl.js
Summary:-  Fetch the distinct Interpretive Field values for selected field name in Query Builder.
*/

angular.module('TGSApp').controller('ipqbCtrl', function ($scope, $rootScope, $http, $timeout, $interval, $compile, SurveyService, Common, InterpretiveService) {
	$rootScope.iptmArr = [];
	$scope.hasQuerybuilder = false;;
	$scope.selectedtd = [];
	$rootScope.IPaplFilter = [];
	$rootScope.IPselectedFieldsDetails = [];
	$rootScope.IPaplFilterData = [];
	
	// This function collects the Interpretive Selected fields 
	$rootScope.IPappliedFilterData = function () {

		for (var i = 0; ($rootScope.IPaplFilterData !== null && i < $rootScope.IPaplFilterData.length); i++) {
			if ($rootScope.IPaplFilterData[i] !== undefined) {
				var tempSelectedValArr = $rootScope.IPaplFilterData[i].split(',');
				var tempSelectedValArr1 = [];

				for (var val = 0; val < tempSelectedValArr.length; val++) {
					if (tempSelectedValArr[val] !== "" && tempSelectedValArr[val] !== null) {
						var filval = tempSelectedValArr[val].includes('~~') ? tempSelectedValArr[val].replace('~~', ',') : tempSelectedValArr[val];
						tempSelectedValArr1.push(filval);
					}
				}
				var obj = new Object();
				obj.value = tempSelectedValArr1;
				obj.type = "comnfilter";
				if ($rootScope.IPaplFilterTitle[i] !== undefined) {
					obj.title = $rootScope.IPaplFilterTitle[i];
				}
				else {
					obj.title = "Polygon Name";
				}
				$rootScope.IPselectedValArr[$rootScope.IPselectedValArr.length] = obj;
			}
		}
	}
	//This  function will frame Query builder depends on user selection
	$rootScope.ipformQueryBuilder = function () {
		var queryBuilderStr = "";
		$rootScope.IPQBFilterArr = [];
		angular.element('.Iprtvegrp .QueryBuilder-container .QueryBuilder-condition').each(function () {

			var LHSVal = angular.element(this).find('select:nth-child(3) option:selected').val();
			var MHSVal = angular.element(this).find('select:nth-child(4) option:selected').val();

			if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typestring')) {
				var RHSVal = angular.element(this).find('.RHSSelect').val();
			}

			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typedate')) {
				if(MHSVal == "btw"){
					var RHSVal = angular.element(this).find('.RHSDateRange').val();
					var tempDate = RHSVal.split('-');
					RHSVal = tempDate[0].split('/').join('-').trim()+ "<<" + tempDate[1].split('/').join('-').trim();
				}
				else{
					var RHSVal = angular.element(this).find('.RHSFielddate').val();
				}
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typesearch')) {
				var RHSVal = angular.element(this).find('.RHSFieldsearch').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typetxt')) {
				var RHSVal = angular.element(this).find('.RHSFieldname').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeflag')) {
				var RHSVal = angular.element(this).find('.RHSFlg').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeRange')) {
				if(MHSVal == "btw"){
					var RHSVal = angular.element(this).find('.RHSNumRange').val();
				}
				else{
					var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
				} 
			}
			else {
				var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
			}
			var allVall = LHSVal + ":" + MHSVal + ":" + RHSVal;
			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				$scope.iptmArr.push(allVall);
			}
		});

		if ($scope.iptmArr.length > 0) {
			queryBuilderStr = Common.getquerybuilderfilter($scope.iptmArr); //Form querybuilder filter string
			$rootScope.IPQBFilterArr = $scope.iptmArr;
		}
		InterpretiveService.ipQueryBuilder = queryBuilderStr;
		if ($scope.iptmArr != null && $scope.iptmArr.length > 0) {
			var obj = new Object();
			obj.value = $scope.iptmArr;
			obj.title = "Query Builder Filter";
			obj.type = "qbfltr";
			obj.fgname = "ipqb";
			$rootScope.IPselectedValArr[$rootScope.IPselectedValArr.length] = obj;
		}
	}
	//This function checks if query builder contains duplicate value 
	$rootScope.checkIPQBDuplicateValue = function (ipQBFilterArr) {
		var qbfieldArr = [];
		angular.element('.Iprtvegrp .QueryBuilder-container .QueryBuilder-condition').each(function () {

			var LHSVal = angular.element(this).find('select:nth-child(3) option:selected').val();
			var MHSVal = angular.element(this).find('select:nth-child(4) option:selected').val();

			if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typestring')) {
				var RHSVal = angular.element(this).find('.RHSSelect').val();
			}

			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typedate')) {
				if(MHSVal == "btw"){
					var RHSVal = angular.element(this).find('.RHSDateRange').val();
					var tempDate = RHSVal.split('-');
					RHSVal = tempDate[0].split('/').join('-').trim()+ "<<" + tempDate[1].split('/').join('-').trim();
				}
				else{
					var RHSVal = angular.element(this).find('.RHSFielddate').val();
				}
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typesearch')) {
				var RHSVal = angular.element(this).find('.RHSFieldsearch').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typetxt')) {
				var RHSVal = angular.element(this).find('.RHSFieldname').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeRange')) {
				var RHSVal = angular.element(this).find('.RHSNumRange').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeflag')) {
				var RHSVal = angular.element(this).find('.RHSFlg').val();
			}
			else {
				var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
			}
			var allVall = LHSVal + ":" + MHSVal + ":" + RHSVal;

			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				qbfieldArr.push(allVall);

				if (qbfieldArr.length > 1) {
					for (var i = 0; i < qbfieldArr.length - 1; i++) {
						for (j = i + 1; j <= qbfieldArr.length; j++) {
							if (qbfieldArr[i] == qbfieldArr[j]) {
								$rootScope.isDuplicate = true;
								$.alertable.alert("Query builder Filter '" + qbfieldArr[i] + "' is selected morethan ones.");
								return false;
							}
						}
					}
				}
			}

			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				for (var f = 0; (ipQBFilterArr !== undefined && f < ipQBFilterArr.length); f++) {
					if (ipQBFilterArr[f] == allVall) {
						$rootScope.isDuplicate = true;
						$.alertable.alert("Query builder Filter '" + allVall + "' is already exist in applied filter. Modify or remove the filter condition.");
						break;
					}
				}
			}
		});

	}
});