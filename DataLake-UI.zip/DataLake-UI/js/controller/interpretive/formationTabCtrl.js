/*
File Name:- formationTabCtrl.js
Summary:- This page will loads formation sub tabs details.
*/

angular.module('TGSApp').controller('formationTabCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
  $rootScope.activeaab = "Bio Strat Tops";
  $scope.fmbTab = function (tabname, e) {
    var Curelement = angular.element(e.currentTarget);    
    $scope.tabName = tabname;
    //Loads Bio Strat Tops tab details
    if ($scope.tabName == "Bio Strat Tops") {
      $rootScope.biostCnt = 1;
      if ($rootScope.biostCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "BioStratTops";
        $rootScope.iptools = false;
        $rootScope.interbiostrattop();
        $rootScope.biostCnt += 1;        
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Chrono Strat Tops tab details
    else if ($scope.tabName == "Chrono Strat Tops") {
      $rootScope.chronostCnt = 1;
      if ($rootScope.chronostCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "ChronoStratTops";
        $rootScope.iptools = false;
        $rootScope.interchronostrattop();
        $rootScope.chronostCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');       
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      
      }
    }
    //Loads Core Tops tab details
    else if ($scope.tabName == "Core Tops") {
      $rootScope.coreTopCnt = 1;
      if ($rootScope.coreTopCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.iptools = false;
        $rootScope.curTab = "CoreTops";
        $rootScope.interCoreTops();
        $rootScope.coreTopCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Env Facies Tops tab details
    else if ($scope.tabName == "Env Facies Tops") {
      $rootScope.envfacCnt = 1
      if ($rootScope.envfacCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "EnvFaciesTops";
        $rootScope.iptools = false;
        $rootScope.interEnvFaciesTops();
        $rootScope.envfacCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Litho Strat Tops tab details
    else if ($scope.tabName == "Litho Strat Tops") {
      $rootScope.lithostCnt = 1
      if ($rootScope.lithostCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "LithoStratTops";
        $rootScope.iptools = false;
        $rootScope.interLithoStratTops();
        $rootScope.lithostCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Lithology Tops tab details
    else if ($scope.tabName == "Lithology Tops") {
      $rootScope.litogyCnt = 1
      if ($rootScope.litogyCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "LithologyTops";
        $rootScope.iptools = false;
        $rootScope.interLithologyTops();
        $rootScope.litogyCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Maturity Type Tops tab details
    else if ($scope.tabName == "Maturity Type Tops") {
      $rootScope.mattypCnt = 1;
      if ($rootScope.mattypCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "MaturityTypeTops";
        $rootScope.iptools = false;
        $rootScope.interMaturitytypetop();
        $rootScope.mattypCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Rock Evaluation Tops tab details
    else if ($scope.tabName == "Rock Evaluation Tops") {
      $rootScope.rockevCnt = 1;
      if ($rootScope.rockevCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "RockEvaluationTops";
        $rootScope.iptools = false;
        $rootScope.interrockevaluationtop();
        $rootScope.rockevCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Sequence Strat Tops tab details
    else if ($scope.tabName == "Sequence Strat Tops") {
      $rootScope.seqstCnt = 1;
      if ($rootScope.seqstCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "SequenceStratTops";
        $rootScope.iptools = false;
        $rootScope.intersequencestrattop();
        $rootScope.seqstCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Showtops Tops tab details
    else if ($scope.tabName == "Showtops") {
      $rootScope.shotopCnt = 1;
      if ($rootScope.shotopCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.iptools = false;
        $rootScope.curTab = "Showtops";
        $rootScope.interShowtop();
        $rootScope.shotopCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
    //Loads Visual Maceral Tops tab details
    else if ($scope.tabName == "Visual Maceral Tops") {
      $rootScope.vismacCnt = 1;
      if ($rootScope.vismacCnt == 1) {
        $rootScope.activeaab = $scope.tabName;
        $rootScope.curTab = "VisualMaceralTops";
        $rootScope.iptools = false;
        $rootScope.intervisualmaceraltop();
        $rootScope.vismacCnt += 1;
        angular.element(Curelement).parent().parent().find('li').removeClass('active');
        angular.element(Curelement).parent().addClass('active');
        angular.element(Curelement).parent().parent().next().find('.tab-content').find('.tab-pane').find('.well-list-details:first').addClass('ng-hide');
      }
    }
  }
});


