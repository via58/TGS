/*
File Name:- interShowTopCtrl.js
Summary:- Fetch the ShowTops details based on the filter string.
*/

angular.module('TGSApp').controller('interShowTopCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;

    // This function fetches the ShowTops data based on the current filter.
    $rootScope.interShowtop = function () {
        $scope.ShowTopsitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
            var geoSpatialFilter = "";

            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
            
            // Below function will loads clusters in Map with respect to current filter string.
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, InterpretiveService.ipQueryBuilder, "", "", "");

            //Form the request object
            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
                "Interpretive", "ShowTops", "0", "20", "", "", "")

            // Calling http service request to get ShowTops data             
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }

    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.ShowTopsitems = response.data.content;
            $scope.ShowTopscount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.ShowTopsPagesCount = response.data.totalElements;    //Assigning total elements count
            }
            else {
                $scope.ShowTopsPagesCount = 10000;
            }
        }
        else {
            $scope.ShowTopsitems = [];
            $scope.ShowTopsPagesCount = 0;
            $scope.ShowTopscount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('#overlay').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('#overlay').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    //  This function will fetch the ShowTops data on click of pager.
    $rootScope.intershowtopspager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        $scope.ShowTopsitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;        

        //Form the request object
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
            "Interpretive", "ShowTops", $scope.clickedpage, "20", "", "", "")

        // Calling http service request to get ShowTops data        
        $http(request).then(successCallback, errorCallback);
    }

});