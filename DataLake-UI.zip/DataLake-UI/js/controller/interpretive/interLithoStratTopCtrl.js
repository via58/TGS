/*
File Name:- interLithoStratTopCtrl.js
Summary:- Fetch the Litho Strat Top details based on the filter string.
*/

angular.module('TGSApp').controller('interLithoStratTopCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;

    // This function fetches the Litho Strat Top data based on the current filter.
    $rootScope.interLithoStratTops = function () {
        $scope.LithoStratTopsitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";
            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

            // Below function will loads clusters in Map with respect to current filter string.
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, InterpretiveService.ipQueryBuilder, "", "", "");

            //Form the request object
            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
                "Interpretive", "LithoStratTops", "0", "20", "", "", "")

            // Calling http service request to get Litho Strat Top data             
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.LithoStratTopsitems = response.data.content;
            $scope.LithoStratTopscount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.LithoStratTopsPagesCount = response.data.totalElements;  //Assigning total elements count
            }
            else {
                $scope.LithoStratTopsPagesCount = 10000;
            }
        }
        else {
            $scope.LithoStratTopsitems = [];
            $scope.LithoStratTopsPagesCount = 0;
            $scope.LithoStratTopscount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }
    //  This function will fetch the Litho Strat Top data on click of pager.
    $rootScope.interLithoStratTopspager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        $scope.LithoStratTopsitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;
        //var lithoStratTopstaburl = 'getDetailInfo?tabName=LithoStratTops&module=Interpretive&pageNumber=' + $scope.clickedpage + '&pageSize=20';

        //Form the request object
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
            "Interpretive", "LithoStratTops", $scope.clickedpage, "20", "", "", "")

        // Calling http service request to get Litho Strat Top data         
        $http(request).then(successCallback, errorCallback);
    }

});