/*
File Name:- interLithologyTopCtrl.js
Summary:- Fetch the Lithology Top details based on the filter string.
*/


angular.module('TGSApp').controller('interLithologyTopCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    // This function fetches the Lithology Top data based on the current filter.
    $rootScope.interLithologyTops = function () {
        $scope.LithologyTopsitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
            var geoSpatialFilter = "";
            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

            // Below function will loads clusters in Map with respect to current filter string.
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, InterpretiveService.ipQueryBuilder, "", "", "");
            //Form the request object
            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
                "Interpretive", "LithologyTops", "0", "20", "", "", "")

            // Calling http service request to get Lithology Top data             
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.LithologyTopsitems = response.data.content;
            $scope.LithologyTopscount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.LithologyTopsPagesCount = response.data.totalElements;   //Assigning total elements count
            }
            else {
                $scope.LithologyTopsPagesCount = 10000;
            }
        }
        else {
            $scope.LithologyTopsitems = [];
            $scope.LithologyTopsPagesCount = 0;
            $scope.LithologyTopscount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
            angular.element(document.body).find('.pagerspinner').remove();
        }, 1500);
        Common.enableTabs();
    }
    // This function will catch the error.
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }
    //  This function will fetch the Lithology Top data on click of pager.
    $rootScope.interLithologyTopspager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        $scope.LithologyTopsitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;
        var lithologyTopstaburl = 'getDetailInfo?tabName=LithologyTops&module=Interpretive&pageNumber=' + $scope.clickedpage + '&pageSize=20';

        //Form the request object
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
            "Interpretive", "LithologyTops", $scope.clickedpage, "20", "", "", "")

        // Calling http service request to get Lithology Top data         
        $http(request).then(successCallback, errorCallback);
    }

});