/*
File Name:- interpretiveLasCtrl.js
Summary:- Fetch the Interpretive Las details based on the filter string.
*/

angular.module('TGSApp').controller('interpretiveLasCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    // This function fetches the Interpretive Las data based on the current filter.
    $rootScope.interpretiveLasTab = function () {
        $rootScope.curTab = "InterpretiveLas";
        $scope.interLasitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";
            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
            
            // Below function will loads clusters in Map with respect to current filter string.
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, InterpretiveService.ipQueryBuilder, "", "", "");

            //Get the post request parameters info
            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter,
                "", InterpretiveService.ipQueryBuilder, "", "", "",
                "Interpretive", "FmbLas",
                "0", $scope.pageSize, "", "", "");
            // Calling http service request to get Interpretive Las data             
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }

    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.interLasitems = response.data.content;
            $scope.interLascount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.interLasPagesCount = response.data.totalElements;    //Assigning total elements count
            }
            else {
                $scope.interLasPagesCount = 10000;
            }
        }
        else {
            $scope.interLasitems = [];
            $scope.interLasPagesCount = 0;
            $scope.interLascount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }
        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1000);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    //  This function will fetch the Interpretive Las data on click of pager
    $rootScope.interLaspager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        $scope.interLasitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;        

        // Calling http service request to get Interpretive Las data 
        //Get the post request parameters info        
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter,
            "", InterpretiveService.ipQueryBuilder, "", "", "",
            "Interpretive", "FmbLas",
            $scope.clickedpage, $scope.pageSize, "", "", "")        
        $http(request).then(successCallback, errorCallback);
    }

});