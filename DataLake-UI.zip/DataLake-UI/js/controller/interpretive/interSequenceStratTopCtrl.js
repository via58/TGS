/*
File Name:- interSequenceStratTopCtrl.js
Summary:- Fetch the Sequence Start Tops details based on the filter string.
*/

angular.module('TGSApp').controller('interSequenceStratTopCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;

    // This function fetches the Sequence Start Tops data based on the current filter.
    $rootScope.intersequencestrattop = function () {
        $scope.Sequencestrattopsitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
            var geoSpatialFilter = "";

            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

            // Below function will loads clusters in Map with respect to current filter string.
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, InterpretiveService.ipQueryBuilder, "", "", "");

            //Form the request object
            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
                "Interpretive", "SequenceStratTops", "0", "20", "", "", "")

            // Calling http service request to get Sequence Start Tops data             
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }


    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.Sequencestrattopsitems = response.data.content;
            $scope.Sequencestrattopscount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.SequencestrattopsPagesCount = response.data.totalElements;   //Assigning total elements count
            }
            else {
                $scope.SequencestrattopsPagesCount = 10000;
            }
        }
        else {
            $scope.Sequencestrattopsitems = [];
            $scope.SequencestrattopsPagesCount = 0;
            $scope.Sequencestrattopscount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    //  This function will fetch the Sequence Start Tops data on click of pager.
    $rootScope.intersequencestrattoppager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        $scope.Sequencestrattopsitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;        

        //Form the request object
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
            "Interpretive", "SequenceStratTops", $scope.clickedpage, "20", "", "", "")

        // Calling http service request to get Sequence Start Tops data         
        $http(request).then(successCallback, errorCallback);
    }
});