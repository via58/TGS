/*
File Name:- interBiostratTopCtrl.js
Summary:- Fetch the Biostrat Top details based on the filter string.
*/

angular.module('TGSApp').controller('interBiostratTopCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    // This function fetches the biostrattop data based on the current filter.
    $rootScope.interbiostrattop = function () {
        $scope.Biostrattopsitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            //angular.element(document.body).append('<div id="overlay"><div class="spinner"></div></div>');
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";
            // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
            if (window.drawPolygon) {
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
            }
            //var biostrattoptaburl = "getDetailInfo?tabName=BioStratTops&module=Interpretive&pageNumber=0&pageSize=20";

            // Below function will loads biostrattop Well clusters in Map with respect to current filter string.                     
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, InterpretiveService.ipQueryBuilder, "", "", "");

            //Form the request object 
            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
                "Interpretive", "BioStratTops", "0", "20", "", "", "")
            // Calling http service request to get biostrattop data
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.Biostrattopsitems = response.data.content; // Assign biostrattop Data
            $scope.Biostrattopscount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.BiostrattopsPagesCount = response.data.totalElements;
            }
            else {
                $scope.BiostrattopsPagesCount = 10000;
            }
        }
        else {
            $scope.Biostrattopsitems = []; // Assign biostrattop Data
            $scope.BiostrattopsPagesCount = 0;
            $scope.Biostrattopscount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        // Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
            //angular.element(document.body).find('#overlay').remove();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }

    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    // This function will call on click of pager and fetches the biostrattop data based on the current filter.    
    $rootScope.interbiostrattoppager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
        if (window.drawPolygon) {
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
        }
        $scope.Biostrattopsitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;

        //Form the request object
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
            "Interpretive", "BioStratTops", $scope.clickedpage, "20", "", "", "")

        // Calling http service request to get biostrattop data        
        $http(request).then(successCallback, errorCallback);
    }

});

