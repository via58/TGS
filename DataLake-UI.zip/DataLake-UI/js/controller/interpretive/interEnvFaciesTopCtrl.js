/*
File Name:- interEnvFaciesTopCtrl.js
Summary:- Fetch the EnvFacies Tops details based on the filter string.
*/

angular.module('TGSApp').controller('interEnvFaciesTopCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, InterpretiveService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    // This function fetches the EnvFacies Tops data based on the current filter. 
    $rootScope.interEnvFaciesTops = function () {
        $scope.EnvironmentFaciesTopsitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";
            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

            //var environmentFaciesToptaburl = "getDetailInfo?tabName=EnvironmentFaciesTops&module=Interpretive&pageNumber=0&pageSize=20";
            // Below function will loads clusters in Map with respect to current filter string.
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, InterpretiveService.ipQueryBuilder, "", "", "");

            //Form the request object
            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
                "Interpretive", "EnvironmentFaciesTops", "0", "20", "", "", "")

            // Calling http service request to get EnvFacies Tops data             
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.EnvironmentFaciesTopsitems = response.data.content;
            $scope.EnvironmentFaciesTopscount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.EnvironmentFaciesTopsPagesCount = response.data.totalElements;    //Assigning total elements count
            }
            else {
                $scope.EnvironmentFaciesTopsPagesCount = 10000;
            }
        }
        else {
            $scope.EnvironmentFaciesTopsitems = [];
            $scope.EnvironmentFaciesTopsPagesCount = 0;
            $scope.EnvironmentFaciesTopscount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
            angular.element(document.body).find('.pagerspinner').remove();
        }, 1500);
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    //  This function will fetch the EnvFacies Tops data on click of pager.
    $rootScope.interEnvFaciesToppager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";
        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        $scope.EnvironmentFaciesTopsitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;

        //Form the request object
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, "", "", "",
            "Interpretive", "EnvironmentFaciesTops", $scope.clickedpage, "20", "", "", "")

        // Calling http service request to get EnvFacies Tops data         
        $http(request).then(successCallback, errorCallback);
    }

});