/*
File Name:- tgsSearchCtrl.js
Summary:- Performs global search in Home screen and fetch the Seismic/well data based on search text.
*/

angular.module('TGSApp').controller('tgsSearchCtrl', function ($scope, $location, $rootScope, WellService, SurveyService, $http, $sce, limitToFilter, Common) {
  $scope.selected = undefined;
  $scope.searchInprogress = false;

  //This method will call on select of any field in Home globle search
  $scope.onsearchSelect = function ($item, $model, $label) {
    if ($item.displayText !== "No result found") {
      angular.element('.surveySummaryPanel').hide();
      $scope.fieldname = $model.field;
      $scope.fieldval = $model.value;
      if (angular.element(document).find('.tools-section').find('.btn-group').find('label.active').text() == "SURVEY") {
        //Checks if any existing field values is selected or not. If it exist, show duplicate message popup.
        for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
          var checkSurvey = $rootScope.surveyselectedValArr[i];
          for (var j = 0; j < checkSurvey.value.length; j++) {
            if (checkSurvey.value[j] == $scope.fieldval && $scope.fieldname == checkSurvey.title) {
              $.alertable.alert("This " + $scope.fieldname + ": '" + $scope.fieldval + "' is already applied in filter.");
              $scope.result = "";
              return false;
            }
          }

        }

        if (SurveyService.allSurveyFilter == "") {
          //Encodes the selectd value and add it to filter string.          
          SurveyService.allSurveyFilter = $scope.fieldname + ":" + $scope.fieldval;

          //Add the selectd field object in seoected fields list. 
          $rootScope.surveycollectFilterData($scope.fieldname, $scope.fieldval, $scope.fieldname);
          var obj = new Object();
          obj.value = [$scope.fieldval];
          obj.title = $scope.fieldname;
          obj.fgname = "sfcommon";

          $rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;
          $rootScope.surveyaplFilterData[$rootScope.surveyaplFilterData.length] = $scope.fieldval;
        }
        else {
          //Checks if field name is exist filter string or not. If it exist add it to filter string.
          if (SurveyService.allSurveyFilter.includes($scope.fieldname)) {
            for (var s = 0; s < $rootScope.surveyselectedValArr.length; s++) {
              if ($rootScope.surveyselectedValArr[s].title == $scope.fieldname) {
                $rootScope.surveyselectedValArr[s].value.push($scope.fieldval)
                var oldfilterval = $rootScope.surveyaplFilterData[s];
                $rootScope.surveyaplFilterData[s] = $rootScope.surveyaplFilterData[s] + "," + $scope.fieldval;
                var newfilterval = $rootScope.surveyaplFilterData[s];
                //Replace the old filter value with new filter value and old filter value.                
                var filterStr = SurveyService.allSurveyFilter.replace(oldfilterval, newfilterval);
                SurveyService.allSurveyFilter = filterStr;
              }
            }

          }
          else {
            //Adding the selected value filter to existing filter string.            
            SurveyService.allSurveyFilter = SurveyService.allSurveyFilter + " AND " + $scope.fieldname + ":" + $scope.fieldval;


            $rootScope.surveycollectFilterData($scope.fieldname, $scope.fieldval, $scope.fieldname);
            var obj = new Object();
            obj.value = [$scope.fieldval];
            obj.title = $scope.fieldname;
            obj.fgname = "sfcommon";

            $rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;
            $rootScope.surveyaplFilterData[$rootScope.surveyaplFilterData.length] = $scope.fieldval;

          }
        }
        //Loads the Survey details for the current filter.
        $rootScope.loadSurveyDetails();
        //Zoom to Survey area in Map
        $rootScope.$broadcast("event:zoomToSurveyByName", { surveyName: $scope.fieldval }); 
      }
      else {
        //Checks if any existing field values is selected or not. If it exist, show duplicate message popup.
        for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
          var checkWell = $rootScope.selectedValArr[i];
          for (var j = 0; j < checkWell.value.length; j++) {
            if (checkWell.value[j] == $scope.fieldval && $scope.fieldname == checkWell.title) {
              $.alertable.alert("This " + $scope.fieldname + ": '" + $scope.fieldval + "' is already applied in filter.");

              $scope.result = "";
              return false;
            }
          }
        }

        //Encodes the selectd value and add it to filter string.
        if (WellService.allWellFilter == "") {
          WellService.allWellFilter =  $scope.fieldname + ":" + $scope.fieldval;
        }
        else {          
          WellService.allWellFilter = WellService.allWellFilter + " AND " + $scope.fieldname + ":" + $scope.fieldval;
        }
        //Commented - cascading is not requird for searchabel fields in Well Metadata
        ///if ($scope.fieldname == "Wellname")
        //{
          //Loading the well Metadata filter values based on Wellname 
          //$rootScope.wellhometoDetailCascade($scope.fieldname);
        //}
          $rootScope.collectFilterData($scope.fieldname, $scope.fieldval, $scope.fieldname);

        var obj = new Object();
        obj.value = [$scope.fieldval];
        obj.title = $scope.fieldname;
        obj.fgname = "wfcommon";

        $rootScope.selectedValArr[$rootScope.selectedValArr.length] = obj;

        $rootScope.aplFilterData[$rootScope.aplFilterData.length] = $scope.fieldval;

        $rootScope.loadWellDetails();
      }
      setTimeout(function () {
        $rootScope.showAppliedtxt();
      }, 1400)

    }
    $scope.result = "";
  };

  $scope.searchData = function (title) {
    if (title.length > 2) {
      $scope.searchInprogress = true;
      $scope.searchResult = [];
      var serviceUrl = "getSearchEntries";
      var moduleName="";

      if (angular.element(document).find('.tools-section').find('.btn-group').find('label.active').text() == "SURVEY") {        
        moduleName = "Seismic";        
      }
      else {       
        moduleName = "Well";       
      }      
      //Form paramInfo
      var paramInfo = {
        searchStr: title,
        module: moduleName,
        requestTimestamp : Common.getCurrentDateTime(),
        token: $rootScope.sessionToken,
        access_token: $rootScope.accessToken
      }
      paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
      var paramInfoList = $.param(paramInfo);
      //Form post request
      var request = {
        method: 'POST',
        url: SurveyService.urlValue + serviceUrl,
        data: paramInfoList,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded'  }
      }
      
      //return $http.get($sce.trustAsResourceUrl(searchurl))
      return $http(request)
        .then(function (response) {
          if (response.data !== undefined && response.data !== "") {
            angular.forEach(response.data, function (value, key1) {
              angular.forEach(value, function (val, key) {

                $scope.searchResult.push({ "value": val, "field": key1, "displayText": val + " (" + key1 + ")" });
              });
            });
          }

          if ($scope.searchResult.length == 0)
            $scope.searchResult.push({ "displayText": "No result found" });
          $scope.searchInprogress = false;
          return limitToFilter($scope.searchResult, 1000);
        });
    }
  };

  $rootScope.showHome = function () {

    $rootScope.callFromHomePage = false;
    window.fromwell = false;
    $location.path('/homeView');
    angular.element('.sub-header').find('.showhome').hide();
    WellService.allWellInfoService = WellService.homeUrl;
    $rootScope.curTab = "home";
    angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
    $rootScope.latlongType = "SurfaceLatLong";
    //Set uuid empty while coming from detail to home
    $rootScope.uuid = "";

    for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
      if ($rootScope.selectedValArr[i].title == "SeismictoWellSwitch")
        $rootScope.selectedValArr.splice(i, 1);
    }

    for (j = 0; j < $rootScope.surveyselectedValArr.length; j++) {
      if ($rootScope.surveyselectedValArr[j].title == "WelltoSurveySwitch")
        $rootScope.surveyselectedValArr.splice(j, 1);
    }

    for (k = 0; k < $rootScope.surveyselectedFieldsDetails.length; k++) {
      if ($rootScope.surveyselectedFieldsDetails[k].fieldName == "WelltoSurveySwitch")
        $rootScope.surveyselectedFieldsDetails.splice(k, 1);
    }

    for (l = 0; l < $rootScope.selectedFieldsDetails.length; l++) {
      if ($rootScope.selectedFieldsDetails[l].fieldName == "SeismictoWellSwitch")
        $rootScope.selectedFieldsDetails.splice(l, 1);
    }


    if (angular.element(document).find('.applied-form-control').find('span:first-child').text() == "") {
      WellService.allWellFilter = "";
      WellService.wellQueryBuilder = "";
    }
    setTimeout(function () {
      angular.element(document).find('.Wellfltrgrp').addClass('hide');
      angular.element(document).find('.Iprtvegrp').addClass('hide');
      angular.element(document).find('.Seismicfltrdetgrp').addClass('hide');
      angular.element(document).find('.Wellfltrdetgrp').addClass('hide');
      angular.element(document).find('.Seismicfltrgrp').removeClass('hide');
      $rootScope.filterNameGroup = "Seismic";
      angular.element(document).find('.sub-header').find('.imaginary_container').show();
      angular.element(document).find('.mapSidepanel').hide();
      angular.element(document).find('.mapSidepanelbtn').hide();

      angular.element('.sub-header').find('.importmapicon').show();


      $rootScope.refreshWells();
      switch ($rootScope.filterNameForNavigation) {
        case "SEISMIC":
          angular.element(document).find('.surveyclass').click();
          $rootScope.filterNameGroup = "Seismic";
          $rootScope.$broadcast("event:applySeismicFilters", { SurveyNames: window.mapallSurveyname });
          angular.element('.surveyappliedgrp').find('.applied-filter-group').each(function () {
            if (angular.element(this).find('.detail-view-label').text() == "WelltoSurveySwitch") {
              angular.element(this).find('.detail-view-label').parent().parent().hide()

            }
          });
          break;
        case "INTERPRETIVE":
          angular.element(document).find('.wellclass').click();
          $rootScope.filterNameGroup = "Well";
          $rootScope.$broadcast("event:applyWellFilters", { filterInfo: $rootScope.selectedFieldsDetails });
          angular.element('.wellappliedgrp').find('.applied-filter-group').each(function () {
            if (angular.element(this).find('.detail-view-label').text() == "SeismictoWellSwitch") {
              angular.element(this).find('.detail-view-label').parent().parent().hide()

            }
          });
          break;
        case "WELLS":
          angular.element(document).find('.wellclass').click();
          $rootScope.filterNameGroup = "Well";
          $rootScope.$broadcast("event:applyWellFilters", { filterInfo: $rootScope.selectedFieldsDetails });
          angular.element('.wellappliedgrp').find('.applied-filter-group').each(function () {
            if (angular.element(this).find('.detail-view-label').text() == "SeismictoWellSwitch") {
              angular.element(this).find('.detail-view-label').parent().parent().hide()

            }
          });
          break;
        default:
          break;
      }


      $rootScope.showAppliedtxt();
    }, 1000);
    angular.element('.surveyappliedgrp').show();
    angular.element('.wellappliedgrp').hide();

  }
});


