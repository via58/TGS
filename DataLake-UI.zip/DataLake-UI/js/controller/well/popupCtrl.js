angular.module('TGSApp').controller('popupCtrl', function ($scope) {    
   
     $scope.minVal = "";
     $scope.maxVal = "";
    $scope.ApplyVal = function(){        
        
        if($scope.minVal !== undefined && $scope.maxVal !== undefined)
        {         
            $scope.rangeVal = "";
            if ($scope.minVal == "" && $scope.maxVal == "") {
                $scope.rangeVal = ""
            }
            else if ($scope.minVal !== "" && $scope.maxVal == "") {
                $.alertable.alert('Please enter Max value.');
                    return false;
            }
            else if ($scope.minVal == "" && $scope.maxVal !== "")   {
                $.alertable.alert('Please enter Min value');
                return false;
            }
            else {
                if(parseFloat($scope.minVal) > parseFloat($scope.maxVal))
			    {
                    $.alertable.alert('Max value should be greater than Min value');
                    return false;
			    }
                $scope.rangeVal = $scope.minVal + " to " + $scope.maxVal;
            }
            $scope.minVal = "";
            $scope.maxVal = "";
        }
        angular.element(document).find(".popover").hide();
    }        

    $scope.validateNumericRange = function(evt,txt){
        var curField = angular.element(evt.currentTarget);
        var num = curField.val();
       var charCode = (evt.which) ? evt.which : evt.keyCode
       if (charCode > 31 && charCode !== 45 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8))
       {
           evt.preventDefault();
       }
       else {			
           var index = num.indexOf('.');
           if (index >= 0  && charCode == 46) {
               evt.preventDefault();
           }
           var mindex = num.indexOf('-');
           if (mindex >= 0  && charCode == 45) {
               evt.preventDefault();
           }
           //Allow minus at first position of textbox value
			if (charCode == 45 && curField[0].selectionStart !== 0) {
				evt.preventDefault();
			}
       }
    }
    
})
.directive('popover', function($compile){
    return {
        restrict : 'A',
        link : function(scope, elem){
            
            var content = angular.element("#popover-content").html();
            var compileContent = $compile(content)(scope);
            var title = angular.element("#popover-head").html();
            var options = {
                content: compileContent,
                html: true,
                title: title
            };            
            angular.element(elem).popover(options);
        }
    }
});