/*
File Name:- multiSelectCtrl.js
Summary:- This page will collects the Meta Data fields, form filter string to fetch the Well details .
*/

angular.module('TGSApp').controller('multiSelectCtrl', function ($scope, $rootScope, $http, $timeout, $interval, $compile, WellService, Common) {
	$rootScope.tmArr = [];

	angular.element('.Wellfltrgrp').addClass('hide');
	$scope.hasQuerybuilder = false;;
	//Well

	$scope.cntrys = [];
	$scope.selectedcntry = [];
	$scope.countys = [];
	$scope.selectedcounty = [];
	$scope.oshore = [];
	$scope.selectedoshore = [];
	$scope.states = [];
	$scope.selectedstate = [];
	$scope.sections = [];
	$scope.selectedsection = [];

	$scope.townships = [];
	$scope.selectedtownship = [];
	$scope.ranges = [];
	$scope.selectedrage = [];
	$scope.surfacearea = [];
	$scope.selectedsurface = []
	$scope.surfaceareablock = [];
	$scope.selectedsurfaceblock = [];
	$scope.bottomarea = [];
	$scope.selectedbottomarea = [];
	$scope.bottomblock = [];
	$scope.selectedbottomblock = []
	$scope.uwilist = [];
	$scope.selecteduwi = [];
	$scope.wellnames = [];
	$scope.selectedwell = [];
	$scope.wellnumbers = [];
	$scope.selectedwellnumber = [];
	$scope.wellIDs = [];
	$scope.selectedwellid = [];
	$scope.operators = [];
	$scope.selectedoperator = [];
	$scope.totaldepth = [];
	$scope.selectedtd = []

	$rootScope.aplFilter = []
	$rootScope.selectedFieldsDetails = [];
	$scope.cntrys = [];
	$rootScope.aplFilterData = [];

	$(function () {

		$('input[name="datefilter"]').daterangepicker({
			autoUpdateInput: false,
			showDropdowns: true,
			locale: {
				cancelLabel: 'Clear'
			}
		});

		$('input[name="datefilter"]').on('apply.daterangepicker', function (ev, picker) {
			$(this).val(picker.startDate.format('YYYY/MM/DD') + ' - ' + picker.endDate.format('YYYY/MM/DD'));
		});

		$('input[name="datefilter"]').on('cancel.daterangepicker', function (ev, picker) {
			$(this).val('');
		});

	});

	//Below function will get the state details based on selected filterName 
	$scope.getStatesForCountry = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//var serviceurl = "getFieldDistinctValuesFilter?source=StateName";
			var request = Common.getWellPostRequest(source = "StateName", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.states = $scope.fillData(response.data.resultList, "StateName", "StateName");
				}).catch(function (response) {
				});
		}

		else {
			//var serviceurl = "getFieldDistinctValuesFilter?source=StateName&filterStr=" + filterName + ":" + filterValueList;
			var request = Common.getWellPostRequest(source = "StateName", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					if (response.data.resultList.length == 0) {
						$scope.states = [];
					}
					else {
						$scope.states = $scope.fillData(response.data.resultList, "StateName", "StateName");
					}
				}).catch(function (response) {
				});
		}
	}

	//Below function will get the County details based on selected filterName 
	$scope.getCountyData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "CountyName", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.countys = $scope.fillData(response.data.resultList, "CountyName", "CountyName");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "CountyName", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.countys = $scope.fillData(response.data.resultList, "CountyName", "CountyName");
				}).catch(function (response) {
				});
		}
	}

	//Below function will get the Section details based on selected filterName 
	$scope.getSectionsData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "GeoSection", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.sections = $scope.fillData(response.data.resultList, "GeoSection", "GeoSection");
				}).catch(function (response) {

				});
		}
		else {
			var request = Common.getWellPostRequest(source = "GeoSection", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.sections = $scope.fillData(response.data.resultList, "GeoSection", "GeoSection");
				}).catch(function (response) {
				});
		}
	}

	//Below function will get the Township details based on selected filterName 
	$scope.getTownshipData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "Township", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.townships = $scope.fillData(response.data.resultList, "Township", "Township");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "Township", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.townships = $scope.fillData(response.data.resultList, "Township", "Township");
				}).catch(function (response) {
				});
		}
	}

	//Below function will get the Range details based on selected filterName 
	$scope.getRangeData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "Range", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.ranges = $scope.fillData(response.data.resultList, "Range", "Range");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "Range", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.ranges = $scope.fillData(response.data.resultList, "Range", "Range");
				}).catch(function (response) {
				});

		}
	}

	//Below function will get the Sruface Area details based on selected filterName 
	$scope.getSrufaceAreaData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "SurfArea", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.surfacearea = $scope.fillData(response.data.resultList, "SurfArea", "SurfArea");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "SurfArea", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.surfacearea = $scope.fillData(response.data.resultList, "SurfArea", "SurfArea");
				}).catch(function (response) {
				});
		}
	}

	//Below function will get the Sruface Block details based on selected filterName 
	$scope.getSrufaceBlockData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "SurfBlock", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.surfaceareablock = $scope.fillData(response.data.resultList, "SurfBlock", "SurfBlock");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "SurfBlock", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.surfaceareablock = $scope.fillData(response.data.resultList, "SurfBlock", "SurfBlock");
				}).catch(function (response) {
				});
		}
	}

	//Below function will get the Bottom Area details based on selected filterName 
	$scope.getBotmAreaData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "BotmArea", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.bottomarea = $scope.fillData(response.data.resultList, "BotmArea", "BotmArea");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "BotmArea", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.bottomarea = $scope.fillData(response.data.resultList, "BotmArea", "BotmArea");
				}).catch(function (response) {
				});
		}
	}

	//Below function will get the Bottom Block details based on selected filterName 
	$scope.getBotmBlockData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "BotmBlock", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.bottomblock = $scope.fillData(response.data.resultList, "BotmBlock", "BotmBlock");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "BotmBlock", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.bottomblock = $scope.fillData(response.data.resultList, "BotmBlock", "BotmBlock");
				}).catch(function (response) {
				});
		}
	}

	$scope.getUWIData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "UWI", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.uwilist = $scope.fillData(response.data.resultList, "UWI", "UWI");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "UWI", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.uwilist = $scope.fillData(response.data.resultList, "UWI", "UWI");
				}).catch(function (response) {
				});
		}
	}
	//Below function will get the Wellname details based on selected filterName 
	$scope.getWellnameData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "Wellname", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.wellnames = $scope.fillData(response.data.resultList, "Wellname", "Wellname");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "Wellname", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.wellnames = $scope.fillData(response.data.resultList, "Wellname", "Wellname");
				}).catch(function (response) {
				});

		}

	}

	//Below function will get the Well number details based on selected filterName 
	$scope.getWellNumberData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "WellnbrTxt", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.wellnumbers = $scope.fillData(response.data.resultList, "WellNumber", "WellNumber");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "WellnbrTxt", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.wellnumbers = $scope.fillData(response.data.resultList, "WellNumber", "WellNumber");
				}).catch(function (response) {
				});

		}
	}

	//Below function will get the WellId details based on selected filterName 
	$scope.getWellIdData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "WellID", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.wellIDs = $scope.fillData(response.data.resultList, "WellID", "WellID");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "WellID", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.wellIDs = $scope.fillData(response.data.resultList, "WellID", "WellID");
				}).catch(function (response) {
				});
		}

	}

	//Below function will get the Operator details based on selected filterName 
	$scope.getOperatorData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			var request = Common.getWellPostRequest(source = "Operator", filterStr = "", "")
			$http(request).
				then(function (response) {
					$scope.operators = $scope.fillData(response.data.resultList, "Operator", "Operator");
				}).catch(function (response) {
				});
		}
		else {
			var request = Common.getWellPostRequest(source = "Operator", filterStr = filterName + ":", filterValueList)
			$http(request).
				then(function (response) {
					$scope.operators = $scope.fillData(response.data.resultList, "Operator", "Operator");
				}).catch(function (response) {
				});
		}

	}

	//Below function will call when a value is selected in meta data filters. 
	$scope.serviceCall = function (selectedField, checkedValue) {

		var flag = checkDuplicateValue(selectedField.model, checkedValue);
		//If any duplicate value is selected, shows the below popup.
		if (flag) {
			$.alertable.alert("Filter value '" + selectedField.model.name + "' is already exist in applied filter");
			return false;
		}

		//Below methid will collects the selected meta data values
		if (checkedValue) {
			$rootScope.collectFilterData(selectedField.model.fieldName, selectedField.model.name, selectedField.model.titleName, checkedValue);
		}
		else {
			//Below methid will removed the unselected meta data values
			$rootScope.removeData(selectedField.model.fieldName, selectedField.model.name);
		}
		//Cascading filter values
		//Loads the metadata values based on filter values
		$scope.cascadeWellFilterData(selectedField.model.fieldName, $rootScope.selectedFieldsDetails, false);
	}

	//Loads the Meta data values based the parent value selected
	$rootScope.cascadeWellFilterData = function (fieldName, selectedFields, isfromApplFilter) {
		var selectedFieldDetails = selectedFields;

		if (isfromApplFilter && selectedFieldDetails.length == 0) {
			var filterVal = "";
			$scope.getStatesForCountry(filterVal, "CountryName");
			$scope.getCountyData(filterVal, "CountryName");
			$scope.getSectionsData(filterVal, "CountryName");
			$scope.getTownshipData(filterVal, "CountryName");
			$scope.getRangeData(filterVal, "CountryName");
			$scope.getSrufaceAreaData(filterVal, "CountryName");
			$scope.getSrufaceBlockData(filterVal, "CountryName");
			$scope.getBotmAreaData(filterVal, "CountryName");
			$scope.getBotmBlockData(filterVal, "CountryName");
			return;
		}

		if (fieldName == "CountryName") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "CountryName") {
					$scope.getStatesForCountry(filterVal, "CountryName");
					$scope.getCountyData(filterVal, "CountryName");
					$scope.getSectionsData(filterVal, "CountryName");
					$scope.getTownshipData(filterVal, "CountryName");
					$scope.getRangeData(filterVal, "CountryName");
					$scope.getSrufaceAreaData(filterVal, "CountryName");
					$scope.getSrufaceBlockData(filterVal, "CountryName");
					$scope.getBotmAreaData(filterVal, "CountryName");
					$scope.getBotmBlockData(filterVal, "CountryName");


				}
			}
		}
		//State Cascading - Load County,Section and Township
		else if (fieldName == "StateName") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "StateName") {
					$scope.getCTSforState(filterVal);
					$scope.getRangeData(filterVal, "StateName");
					$scope.getSrufaceAreaData(filterVal, "StateName");
					$scope.getSrufaceBlockData(filterVal, "StateName");
					$scope.getBotmAreaData(filterVal, "StateName");
					$scope.getBotmBlockData(filterVal, "StateName");


				}
			}
		}

		else if (fieldName == "CountyName") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}
				if (fName == "CountyName") {
					$scope.getSectionsData(filterVal, "CountyName");
					$scope.getTownshipData(filterVal, "CountyName");
					$scope.getRangeData(filterVal, "CountyName");
					$scope.getSrufaceAreaData(filterVal, "CountyName");
					$scope.getSrufaceBlockData(filterVal, "CountyName");
					$scope.getBotmAreaData(filterVal, "CountyName");
					$scope.getBotmBlockData(filterVal, "CountyName");

				}
			}
		}

		else if (fieldName == "GeoSection") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "GeoSection") {
					$scope.getTownshipData(filterVal, "GeoSection");
					$scope.getRangeData(filterVal, "GeoSection");
					$scope.getSrufaceAreaData(filterVal, "GeoSection");
					$scope.getSrufaceBlockData(filterVal, "GeoSection");
					$scope.getBotmAreaData(filterVal, "GeoSection");
					$scope.getBotmBlockData(filterVal, "GeoSection");
				}
			}
		}

		else if (fieldName == "Township") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "Township") {
					$scope.getRangeData(filterVal, "Township");
					$scope.getSrufaceAreaData(filterVal, "Township");
					$scope.getSrufaceBlockData(filterVal, "Township");
					$scope.getBotmAreaData(filterVal, "Township");
					$scope.getBotmBlockData(filterVal, "Township");
				}
			}
		}

		else if (fieldName == "Range") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "Range") {
					$scope.getSrufaceAreaData(filterVal, "Township");
					$scope.getSrufaceBlockData(filterVal, "Township");
					$scope.getBotmAreaData(filterVal, "Township");
					$scope.getBotmBlockData(filterVal, "Township");
				}
			}
		}
		//Upto Range values need to fill UWI,WellName,WellNumber,WellId and Operator
		else if (fieldName == "SurfArea") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "SurfArea") {
					$scope.getSrufaceBlockData(filterVal, "SurfArea");
					$scope.getBotmAreaData(filterVal, "SurfArea");
					$scope.getBotmBlockData(filterVal, "SurfArea");
				}
			}
		}

		else if (fieldName == "SurfBlock") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "SurfBlock") {
					$scope.getBotmAreaData(filterVal, "SurfBlock");
					$scope.getBotmBlockData(filterVal, "SurfBlock");
				}
			}
		}

		else if (fieldName == "BotmArea") {
			for (var i = 0; i < selectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = selectedFieldDetails[i].fieldName;
					var filterVal = selectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "BotmArea") {
					$scope.getBotmBlockData(filterVal, "BotmArea");
				}
			}
		}

	}

	//Loads the Well Metadata filter values
	$rootScope.loadFilterData = function () {
		angular.element(document).find('#LabelFilter').addClass('hide');
		angular.element(document).find('#Loading').removeClass('hide');

		//Form Post request for all Well Geography Metadata filter combo values
		var paramInfo = {
			requestTimestamp: Common.getCurrentDateTime(),
			token: $rootScope.sessionToken,
			access_token: $rootScope.accessToken
		}
		paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
		paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

		var paramInfoList = $.param(paramInfo);

		var request = {
			method: 'POST',
			data: paramInfoList,
			url: WellService.urlValue + WellService.allGeographyData,
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
		}
		$http(request).
			then(function (response) {
				let geographyData = response.data;

				$scope.cntrys = $scope.fillData(geographyData.countryNamesList, "CountryName", "CountryName");
				$scope.states = $scope.fillData(geographyData.stateNamesList, "StateName", "StateName");
				$scope.sections = $scope.fillData(geographyData.geoSectionList, "GeoSection", "GeoSection");
				$scope.townships = $scope.fillData(geographyData.townshipList, "Township", "Township");
				$scope.ranges = $scope.fillData(geographyData.rangeList, "Range", "Range");
				$scope.surfaceareablock = $scope.fillData(geographyData.surfBlockList, "SurfBlock", "SurfBlock");
				$scope.surfacearea = $scope.fillData(geographyData.surfaceAreaList, "SurfArea", "SurfArea");
				$scope.bottomarea = $scope.fillData(geographyData.botmAreaList, "BotmArea", "BotmArea");
				$scope.bottomblock = $scope.fillData(geographyData.botmBlockList, "BotmBlock", "BottomBlock");
				$scope.countys = $scope.fillData(geographyData.countyNamesList, "CountyName", "CountyName");

				$scope.selectedFieldsDetails = [];
				angular.element(document).find('#Loading').addClass('hide');
				angular.element(document).find('#LabelFilter').removeClass('hide');

			}).catch(function (response) {
				angular.element(document).find('#Loading').addClass('hide');
				angular.element(document).find('#LabelFilter').removeClass('hide');
			});

		angular.element(document).find('#LabelFilter').addClass('hide');
		angular.element(document).find('#Loading').removeClass('hide');

		var paramInfo = {
			module: "Well",
			requestTimestamp: Common.getCurrentDateTime(),
			token: $rootScope.sessionToken,
			access_token: $rootScope.accessToken
		}

		paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
		paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
		var paramInfoList = $.param(paramInfo);

		var request = {
			method: 'POST',
			url: WellService.urlValue + WellService.EntitlementWellurl,
			data: paramInfoList,
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
		}

		$http(request).
			then(function (response) {
				var wellCustomers = $scope.EntitlementtFillData(response.data.content, "CustomerName", "CustomerName");
				var wellCustomeroption = '';
				for (var i = 0; i < wellCustomers.length; i++) {
					wellCustomeroption = wellCustomeroption + "<option value='" + wellCustomers[i].customerId + "'>" + wellCustomers[i].name + "</option>";
				}
				angular.element('.selectedwellEntitleUser').append(wellCustomeroption);
			}).catch(function (response) {
			});
	}
	//Fills the Metadata values
	$scope.fillData = function (fieldArr, fieldName, titleName) {
		var arr = [];
		var count = 0;
		if (fieldArr !== null && fieldArr.length == 0)
			return arr;
		else {
			for (x in fieldArr) {
				if (fieldArr[x].trim() != "") {

					var obj = new Object();
					obj.id = count + 1;
					obj.name = fieldArr[x];
					obj.fieldName = fieldName;
					obj.titleName = titleName;
					obj.displayName = "";
					arr[arr.length] = obj;
					count++;
				}
			}
			return arr;
		}
	}

	//Fill the Entitlement user details
	$scope.EntitlementtFillData = function (fieldArr, fieldName, titleName) {
		var arr = [];
		if (fieldArr.length > 0) {
			for (var i = 0; i < fieldArr.length; i++) {
				if (fieldArr[i] != "") {
					var obj = new Object();
					obj.name = fieldArr[i].CustId;
					obj.customerId = fieldArr[i].CustomerId;
					obj.fieldName = fieldName;
					obj.titleName = titleName;
					obj.displayName = "";
					arr[arr.length] = obj;
				}
			}
		}
		return arr;
	}
	//Get the well Entitlement user details
	$scope.getWellCustomerData = function () {
		var sel = document.getElementById('wellent');
		var opt = sel.options[sel.selectedIndex];
		var custId = opt.value;
		var custName = opt.text;
		if (custName !== "Select Customer" && custId !== "") {
			$rootScope.wellCustomer = { customerId: custId, name: custName };
			//$scope.collectWellEntitlementData("CustomerName", $rootScope.wellCustomer, "CustomerName");
		}
	}

	//Form the Applied filter values 
	$rootScope.appliedFilterData = function () {
		for (var i = 0; ($rootScope.aplFilterData !== null && i < $rootScope.aplFilterData.length); i++) {

			if ($rootScope.aplFilterData[i] !== undefined) {

				var tempSelectedValArr = $rootScope.aplFilterData[i].split("||");
				var tempSelectedValArr1 = [];

				for (var val = 0; val < tempSelectedValArr.length; val++) {
					if (tempSelectedValArr[val] !== "" && tempSelectedValArr[val] !== null)
						tempSelectedValArr1.push(tempSelectedValArr[val]);
				}
				var obj = new Object();
				obj.value = tempSelectedValArr1;
				obj.fgname = "wfcommon";
				obj.type = "comnfilter";
				if ($rootScope.aplFilterTitle[i] !== undefined) {
					obj.title = $rootScope.aplFilterTitle[i];
				}
				else {
					obj.title = "Polygon Name";
				}
				$rootScope.selectedValArr[$rootScope.selectedValArr.length] = obj;
			}
		}

		setTimeout(function () {
			angular.element('.Wellfltrgrp').find('.dropdown-menu').find('li').find('a').find('i').removeClass('icon-ok').addClass('icon-empty');
			angular.element('.wellappliedgrp').find('.applied-filter-group').each(function () {

				var datalocation = angular.element(this).find('.detail-view-label').text();
				if (angular.element(this).find('.detail-view-label').text() == datalocation) {

					angular.element(this).find('.detail-view-list').find('.applied-form-control').each(function () {
						var datalocationinfo = angular.element(this).find('span:first').text();

						angular.element('.Wellfltrgrp').find('[data-location]').each(function () {

							if (angular.element(this).attr('data-location') == datalocation) {

								angular.element(angular.element(this)).find('.dropdown-menu li').each(function () {

									if (angular.element(this).find('a').text().trim() == datalocationinfo) {
										angular.element(this).find('a').find('i').removeClass('icon-empty').addClass('icon-ok');
									}
								});
							}
						});
					});
				}
			}
			);
		}, 3000)


	}

	//Below method will checks duplicate values for the selected filter values
	var checkDuplicateValue = function (selectedValue, checkedValue) {
		if (checkedValue) {
			for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
				var arr = $rootScope.selectedValArr[i].value;
				var title = $rootScope.selectedValArr[i].title;
				for (var j = 0; j < arr.length; j++) {
					if (arr[j] == selectedValue.name && title == selectedValue.fieldName) {
						return true;
					}
				}
			}
		}
		return false;
	}

	//CTS-County,Township and Section
	//Get the County,Township and Section for the selected states
	$scope.getCTSforState = function (stateList) {
		if (stateList == "") {
			$scope.getAllCTS();
		}
		else {
			var request = Common.getWellCTSPostRequest(source = "CountyName", filterStr = "StateName:", stateList);
			$http(request).
				then(function (response) {
					if (response.data.countyNameList.length == 0)
						$scope.countys = [];
					else
						$scope.countys = $scope.fillData(response.data.countyNameList, "CountyName", "CountyName");
					if (response.data.geoSectionList.length == 0)
						$scope.sections = [];
					else
						$scope.sections = $scope.fillData(response.data.geoSectionList, "GeoSection", "GeoSection");
					if (response.data.townShipList.length == 0)
						$scope.townships = [];
					else
						$scope.townships = $scope.fillData(response.data.townShipList, "Township", "Township");
				}).catch(function (response) {
				});
		}
	}
	//Get the all County,Township and Section values
	$scope.getAllCTS = function () {
		//var serviceurl = "getCountyAndGeoSectionAndTownShipByState?source=CountyName";		
		var request = Common.getWellCTSPostRequest(source = "CountyName", filterStr = "", "")
		$http(request).
			then(function (response) {
				$scope.countys = $scope.fillData(response.data.countyNameList, "CountyName", "CountyName");
				$scope.townships = $scope.fillData(response.data.townShipList, "Township", "Township");
				$scope.sections = $scope.fillData(response.data.geoSectionList, "GeoSection", "GeoSection");
			}).catch(function (response) {
			});
	}

	//Below method will remove the unselected Meta data values
	$rootScope.removeData = function (fieldName, fieldValue) {
		if ($rootScope.selectedFieldsDetails.length > 0) {
			for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
				if ($rootScope.selectedFieldsDetails[i].fieldName == fieldName) {
					var value = $rootScope.selectedFieldsDetails[i].fieldValue;

					var arr = value.split(",");
					var strValue = "";
					var k = 0;

					for (var n = 0; n < arr.length; n++) {

						if (!(arr[n] == fieldValue)) {
							if (k > 0) {
								strValue = strValue + "," + arr[n];
							}
							else {
								strValue = arr[n];
							}

							k++;
						}
					}
					$rootScope.selectedFieldsDetails[i].fieldValue = strValue;
					$rootScope.selectedFieldsDetails[i].displayName = strValue;
				}
			}
		}
	}

	//Collects the selected Metadata Filter values
	$rootScope.collectFilterData = function (fieldName, fieldValue, titleName) {
		var fval = fieldValue;
		if (fieldName !== "SurfaceLatLong")
			fieldValue = fieldValue.includes(',') ? fieldValue.replace(',', '~~') : fieldValue;
		if ($rootScope.selectedFieldsDetails.length > 0) {
			var flag = true;

			for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
				if ($rootScope.selectedFieldsDetails[i].fieldName == fieldName) {
					if ($rootScope.selectedFieldsDetails[i].fieldValue != "") {
						$rootScope.selectedFieldsDetails[i].fieldValue = $rootScope.selectedFieldsDetails[i].fieldValue + "," + fieldValue;
						$rootScope.selectedFieldsDetails[i].displayName = $rootScope.selectedFieldsDetails[i].displayName + "||" + fval;
					}
					else {
						$rootScope.selectedFieldsDetails[i].fieldValue = fieldValue;
						$rootScope.selectedFieldsDetails[i].displayName = fval;
					}

					flag = false;
					break;
				}
			}
			if (flag) {
				var obj = new Object();
				obj.fieldName = fieldName;
				obj.fieldValue = fieldValue;
				obj.titleName = titleName;
				obj.displayName = fval;
				$rootScope.selectedFieldsDetails[$rootScope.selectedFieldsDetails.length] = obj;
			}
		}

		else {
			var obj = new Object();
			obj.fieldName = fieldName;
			obj.fieldValue = fieldValue;
			obj.titleName = titleName;
			obj.displayName = fval;
			$rootScope.selectedFieldsDetails[$rootScope.selectedFieldsDetails.length] = obj;
		}
	}

	//Below function will form the Filter String to fetch the data.
	$rootScope.formFilter = function () {
		if ($rootScope.filterNameGroup == "Well") {
			var wellfilterStr = "";
			$rootScope.aplFilterData = [];
			$rootScope.aplFilterTitle = [];
			for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
				if (i == 0) {
					if ($rootScope.selectedFieldsDetails[i].fieldValue !== "" && $rootScope.selectedFieldsDetails[i].fieldName !== "CustomerName"
						&& $rootScope.selectedFieldsDetails[i].fieldName !== "SeismictoWellSwitch") {
						if ($rootScope.selectedFieldsDetails[i].fieldName == "CompletionDate" || $rootScope.selectedFieldsDetails[i].fieldName == "SpudDate" || $rootScope.selectedFieldsDetails[i].fieldName == "TDdate") {
							var tempDate = $rootScope.selectedFieldsDetails[i].fieldValue.split(' to ');
							var startTempDate = tempDate[0].trim();
							var endTempDate = tempDate[1].trim();
							wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate + " 00:00:00.0";
						}
						else {
							if ($rootScope.selectedFieldsDetails[i].fieldName == "Range") {
								var filterVal = $rootScope.selectedFieldsDetails[i].fieldValue;
								if (filterVal.includes('lte:') || filterVal.includes('gte:')) {
									wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + filterVal;
								}
								else {
									filterVal = filterVal.replace(' to ', '<<');
									wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + "btw" + ":" + filterVal;
								}
							}
							else {
								wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + $rootScope.selectedFieldsDetails[i].fieldValue;
							}
						}
					}
				}
				else {
					if ($rootScope.selectedFieldsDetails[i] !== "" && $rootScope.selectedFieldsDetails[i].fieldValue !== "" && $rootScope.selectedFieldsDetails[i].fieldName !== "CustomerName"
						&& $rootScope.selectedFieldsDetails[i].fieldName !== "SeismictoWellSwitch") {
						if (wellfilterStr == "") {
							if ($rootScope.selectedFieldsDetails[i].fieldName == "CompletionDate" || $rootScope.selectedFieldsDetails[i].fieldName == "SpudDate" || $rootScope.selectedFieldsDetails[i].fieldName == "TDdate") {
								var tempDate = $rootScope.selectedFieldsDetails[i].fieldValue.split(' to ');
								var startTempDate = tempDate[0].trim();
								var endTempDate = tempDate[1].trim();
								wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate + " 00:00:00.0";
							}
							else {
								if ($rootScope.selectedFieldsDetails[i].fieldName == "Range") {
									var filterVal = $rootScope.selectedFieldsDetails[i].fieldValue;
									if (filterVal.includes('lte:') || filterVal.includes('gte:')) {
										wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + filterVal;
									}
									else {
										filterVal = filterVal.replace(' to ', '<<');
										wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + "btw" + ":" + filterVal;
									}
								}
								else {
									wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + $rootScope.selectedFieldsDetails[i].fieldValue;
								}
							}
						}
						else {
							if ($rootScope.selectedFieldsDetails[i].fieldName !== "SeismictoWellSwitch") {
								if ($rootScope.selectedFieldsDetails[i].fieldName == "CompletionDate" || $rootScope.selectedFieldsDetails[i].fieldName == "SpudDate" || $rootScope.selectedFieldsDetails[i].fieldName == "TDdate") {
									var tempDate = $rootScope.selectedFieldsDetails[i].fieldValue.split(' to ');
									var startTempDate = tempDate[0].trim();
									var endTempDate = tempDate[1].trim();
									wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate + " 00:00:00.0";
								}
								else {
									if ($rootScope.selectedFieldsDetails[i].fieldName == "Range") {
										var filterVal = $rootScope.selectedFieldsDetails[i].fieldValue;
										if (filterVal.includes('lte:') || filterVal.includes('gte:')) {
											wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":" + filterVal;
										}
										else {
											filterVal = filterVal.replace(' to ', '<<');
											wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":" + "btw" + ":" + filterVal;
										}
									}
									else {
										wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":" + $rootScope.selectedFieldsDetails[i].fieldValue;
									}
								}
							}
						}
					}
				}
				if ($rootScope.selectedFieldsDetails[i].fieldValue !== "") {
					if ($rootScope.selectedFieldsDetails[i].fieldName !== "CustomerName") {
						$rootScope.aplFilterData[$rootScope.aplFilterData.length] = $rootScope.selectedFieldsDetails[i].displayName;
					}
					else {
						$rootScope.aplFilterData[$rootScope.aplFilterData.length] = $rootScope.selectedFieldsDetails[i].fieldValue;
					}
					$rootScope.aplFilterTitle[$rootScope.aplFilterTitle.length] = $rootScope.selectedFieldsDetails[i].titleName;
				}
			}

			$rootScope.wellfilterstring = wellfilterStr;
			if ($rootScope.wellfilterstring != "") {
				WellService.allWellFilter = wellfilterStr;
			}
			else {
				WellService.allWellFilter = $rootScope.wellfilterstring;
			}
		}

		else if ($rootScope.filterNameGroup == "interpretive") {
			var wellfilterStr = "";
			$rootScope.aplFilterData = [];
			$rootScope.aplFilterTitle = [];
			for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
				if (i == 0) {
					if ($rootScope.selectedFieldsDetails[i].fieldValue !== "" && $rootScope.selectedFieldsDetails[i].fieldName !== "CustomerName"
						&& $rootScope.selectedFieldsDetails[i].fieldName !== "SeismictoWellSwitch") {
						if ($rootScope.selectedFieldsDetails[i].fieldName == "CompletionDate" || $rootScope.selectedFieldsDetails[i].fieldName == "SpudDate" || $rootScope.selectedFieldsDetails[i].fieldName == "TDdate") {
							var tempDate = $rootScope.selectedFieldsDetails[i].fieldValue.split(' to ');
							var startTempDate = tempDate[0].trim();
							var endTempDate = tempDate[1].trim();
							wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate + " 00:00:00.0";
						}
						else {
							if ($rootScope.selectedFieldsDetails[i].fieldName == "Range") {
								var filterVal = $rootScope.selectedFieldsDetails[i].fieldValue;
								if (filterVal.includes('lte:') || filterVal.includes('gte:')) {
									wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + filterVal;
								}
								else {
									filterVal = filterVal.replace(' to ', '<<');
									wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + "btw" + ":" + filterVal;
								}
							}
							else {
								wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + $rootScope.selectedFieldsDetails[i].fieldValue;
							}
						}
					}
				}
				else {
					if ($rootScope.selectedFieldsDetails[i] !== "" && $rootScope.selectedFieldsDetails[i].fieldValue !== "" && $rootScope.selectedFieldsDetails[i].fieldName !== "CustomerName"
						&& $rootScope.selectedFieldsDetails[i].fieldName !== "SeismictoWellSwitch") {
						if (wellfilterStr == "") {
							if ($rootScope.selectedFieldsDetails[i].fieldName == "CompletionDate" || $rootScope.selectedFieldsDetails[i].fieldName == "SpudDate" || $rootScope.selectedFieldsDetails[i].fieldName == "TDdate") {
								var tempDate = $rootScope.selectedFieldsDetails[i].fieldValue.split(' to ');
								var startTempDate = tempDate[0].trim();
								var endTempDate = tempDate[1].trim();
								wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate + " 00:00:00.0";
							}
							else {
								if ($rootScope.selectedFieldsDetails[i].fieldName == "Range") {
									var filterVal = $rootScope.selectedFieldsDetails[i].fieldValue;
									if (filterVal.includes('lte:') || filterVal.includes('gte:')) {
										wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + filterVal;
									}
									else {
										filterVal = filterVal.replace(' to ', '<<');
										wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + "btw" + ":" + filterVal;
									}
								}
								else {
									wellfilterStr = $rootScope.selectedFieldsDetails[i].fieldName + ":" + $rootScope.selectedFieldsDetails[i].fieldValue;
								}
							}
						}
						else {
							if ($rootScope.selectedFieldsDetails[i].fieldName !== "SeismictoWellSwitch") {
								if ($rootScope.selectedFieldsDetails[i].fieldName == "CompletionDate" || $rootScope.selectedFieldsDetails[i].fieldName == "SpudDate" || $rootScope.selectedFieldsDetails[i].fieldName == "TDdate") {
									var tempDate = $rootScope.selectedFieldsDetails[i].fieldValue.split(' to ');
									var startTempDate = tempDate[0].trim();
									var endTempDate = tempDate[1].trim();
									wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate + " 00:00:00.0";
								}

								else {
									if ($rootScope.selectedFieldsDetails[i].fieldName == "Range") {
										var filterVal = $rootScope.selectedFieldsDetails[i].fieldValue;
										if (filterVal.includes('lte:') || filterVal.includes('gte:')) {
											wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":" + filterVal;
										}
										else {
											filterVal = filterVal.replace(' to ', '<<');
											wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":" + "btw" + ":" + filterVal;
										}
									}
									else {
										wellfilterStr = wellfilterStr + " AND " + $rootScope.selectedFieldsDetails[i].fieldName + ":" + $rootScope.selectedFieldsDetails[i].fieldValue;
									}
								}
							}
						}
					}
				}
				if ($rootScope.selectedFieldsDetails[i].fieldValue !== "" && !($rootScope.selectedFieldsDetails[i].fieldName == "SeismictoWellSwitch")) {
					if ($rootScope.selectedFieldsDetails[i].fieldName !== "CustomerName")
						$rootScope.aplFilterData[$rootScope.aplFilterData.length] = $rootScope.selectedFieldsDetails[i].displayName;
					else
						$rootScope.aplFilterData[$rootScope.aplFilterData.length] = $rootScope.selectedFieldsDetails[i].fieldValue;

					$rootScope.aplFilterTitle[$rootScope.aplFilterTitle.length] = $rootScope.selectedFieldsDetails[i].titleName;
				}
			}

			$rootScope.wellfilterstring = wellfilterStr;
			if ($rootScope.wellfilterstring != "") {
				WellService.allWellFilter = wellfilterStr;
			}
			else {
				WellService.allWellFilter = $rootScope.wellfilterstring;
			}

		}
	}

	//Below function will collects the values of Text field and Date fields
	$rootScope.getTextAndDateVaues = function () {
		angular.element('.Wellfltrgrp').find('.customeData').each(function () {
			var control = angular.element(this);

			for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
				var checkField = $rootScope.selectedFieldsDetails[i];
				if (checkField.fieldValue !== "") {
					if (control[0].placeholder.includes('Date') && control.val() !== "") {
						var tempDateValueCheck = control.val().split('-');
						var dateValueCheck = tempDateValueCheck[0].split('/').join('-').trim() + " to " + tempDateValueCheck[1].split('/').join('-').trim();
						if (dateValueCheck == checkField.fieldValue && checkField.fieldName == control[0].placeholder) {
							$.alertable.alert("The filter '" + control[0].placeholder + " : " + checkField.fieldValue + "' is already applied.");
							return false;
						}
					}
					else if (checkField.fieldValue == control.val().trim() && checkField.fieldName == control[0].placeholder) {
						$.alertable.alert("The filter '" + control[0].placeholder + " : " + control.val().trim() + "' is already applied.");
						return false;
					}
				}
			}

			if (control.val().trim() !== "" && control.val().trim() !== null) {
				var obj = new Object();
				if (control[0].placeholder == "Range") {
					obj.fieldName = control[0].placeholder;
					obj.fieldValue = control.val().trim();
					obj.titleName = control[0].placeholder;
					obj.displayName = control.val().trim();
				}
				if (control[0].placeholder == "CompletionDate" || control[0].placeholder == "SpudDate" ||
					control[0].placeholder == "TDdate") {
					obj.fieldName = control[0].placeholder;
					var tempDate = control.val().split('-');
					obj.fieldValue = tempDate[0].split('/').join('-').trim() + " to " + tempDate[1].split('/').join('-').trim();
					obj.titleName = control[0].placeholder;
					obj.displayName = obj.fieldValue;
				}
				$rootScope.selectedFieldsDetails.push(obj);
			}
		});
	}

	//Below function will clears the Text fields and Date fields
	$rootScope.clearTextAndDateVaues = function () {
		angular.element('.Wellfltrgrp').find('input').each(function () {
			angular.element(this).val('');
		});

		angular.element('.Wellfltrdetgrp, .Seismicfltrgrp').find('input').each(function () {
			angular.element(this).val('');
		});

		angular.element('.Seismicfltrdetgrp').find('input').each(function () {
			angular.element(this).val('');
		});

	}

	//Below function will collects the Well Querybuilder data
	$rootScope.getQbWellData = function () {

		angular.element('.WellQBFieldSearch').each(function () {
			let qbSelectedWellValue = this.value;
			let titleName = this.name;
			let fieldName = this.id;
			//Checks the applied QB values and show duplicate popup message
			for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
				var checkField = $rootScope.selectedFieldsDetails[i];
				if (checkField.fieldValue !== "") {
					if (checkField.fieldValue == qbSelectedWellValue.trim() && checkField.fieldName == titleName) {
						$.alertable.alert("The filter '" + fieldName + " : " + qbSelectedWellValue + "' is already applied.");
						return false;
					}
				}
			}

			if (qbSelectedWellValue !== "" && qbSelectedWellValue !== null && qbSelectedWellValue !== undefined) {
				var obj = new Object();

				obj.fieldName = fieldName;
				obj.fieldValue = qbSelectedWellValue;
				obj.titleName = titleName;
				obj.displayName = qbSelectedWellValue;

				$rootScope.collectFilterData(obj.fieldName, obj.fieldValue, obj.titleName);
			}
		});
	}

	//Below function will collects the Well QB values 
	$rootScope.formQueryBuilder = function () {

		var queryBuilderStr = "";
		$rootScope.WellQBFilterArr = [];
		angular.element('.Wellfltrdetgrp .QueryBuilder-container .QueryBuilder-condition').each(function () {

			var LHSVal = angular.element(this).find('select:nth-child(3) option:selected').val();
			var MHSVal = angular.element(this).find('select:nth-child(4) option:selected').val();

			if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typestring')) {
				var RHSVal = angular.element(this).find('.RHSSelect').val();
			}

			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typedate')) {
				if (MHSVal == "btw") {
					var RHSVal = angular.element(this).find('.RHSDateRange').val();
					var tempDate = RHSVal.split('-');
					RHSVal = tempDate[0].split('/').join('-').trim() + " to " + tempDate[1].split('/').join('-').trim();
				}
				else {
					var RHSVal = angular.element(this).find('.RHSFielddate').val();
				}
			}

			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeRange')) {
				if (MHSVal == "btw") {
					var RHSVal = angular.element(this).find('.RHSNumRange').val();
				}
				else {
					var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
				}
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typesearch')) {
				var RHSVal = angular.element(this).find('.RHSFieldsearch').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeflag')) {
				var RHSVal = angular.element(this).find('.RHSFlg').val();
			}
			else {
				var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
			}
			var allVall = LHSVal + ":" + MHSVal + ":" + RHSVal;

			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				$scope.tmArr.push(allVall)
			}
		});

		//Bounding Box - Add BottomLatLong filter in QueryBuilder for Production tab
		if ($rootScope.latlongType == "BottomLatLong") {
			var nwLat = angular.element(document).find('#nwlat').val().trim();
			var nwLong = angular.element(document).find('#nwlong').val().trim();

			var seLat = angular.element(document).find('#selat').val().trim();
			var seLong = angular.element(document).find('#selong').val().trim();

			if (nwLat !== "" && seLat !== "" && nwLong !== "" && seLong !== "") {
				nwLat = parseFloat(nwLat);
				nwLong = parseFloat(nwLong);
				seLat = parseFloat(seLat);
				seLong = parseFloat(seLong);
				if (Number.isFinite(nwLat) && Number.isFinite(nwLong) && Number.isFinite(seLat) && Number.isFinite(seLong)) {
					var latLongValues = nwLat + ", " + nwLong + ", " + seLat + ", " + seLong;
					var latLongVal = "BottomLatLong" + ":" + "eqto" + ":" + latLongValues;
					// $scope.tmArr.push(latLongVal);
					$rootScope.BBFilter = true;
					$rootScope.setBBCoords(latLongValues);
				}
				else {
					$.alertable.alert("Please enter valid bounding box filter values.")
				}
			}
		}

		if ($scope.tmArr.length > 0) {
			queryBuilderStr = Common.getquerybuilderfilter($scope.tmArr); //Form querybuilder filter string
			$rootScope.WellQBFilterArr = $scope.tmArr;
		}
		WellService.wellQueryBuilder = queryBuilderStr;

		if ($scope.tmArr != null && $scope.tmArr.length > 0) {
			var obj = new Object();
			obj.value = $scope.tmArr;
			obj.title = "Query Builder Filter";
			obj.fgname = "wellqb";
			obj.type = "qbfltr";
			$rootScope.selectedValArr[$rootScope.selectedValArr.length] = obj;
		}
	}

	//Below function will checks the duplicates in Querybuilder.
	$rootScope.checkWellQBDuplicateValue = function (wellQBFilterArr) {
		var qbfieldArr = [];
		angular.element('.Wellfltrdetgrp .QueryBuilder-container .QueryBuilder-condition').each(function () {

			var LHSVal = angular.element(this).find('select:nth-child(3) option:selected').val();
			var MHSVal = angular.element(this).find('select:nth-child(4) option:selected').val();

			if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typestring')) {
				var RHSVal = angular.element(this).find('.RHSSelect').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typedate')) {
				if (MHSVal == "btw") {
					var RHSVal = angular.element(this).find('.RHSDateRange').val();
					var tempDate = RHSVal.split('-');
					RHSVal = tempDate[0].split('/').join('-').trim() + " to " + tempDate[1].split('/').join('-').trim();
				}
				else {
					var RHSVal = angular.element(this).find('.RHSFielddate').val();
				}
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typesearch')) {
				var RHSVal = angular.element(this).find('.RHSFieldsearch').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeRange')) {
				var RHSVal = angular.element(this).find('.RHSNumRange').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeflag')) {
				var RHSVal = angular.element(this).find('.RHSFlg').val();
			}
			else {
				var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
			}
			var allVall = LHSVal + ":" + MHSVal + ":" + RHSVal;

			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				qbfieldArr.push(allVall);

				if (qbfieldArr.length > 1) {
					for (var i = 0; i < qbfieldArr.length - 1; i++) {
						for (j = i + 1; j <= qbfieldArr.length; j++) {
							if (qbfieldArr[i] == qbfieldArr[j]) {
								$rootScope.isDuplicate = true;
								$.alertable.alert("Query builder Filter '" + qbfieldArr[i] + "' is selected morethan ones.");
								return false;
							}
						}
					}
				}
			}
			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				for (var f = 0; (wellQBFilterArr !== undefined && f < wellQBFilterArr.length); f++) {
					if (wellQBFilterArr[f] == allVall) {
						$rootScope.isDuplicate = true;
						$.alertable.alert("Query builder Filter '" + allVall + "' is already exist in applied filter. Modify or remove the filter condition.");
						break;
					}
				}
			}

		});

		//Bounding Box - Duplicate value check in QueryBuilder filter
		if ($rootScope.latlongType == "BottomLatLong") {
			var nwLat = angular.element(document).find('#nwlat').val().trim();
			var nwLong = angular.element(document).find('#nwlong').val().trim();

			var seLat = angular.element(document).find('#selat').val().trim();
			var seLong = angular.element(document).find('#selong').val().trim();

			if (nwLat !== "" && seLat !== "" && nwLong !== "" && seLong !== "") {
				var latLongValues = nwLat + ", " + nwLong + ", " + seLat + ", " + seLong;
				var latLongVal = "BottomLatLong" + ":" + "eqto" + ":" + latLongValues;
				for (var l = 0; (wellQBFilterArr !== undefined && l < wellQBFilterArr.length); l++) {
					if (wellQBFilterArr[l] == latLongVal) {
						$rootScope.isDuplicate = true;
						$.alertable.alert("Query builder Filter '" + latLongVal + "' is already exist in applied filter. Modify or remove the filter condition.");
						break;
					}
				}
			}

		}
	}

	//Bounding Box Code

	$scope.getBoundingLatLong = function (latlongType) {
		$rootScope.latlongType = latlongType;
	}

	//Get bounding box lat long values 
	$rootScope.getBoundingBoxValues = function () {
		var nwLat = angular.element(document).find('#nwlat').val().trim();
		var nwLong = angular.element(document).find('#nwlong').val().trim();

		var seLat = angular.element(document).find('#selat').val().trim();
		var seLong = angular.element(document).find('#selong').val().trim();

		if (nwLat !== "" && seLat !== "" && nwLong !== "" && seLong !== "") {
			nwLat = parseFloat(nwLat);
			nwLong = parseFloat(nwLong);
			seLat = parseFloat(seLat);
			seLong = parseFloat(seLong);
			if (Number.isFinite(nwLat) && Number.isFinite(nwLong) && Number.isFinite(seLat) && Number.isFinite(seLong)) {
				var latLongValues = nwLat + ", " + nwLong + ", " + seLat + ", " + seLong;
				// latLongValues = "31.71,-65.74,48.74,-38.32";
				// latLongValues= "-87.01,-59.94,37.01,49.60";
				if ($rootScope.latlongType !== "BottomLatLong") {
					for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
						var checkField = $rootScope.selectedFieldsDetails[i];
						if (checkField.fieldValue !== "") {
							if (checkField.fieldValue == latLongValues && checkField.fieldName == "SurfaceLatLong") {
								$rootScope.isDuplicate = true
								$.alertable.alert("The filter SurfaceLatLong : " + latLongValues + " is already applied.");
								return false;
							}
						}
					}

					if (nwLat !== "" && seLat !== "" && nwLong !== "" && seLong !== "") {
						var obj = new Object();
						obj.fieldValue = latLongValues;
						obj.fieldName = "SurfaceLatLong";
						obj.titleName = "SurfaceLatLong";
						obj.displayName = latLongValues;
						$rootScope.BBFilter = true;
						$rootScope.setBBCoords(obj.fieldValue);
					}
				}
			}
			else {
				$.alertable.alert("Please enter valid bounding box filter values.")
			}
		}
	}


	//NW Latitude validation for value within -90 to 90
	$scope.validateNWLatitude = function (evt, txt) {
		var curField = angular.element(evt.currentTarget);
		var num = curField.val();
		var selatval = parseInt(angular.element(document).find('#selat').val());

if(num !== "" &&( parseInt(num) > 90 || parseInt(num) < -90 )){
	
			 $scope.invalidNWLatData2 = true;
			 $rootScope.invalidNWLatData2 = true;

			
			}
else{
	   $scope.invalidNWLatData2=false;
	   $rootScope.invalidNWLatData2 = false;
			
	}


		if ((selatval !== "" && selatval >= parseInt(num))) {
			$scope.invalidNWLatData = true;
			$scope.invalidSELatData = false;
			$rootScope.invalidNWLatData = true;
			$rootScope.invalidSELatData = false;
		}

		else {
			$scope.invalidNWLatData = true;
			$scope.invalidSELatData = true;
			$rootScope.invalidNWLatData = false;
			$rootScope.invalidSELatData = false;
		}
	}

	//SE Latitude validation for value within -90 to 90
	$scope.validateSELatitude = function (evt, txt) {
		var curField = angular.element(evt.currentTarget);
		var num = curField.val();
		var nwlatval = parseInt(angular.element(document).find('#nwlat').val());

		if(num !== "" && parseInt(num) > 90 || parseInt(num) < -90 ){
			$scope.invalidSELatData2 =true;
			$rootScope.invalidSELatData2=true;
		}

		else{			 
			$scope.invalidSELatData2 =false;
			$rootScope.invalidSELatData2=false;
		 }

		if ((nwlatval !== "" && nwlatval <= parseInt(num))) {
			$scope.invalidSELatData = true;
			$scope.invalidNWLatData = false;
			$rootScope.invalidSELatData = true;
			$rootScope.invalidNWLatData = false;
		}
		else {
			$scope.invalidNWLatData = true;
			$scope.invalidSELatData = true;
			$rootScope.invalidSELatData = false;
			$rootScope.invalidNWLatData = false;
		}
	}

	//NW Longitude validation for value within -180 to 180
	$scope.validateNWLongitude = function (evt, txt) {
		var curField = angular.element(evt.currentTarget);
		var num = curField.val();
		var selongval = parseInt(angular.element(document).find('#selong').val());

		if (num !== "" && parseInt(num) > 180 || parseInt(num) < -180) {
			$scope.invalidNWLongData2 = true;
			$rootScope.invalidNWLongData2 = true;
		}
		else {
			$scope.invalidNWLongData2 = false;
			$rootScope.invalidNWLongData2 = false;
		}

		if ((selongval !== "" && selongval <= parseInt(num))) {
			//$scope.invalidNWLongData = true;		
			$scope.invalidNWLongData = true;
			$scope.invalidSELongData = false;
			$rootScope.invalidNWLongData = true;
			$rootScope.invalidSELongData = false;
		}
		else {
			//$scope.invalidNWLongData = false;	
			$scope.invalidNWLongData = true;
			$scope.invalidSELongData = true;
			$rootScope.invalidNWLongData = false;
			$rootScope.invalidSELongData = false;
		}
	}

	//SE Longitude validation for value within -180 to 180
	$scope.validateSELongitude = function (evt, txt) {
		var curField = angular.element(evt.currentTarget);
		var num = curField.val();
		var nwlongval = parseInt(angular.element(document).find('#nwlong').val());


		if (num !== "" && parseInt(num) > 180 || parseInt(num) < -180) {
			$scope.invalidSELongData2 = true;
			$rootScope.invalidSELongData2 = true;
		}
		else {
			$scope.invalidSELongData2 = false;
			$rootScope.invalidSELongData2 = false;
		}

		if ((nwlongval !== "" && nwlongval >= parseInt(num))) {
			//$scope.invalidSELongData = true;	
			$scope.invalidSELongData = true;
			$scope.invalidNWLongData = false;
			$rootScope.invalidSELongData = true;
			$rootScope.invalidNWLongData = false;
		}
		else {
			//$scope.invalidSELongData = false;
			$scope.invalidNWLongData = true;
			$scope.invalidSELongData = true;
			$rootScope.invalidSELongData = false;
			$rootScope.invalidNWLongData = false;
		}
	}

	//Valudating the data for min and max values
	//Restrict alphabets and sepecial characters
	$scope.validateNumericRange = function (evt, txt) {
		var curField = angular.element(evt.currentTarget);
		var num = curField.val();
		var charCode = (evt.which) ? evt.which : evt.keyCode
		if (charCode > 31 && charCode !== 45 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8)) {
			evt.preventDefault();
		}
		else {
			var index = num.indexOf('.');
			if (index >= 0 && charCode == 46) {
				evt.preventDefault();
			}
			var mindex = num.indexOf('-');
			if (mindex >= 0 && charCode == 45) {
				evt.preventDefault();
			}
			//Allow minus at first position of textbox value
			if (charCode == 45 && curField[0].selectionStart !== 0) {
				evt.preventDefault();
			}
		}
	}
	//Shows Min and Max values in Range field textbox in well metadata
	$scope.ApplyRangeVal = function () {

		var minval = angular.element(document).find('#rangeMinVal').val();
		var maxval = angular.element(document).find('#rangeMaxVal').val();

		$scope.rangeMinVal = (minval !== "" && !angular.isUndefined(minval)) ? parseFloat(minval) : "";
		$scope.rangeMaxVal = (maxval !== "" && !angular.isUndefined(maxval)) ? parseFloat(maxval) : "";

		
		if ($scope.rangeMinVal !== "" && $scope.rangeMaxVal !== 0 && $scope.rangeMaxVal == "") {
			if($scope.rangeMinVal <= -65000.0001 || $scope.rangeMinVal >= 65000.0001)
			{
				$.alertable.alert('Min value should be with in -65000 to 65000');
				return false;
			}
			$scope.metaRngeVal = "gte:" + $scope.rangeMinVal;
		}
		else if ($scope.rangeMinVal == "" && $scope.rangeMinVal !== 0 && $scope.rangeMaxVal !== "") {
			 if($scope.rangeMaxVal <= -65000.0001 || $scope.rangeMaxVal >= 65000.0001)
			{
				$.alertable.alert('Max value should be with in -65000 to 65000');
				return false;
			}
			$scope.metaRngeVal = "lte:" + $scope.rangeMaxVal;
		}
		else if ($scope.rangeMinVal !== "" && $scope.rangeMaxVal !== "") {
			if($scope.rangeMinVal <= -65000.0001 || $scope.rangeMinVal >= 65000.0001)
			{
				$.alertable.alert('Min value should be with in -65000 to 65000');
				return false;
			}
			else if($scope.rangeMaxVal <= -65000.0001 || $scope.rangeMaxVal >= 65000.0001)
			{
				$.alertable.alert('Max value should be with in -65000 to 65000');
				return false;
			} else
			 if ($scope.rangeMinVal > $scope.rangeMaxVal) {
				$.alertable.alert('Max value should be greater than Min value');
				return false;
			}
			$scope.metaRngeVal = $scope.rangeMinVal + " to " + $scope.rangeMaxVal;
		}
		else {
			$scope.metaRngeVal = "";
		}
		angular.element("#meta-range-popover").popover('hide');
		angular.element(document).find('#rangeMinVal').val('');
		angular.element(document).find('#rangeMaxVal').val('');
	}
	$scope.loadFilterData();
})
	.directive('rangepopover', function ($compile) {  // Add range popover for Well metadata Range field
		return {
			restrict: 'A',
			link: function (scope, elem) {
				var content = angular.element("#range-popover-content").html();
				var compileContent = $compile(content)(scope);
				var title = angular.element("#range-popover-head").html();
				var options = {
					content: compileContent,
					html: true,
					title: title
				};
				angular.element(elem).popover(options);
			}
		}
	});


