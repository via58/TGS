/*
File Name:- wellRasterTabCtrl.js
Summary:- Fetch the Raster product details based on the filter string.
*/

angular.module('TGSApp').controller('wellRasterTabCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    //This function fetches the Raster data based on the current filter.
    $rootScope.wellRastertab = function () {
        $scope.Rasteritems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";
            // If polygon is drawn, get the Well LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

            // Below function will gets the UUID and frame the Filter string.
            var uuid = Common.getUuid();

            // Below function will gets the Entitlement customer Id and frame the Filter string.
            var entitlementUrl = Common.getWellEntitlementUrl();
            if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }

            // Below function will loads Production Well clusters in Map with respect to current filter string.                     
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, WellService.wellQueryBuilder, uuid, entitlementUrl, "");

            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "Raster", "0", "20", "", "", "");

            // Calling http service request to get LAS data
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.Rasteritems = response.data.content; // Assign Production Data
            $scope.Rastercount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.rasterPagesCount = response.data.totalElements;
            }
            else {
                $scope.rasterPagesCount = 10000;
            }
        }
        else {
            $scope.Rasteritems = []; // Assign Production Data
            angular.element(document).find('.norecords').text('No records found.');
            $scope.rasterPagesCount = 0;
            $scope.Rastercount = 0;
        }
        
        // Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }

    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    // This function will call on click of pager and fetches the Raster data based on the current filter.
    $rootScope.wellRasterpager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.  
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        // Below function will gets the UUID and frame the Filter string.  
        var uuid = Common.getUuid();

        // Below function will gets the Entitlement customer Id and frame the Filter string.
        var entitlementUrl = Common.getWellEntitlementUrl();
        if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }

        $scope.Rasteritems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;

        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "Raster", $scope.clickedpage, "20", "", "", "");

        // Calling http service request to get LAS data
        $http(request).then(successCallback, errorCallback);
    }
});