/*
File Name:- wellLasTabCtrl.js
Summary:- Fetch the Las product details based on the filter string.
*/

angular.module('TGSApp').controller('wellLasTabCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, Common) {

    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    angular.element('.sub-header').find('.showhome').show();
    //This function fetches the LAS data based on the current filter.
    $rootScope.wellLastab = function () {
        if (!$rootScope.wellSwitchFlag) {
            $scope.Lasitems = [];
            $scope.sercnt += 1;
            if ($scope.sercnt == 1) {
                angular.element(document).find('.nav.nav-tabs').find('.isTabDisable').removeClass('hide');
                // Apply loader on Map Container
                angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

                var geoSpatialFilter = "";
                // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

                // below function will gets the Entitlement customer Id and frame the Filter string.
                var entitlementUrl = Common.getWellEntitlementUrl();
                if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
                    {
                        entitlementUrl = $rootScope.WellEntitleUrl;
                    }
                
                // below function will gets the UUID and frame the Filter string.
                var uuid = Common.getUuid();
                // below function will hides the shapes in map based on the Filter string.

                $rootScope.hideProjectLayer();
                // This below function will loads Las Well clusters in Map with respect to current filter string.
                $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, WellService.wellQueryBuilder, uuid, entitlementUrl, "");

                var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "Las", "0", "20", "", "", "");

                //Calling http service request to get LAS data
                $http(request).then(successCallback, errorCallback);
                $scope.currentPage = 0;
                $scope.sercnt = 0;
                setTimeout(function () {
                    if (angular.element('.applied-filter-group').find('.detail-view-label').text() !== "") {
                        angular.element('.applied-filter-section').find('.no-filter-applied').hide();
                    }
                }, 1000)
            }
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0 ) {
            $scope.Lasitems = response.data.content; //Assign Las Data
            $scope.Lascount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.lasPagesCount = response.data.totalElements; //Assign Total elements count.
            }
            else {
                $scope.lasPagesCount = 10000; //Set the count to 10000 if totalElements > 10000
            }
            // calling map filters   
        }
        else {
            $scope.Lasitems = [];    //Assign Las Data
            angular.element(document).find('.norecords').text('No records found.');
            $scope.lasPagesCount = 0;
            $scope.Lascount = 0;
        }        
        //below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
            //angular.element(document.body).find('#overlay').remove();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }

    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();                
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    //This function will call on click of pager and fetches the LAS data based on the current filter.
    $rootScope.wellLaspager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        // below function will gets the UUID and frame the Filter string.
        var uuid = Common.getUuid();

        // below function will gets the Entitlement customer Id and frame the Filter string.
        var entitlementUrl = Common.getWellEntitlementUrl();
        if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }

        $scope.Lasitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;

        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "Las", $scope.clickedpage, "20", "", "", "");
        //Calling http service request to get LAS data
        $http(request).then(successCallback, errorCallback);
    }

});