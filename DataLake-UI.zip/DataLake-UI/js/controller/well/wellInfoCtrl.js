/*
File Name:- wellInfoCtrl.js
Summary:- Fetch the well details in home view based on the filter string.
*/

angular.module('TGSApp').controller('wellInfoCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, Common) {
    $rootScope.detailView = true;
    $rootScope.moduleName = '';
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    window.WellLongLat = [];
    window.AllWellLongLat = [];
    $scope.weltableInfo = function (wellName) {
        for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
            var checkWell = $rootScope.selectedValArr[i];
            if (checkWell.value[0] == wellName) {
                $.alertable.alert("This well name : '" + wellName + "' is already applied in filter.");
                $rootScope.detailView = false;
                window.fromwell = true;
                $rootScope.callFromHomePage = true;
                $location.path('/detail');

                setTimeout(function () {
                    angular.element('.nav.nav-tabs:first').find('li:nth-child(2)').find('a').click();
                    $rootScope.filterNameGroup = "Well";

                }, 300);
                return false;
            }
        }
        $rootScope.callsegyfromhome = false;
        if (WellService.allWellFilter == "") {
            WellService.allWellFilter = "Wellname:" + wellName;
        }
        else {
            WellService.allWellFilter = WellService.allWellFilter + " AND Wellname:" + wellName;
        }
        $rootScope.collectFilterData("Wellname", wellName, "Wellname");

        var obj = new Object();
        obj.value = [wellName];

        obj.title = "Wellname";
        obj.fgname = "wfcommon";

        $rootScope.selectedValArr[$rootScope.selectedValArr.length] = obj;
        $rootScope.aplFilterData[$rootScope.aplFilterData.length] = wellName;
        $rootScope.detailView = false;
        $rootScope.wellFromHome = true;
        window.fromwell = true;
        $rootScope.callFromHomePage = true;
        $location.path('/detail');
        //Commented - cascading is not requird for searchabel fields in Well Metadata
        //$rootScope.wellhometoDetailCascade(wellName);

        setTimeout(function () {
            angular.element('.nav.nav-tabs:first').find('li:nth-child(2)').find('a').click();
            angular.element('.Wellfltrdetgrp').removeClass('hide');
            angular.element('.detail-view-tab > .filter-setting').addClass('hide');

        }, 1000);
    }

    // init the filtered items
    $rootScope.allwellmap = function () {

        var toggleTxt = angular.element(document).find('.tools-section').find('.btn-group').find('label.active').text()
        $rootScope.$broadcast("event:applyWellFilters", { filterInfo: $rootScope.selectedFieldsDetails, selectedTab: toggleTxt });
                
    };

    // This function fetches the Well data in home view based on the current filter.
    $rootScope.loadWellDetails = function () {
        window.WellLongLat = [];
        var geoSpatialFilter = "";
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

        // Below function will gets the Entitlement customer Id and frame the Filter string.
        var entitlementUrl = Common.getWellEntitlementUrl();
        if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
        {
        entitlementUrl = $rootScope.WellEntitleUrl;
        }        

        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", "", WellService.allWellSelectedFields, "", entitlementUrl, "", "", "0", "20", "WellID,Asc", "", "");
        request.url = Common.urlValue + WellService.allWellInfoService;

        $http(request).
            // Calling http service request to get Well data            
            then(function (response) {                
                if (response.data.content.length > 0) {
                    $scope.items = response.data.content;
                    window.WellLongLat = getWellLongLat($scope.items);                    
                    $scope.homeWellcount = response.data.totalElements;
                    if (response.data.totalElements < 10000) {
                        $scope.wellTotalPagesCount = response.data.totalElements;
                    }
                    else {
                        $scope.wellTotalPagesCount = 10000;
                    }
                }
                else {
                    $scope.items = response.data.content;
                    $scope.wellTotalPagesCount = response.data.length; 
                    $scope.homeWellcount = response.data.totalElements; 
                    angular.element(document).find('.norecords').text('No records found.');                  
                }
                $scope.currentPage = 0;
                $scope.sort = {
                    sortingOrder: $scope.items.UWI,
                    reverse: false
                };
                $scope.hideQueryBuilderFilter();                               
            }).catch(function (reason) {                                
                Common.redirectToCore(reason); 
            });      
    };
    // Below function will form the Lat Long coordinates based on well Data
    var getWellLongLat = function (data) {
        var lontLat = [];
        for (var i = 0; i < data.length; i++) {
            if (i == 0)
                lontLat.push(JSON.parse("[" + data[i].SurfaceLongitudeWGS84 + ", " + data[i].SurfaceLatitudeWGS84 + "]"));
            else
                lontLat.push(JSON.parse("[" + data[i].SurfaceLongitudeWGS84 + ", " + data[i].SurfaceLatitudeWGS84 + "]"));

        }
        return lontLat;
    }

    // Hide Query Builder filter in home page
    $rootScope.hideQueryBuilderFilter = function () {
        angular.element('.applied-filter-group').each(function () {
            if (angular.element(this).find('.detail-view-label').text() == "Query Builder Filter") {
                angular.element(this).find('.detail-view-label').parent('div').parent('div').hide();
            }
        });
    }

    // This function will call on click of pager and fetches the Well data based on the current filter.    
    $rootScope.wellpager = function (custommsg, page, pageSize, total) {
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;
        var geoSpatialFilter = "";
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string. 
        if (window.drawPolygon) {
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
        }
        // Below function will gets the Entitlement customer Id and frame the Filter string.
        var entitlementUrl = Common.getWellEntitlementUrl();

        //  var allWellInfoServiceurl = 'getWellInfoFilterService?pageSize=20&pageNumber=' + $scope.clickedpage + '&orderStr=WellID,Asc' ;
        $scope.items = [];

        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", "", WellService.allWellSelectedFields, "", entitlementUrl, "", "", $scope.clickedpage, "20", "WellID,Asc","","");                                           
        request.url = Common.urlValue + WellService.allWellInfoService;      
        $http(request).
            then(function (response) {
                if (response.data.content.length > 0) {                    
                    $scope.items = response.data.content;
                    window.WellLongLat = getWellLongLat($scope.items);
                    if (response.data.totalElements < 10000) {
                        $scope.wellTotalPagesCount = response.data.totalElements;
                    }
                    else {
                        $scope.wellTotalPagesCount = 10000;
                    }
                }
                else {
                    $scope.items = response.data.content;
                    $scope.wellTotalPagesCount = response.data.length;
                    angular.element(document).find('.norecords').text('No records found.');
                    $scope.homeWellcount = response.data.totalElements;
                }
                $scope.hideQueryBuilderFilter();
                angular.element(document.body).find('.pagerspinner').remove();                
            }).catch(function (reason) {
                $scope.hideQueryBuilderFilter();
                angular.element(document.body).find('.pagerspinner').remove();                
                Common.redirectToCore(reason); 
            });     
    }
    setTimeout(function () {
        $scope.loadWellDetails();
    }, 700)

    //When draw polygon, broad cast the below event and load the Well details
    $scope.$on("event:wellPolygonDraw", function (event, data) {
        $rootScope.aplFilterData = [];
        $rootScope.aplFilterTitle = [];
        $scope.loadWellDetails();
        $scope.allwellmap();
    });
});