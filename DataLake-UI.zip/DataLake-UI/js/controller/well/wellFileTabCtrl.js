/*
File Name:- wellFileTabCtrl.js
Summary:- Fetch the well File details based on the filter string.
*/

angular.module('TGSApp').controller('wellFileTabCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    $scope.searchwellfiletext = "";
    var searchwellfileUrl = "";

    // This function will clear the Well File search filter.
    $rootScope.emptySearchFieldwellfile = function () {
        $scope.searchwellfiletext = "";
        $scope.pagenumberflag = false;
    }
    // This function fetches the Well File data based on the current filter.
    $rootScope.wellWFtab = function () {
        $scope.WFitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
            var geoSpatialFilter = "";
            // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
            var selectedFields = Common.getWellFileSelectedFields();
            if ($scope.searchwellfiletext !== "") {
                if (selectedFields !== "") {
                    //Below function will frame the Filter string based on the search filter string.
                    searchwellfileUrl = Common.getWellFilterUrl($scope.searchwellfiletext);
                } else {
                    searchwellfileUrl = Common.getWellFilterUrl($scope.searchwellfiletext);
                }
            } else {
                searchwellfileUrl = Common.getWellFilterUrl("");
            }
            // Below function will gets the Entitlement customer Id and frame the Filter string.
            var entitlementUrl = Common.getWellEntitlementUrl();
            if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }
            
            // Below function will gets the UUID and frame the Filter string.
            var uuid = Common.getUuid();

            $scope.WFitems = [];
            // Below function will loads Well File clusters in Map with respect to current filter string. 

            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, WellService.wellQueryBuilder, uuid, entitlementUrl, searchwellfileUrl);
            // Calling http service request to get Well File data

            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, selectedFields, uuid, entitlementUrl, "Well", "WellFile", "0", "20", "", "", searchwellfileUrl);

            // $http.get(WellService.urlValue + WellService.wellWFtaburl + WellService.allWellFilter + geoSpatialFilter + WellService.wellQueryBuilder + selectedFields + uuid + entitlementUrl + searchwellfileUrl).
            $http(request).then(successCallback,errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }

    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {            
            $scope.WFcount = response.data.totalElements;
            for (var i = 0; i < response.data.content.length; i++) {
                $scope.WFitems.push({ data: response.data.content[i].list }); // Assign Production Data
            }
            if ($scope.WFcount < 10000) {
                $scope.WFPagesCount = $scope.WFcount;
            }
            else {
                $scope.WFPagesCount = 10000;
            }
        }
        else {
            $scope.WFitems = [];
            angular.element(document).find('.norecords').text('No records found.');
            $scope.WFPagesCount = 0;
            $scope.WFcount = 0;
        }
        
        // Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
            if ($scope.searchwellfiletext !== "") {
                angular.element(document.body).find('.pagenumberspan').addClass('pagenumberclickable');
                angular.element(document.body).find('.fldgrp-set').addClass('filtergrpclick');
            }
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }
    // This function will call on click of pager and fetches the Production data based on the current filter.        
    $rootScope.wellWFpager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.    
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
        var selectedFields = Common.getWellFileSelectedFields();
        if ($scope.searchwellfiletext !== "") {
            if (selectedFields !== "") {
                searchwellfileUrl = Common.getWellFilterUrl($scope.searchwellfiletext);
            } else {
                searchwellfileUrl = Common.getWellFilterUrl($scope.searchwellfiletext);
            }
        } else {
            searchwellfileUrl = Common.getWellFilterUrl("");
        }

        // Below function will gets the Entitlement customer Id and frame the Filter string.
        var entitlementUrl = Common.getWellEntitlementUrl();
        if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }
        
        // Below function will gets the UUID and frame the Filter string.  
        var uuid = Common.getUuid();

        $scope.WFitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
        $scope.clickedpage = page - 1;        
        // Calling http service request to get Well File data

        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, selectedFields, uuid, entitlementUrl, "Well", "WellFile", $scope.clickedpage, "20", "", "", searchwellfileUrl);
        
        $http(request).then(successCallback,errorCallback);
    }

    //On select/click of enter key, fetches the Well File data based on the current search filter text.
    document.getElementById("wellFileSearchBox").addEventListener("keyup", function (event) {

        if ($scope.searchwellfiletext !== "") {
            if (event.keyCode === 13) {
                $scope.pagenumberflag = true;
                $rootScope.wellWFtab();
            }
        }
    });

    //On click of Search button, fetches the Well File data based on the current search filter text.
    $scope.freeTextWellFile = function () {
        $scope.pagenumberflag = true;
        if ($scope.searchwellfiletext !== "") {
            $rootScope.wellWFtab();
        }
    }

    //On click of page numbers, get the text snippet from file and show it in ui
    $scope.showSnippetText = function (number, wffilename, source) {
        if (source == "div") {
            var wellWFtabsearchurl = "getSnippetInfo";
            var pdfFileName = wffilename;
            var pdfPageNumber = number;
            //var pdfFilterUrl = WellService.pdfFilterStr + $scope.searchwellfiletext;
            let responseText = "";
            if ($scope.searchwellfiletext !== "") {

                var paramInfo = {
                    module: "Well",
                    tabName: "WellFile",
                    pdfFileName: pdfFileName,
                    pdfPageNumber: pdfPageNumber,
                    pdfFilterStr: $scope.searchwellfiletext,
                    requestTimestamp : Common.getCurrentDateTime(),
                    token: $rootScope.sessionToken,
                    access_token: $rootScope.accessToken
                }
                
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
                var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent                

                var request = {
                    method: 'POST',
                    url: Common.urlValue + wellWFtabsearchurl,
                    data: paramInfoList,
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded'  }
                }
                //$http.get(WellService.urlValue + wellWFtabsearchurl + pdfFileName + pdfPageNumber + pdfFilterUrl).
                $http(request).
                    then(function (response) {
                        if (response.data.content.length > 0) {
                            if (response.data.content[0].list.OcrText.length > 1) {
                                temp = response.data.content[0].list.OcrText;
                                temp.forEach(element => {
                                    responseText += "<li>" + element + "</li>";
                                });
                            }
                            else {
                                responseText = "<li>" + response.data.content[0].list.OcrText[0] + "</li>";
                            }

                        }
                        else {
                            responseText = "Not found";
                        }
                        angular.element(document.body).find('[label-snippet="' + wffilename + '"]').html(responseText);
                        angular.element(document.body).find('[data-column-val="' + wffilename + '"]').removeClass('hide');
                        setTimeout(function () {
                            angular.element('[label-snippet]').find('em').css('background', 'yellow');
                        })
                    });
            }
        }
    }
    //On click of page numbers, get the text snippet from file and show it in ui
    $scope.showWellFileSnippet = function (number, wffilename, source, $event) {
        if (source == "page") {
            var wellWFtabsearchurl = "getSnippetInfo";
            var pdfFileName = wffilename;
            var pdfPageNumber = number;
            //  var pdfFilterUrl = WellService.pdfFilterStr + $scope.searchwellfiletext;
            let responseText = "";
            if ($scope.searchwellfiletext !== "") {

                var paramInfo = {
                    module: "Well",
                    tabName: "WellFile",
                    pdfFileName: pdfFileName,
                    pdfPageNumber: pdfPageNumber,
                    pdfFilterStr: $scope.searchwellfiletext,
                    requestTimestamp : Common.getCurrentDateTime(),
                    token: $rootScope.sessionToken,
                    access_token: $rootScope.accessToken
                }
                
        paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
        paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
                var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent               

                var request = {
                    method: 'POST',
                    url: Common.urlValue + wellWFtabsearchurl,
                    data: paramInfoList,
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded'  }
                }
               
                $http(request).
                    then(function (response) {
                        if (response.data.content.length > 0) {
                            if (response.data.content[0].list.OcrText.length > 1) {
                                temp = response.data.content[0].list.OcrText;
                                temp.forEach(element => {
                                    responseText += "<li>" + element + "</li>";
                                });
                            }
                            else {
                                responseText = "<li>" + response.data.content[0].list.OcrText[0] + "</li>";
                            }

                        }
                        else {
                            responseText = "Not found";
                        }
                        angular.element(document.body).find('[label-snippet="' + wffilename + '"]').html(responseText);
                        angular.element(document.body).find('[data-column-val="' + wffilename + '"]').removeClass('hide');
                        setTimeout(function () {
                            angular.element('[label-snippet]').find('em').css('background', 'yellow');
                        })
                    });
            }
        }
        $event.stopPropagation();
    }

});
