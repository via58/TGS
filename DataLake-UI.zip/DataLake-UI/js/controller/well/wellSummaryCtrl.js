/*
File Name:- wellSummaryCtrl.js
Summary:- This page will shows Well Summary details.
*/
angular.module('TGSApp').controller('wellSummaryCtrl', function ($scope, $uibModal, $rootScope, $http, WellService, Common) {
    //Below function will show the Well Summary popup
    $scope.showwellSmryModal = function () {
        angular.element(document.body).append('<div id="overlay"><div class="spinner"></div></div>');
        var wellSummaryService = 'getWellSummaryInfo';
        var geoSpatialFilter = "";
        if (window.drawPolygon) {
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
        }

        var entitlementUrl = Common.getWellEntitlementUrl();
        if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            } 
        var request = Common.getPostReqParams( WellService.allWellFilter, geoSpatialFilter, "", "", "", "", entitlementUrl,"","","","","","","")

        request.url = Common.urlValue + wellSummaryService;        
        $http(request).
            then(function (response) {

                $scope.openModal = function () {

                    $scope.modalInstance = $uibModal.open({
                        ariaLabelledBy: 'modal-title',
                        ariaDescribedBy: 'modal-body',
                        templateUrl: 'partials/well/wellSummaryModal.html',
                        controller: 'wellSummaryModelController',
                        controllerAs: '$ctrl',
                        size: 'md',
                        resolve: {
                            "args": function () {
                                return {
                                    responseData: response.data
                                }
                            }

                        }
                    });
                }
                $scope.openModal();
                angular.element(document.body).find('#overlay').remove();
            }).catch(function (response) {
                angular.element(document.body).find('#overlay').remove();                
            });
    }
}).controller("wellSummaryModelController", function ($scope, $uibModalInstance, args) {

    $scope.datalist = args.responseData;
    $scope.cancelModal = function () {
        $uibModalInstance.close('close');
    }    
});

