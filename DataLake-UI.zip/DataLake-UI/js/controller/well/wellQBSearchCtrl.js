/*
File Name:- wellQBSearchCtrl.js
Summary:- Fetch the distinct Field values for selected field name in Query Builder.
*/

angular.module('TGSApp').controller('wellQBSearchCtrl', function ($scope, $location, $rootScope, WellService, SurveyService, $http, $sce, limitToFilter, Common) {
  $scope.selected = undefined;  

  //Below function will fetch the distinct values for the selected field
  $scope.getWellQBValues = function (title) {
    if (title.length >= 2) {
      $scope.result1 = [];

      var mdlname = $rootScope.filterNameGroup;
      if (mdlname == "Seismic") {
        var lhsName = $rootScope.qblhsval;
      }
      else {
        var lhsName = $rootScope.qblhsval;
      }

      var serviceUrl = "getSearchFieldName"

      var paramInfo = {
        source: lhsName,
        module: mdlname,
        searchStr: title,
        requestTimestamp : Common.getCurrentDateTime(),
        token: $rootScope.sessionToken,
        access_token: $rootScope.accessToken
      }
      
      paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

      var paramInfoList = $.param(paramInfo);

      var request = {
        method: 'POST',
        url: SurveyService.urlValue + serviceUrl,
        data: paramInfoList,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded'  }
      }

      // return $http.get($sce.trustAsResourceUrl(searchurl))
      return $http(request)
        .then(function (response) {
          var lhsName = $rootScope.qblhsval;
          var datastr = response.data[lhsName];
          if (response.data !== undefined) {
            angular.forEach(datastr, function (value) {
              $scope.result1.push({ "displayText": value });
            });
          }
          return limitToFilter($scope.result1, 500);
        });
    }
  };

  //Below function will fetch the distinct values for the given search text
  $scope.qbWellFiltername = function (title, fieldname) {
    if (title.length > 2) {
      var mdlname = $rootScope.filterNameGroup;
      $scope.selecteduwi = [];
      $scope.selectedwell = [];
      $scope.selectedwellnumber = [];
      $scope.selectedwellid = [];
      $rootScope.selectedoperator = [];
      var serviceUrl = "getSearchFieldName";
      var paramInfo = {
        source: fieldname,
        module: mdlname,
        searchStr: title,
        requestTimestamp : Common.getCurrentDateTime(),
        token: $rootScope.sessionToken,
        access_token: $rootScope.accessToken
      }
      
      paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

      var paramInfoList = $.param(paramInfo);

      var request = {
        method: 'POST',
        url: SurveyService.urlValue + serviceUrl,
        data: paramInfoList,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded'  }
      }

      //return $http.get($sce.trustAsResourceUrl(searchurl))
      return $http(request)
        .then(function (response) {
          var datastr = response.data[fieldname];
          switch (fieldname) {
            case "UWI":
              if (response.data !== undefined) {
                angular.forEach(datastr, function (value) {
                  $scope.selecteduwi.push({ "displayText": value });
                });
                return limitToFilter($scope.selecteduwi, 25);
              }
              break;
            case "Wellname":
              if (response.data !== undefined) {
                angular.forEach(datastr, function (value) {
                  $scope.selectedwell.push({ "displayText": value });
                });
                return limitToFilter($scope.selectedwell, 25);
              }
              break;
            case "WellnbrTxt":
              if (response.data !== undefined) {
                angular.forEach(datastr, function (value) {
                  $scope.selectedwellnumber.push({ "displayText": value });
                });
                return limitToFilter($scope.selectedwellnumber, 25);
              }
              break;
            case "WellID":
              if (response.data !== undefined) {
                angular.forEach(datastr, function (value) {
                  $scope.selectedwellid.push({ "displayText": value });
                });
                return limitToFilter($scope.selectedwellid, 25);
              }
              break;
            case "Operator":
              if (response.data !== undefined) {
                angular.forEach(datastr, function (value) {
                  $rootScope.selectedoperator.push({ "displayText": value });
                });
                return limitToFilter($rootScope.selectedoperator, 25);
              }
              break;
          }

        });
    }
  }
});

