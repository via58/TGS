/*
File Name:- wellVWHTabCtrl.js
Summary:- Fetch the VWH product details based on the filter string.
*/

angular.module('TGSApp').controller('wellVWHTabCtrl', function ($scope, $location, $rootScope, $filter, $http, WellService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    // This function fetches the VWH data based on the current filter.
    $rootScope.wellVWHtab = function () {
        $scope.VWHitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";
            // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

            // Below function will gets the UUID and frame the Filter string.
            var uuid = Common.getUuid();

            // Below function will gets the Entitlement customer Id and frame the Filter string.
            var entitlementUrl = Common.getWellEntitlementUrl();
            if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }
            
            // Below function will loads VWH Well clusters in Map with respect to current filter string.  
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, WellService.wellQueryBuilder, uuid, entitlementUrl, "");

            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "VWH", "0", "20", "", "", "");

            // Calling http service request to get VWH data            
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.VWHitems = response.data.content; // Assign Production Data
            $scope.VWHcount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.VWHPagesCount = response.data.totalElements;
            }
            else {
                $scope.VWHPagesCount = 10000;
            }
        }
        else {
            $scope.VWHitems = []; // Assign Production Data
            angular.element(document).find('.norecords').text('No records found.');
            $scope.VWHPagesCount = 0;
            $scope.VWHcount = 0;
        }
        
        // Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }

    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    // This function will call on click of pager and fetches the Production data based on the current filter.    
    $rootScope.wellVWHpager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.  
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
        // Below function will gets the UUID and frame the Filter string.    
        var uuid = Common.getUuid();

        // Below function will gets the Entitlement customer Id and frame the Filter string.
        var entitlementUrl = Common.getWellEntitlementUrl();
        if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }

        $scope.VWHitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;       
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "VWH", $scope.clickedpage, "20", "", "", "");

        // Calling http service request to get VWH data
        $http(request).then(successCallback,errorCallback);
    }

});