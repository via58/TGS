/*
File Name:- wellProductionTabCtrl.js
Summary:- Fetch the Production product details based on the filter string.
*/

angular.module('TGSApp').controller('wellProductionTabCtrl', function ($scope, $route, $location, $rootScope, $filter, $http, WellService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    //This function fetches the Production data based on the current filter.
    $rootScope.welproductiontab = function () {
        $scope.sercnt += 1;
        $scope.Productionitems = [];
        if ($scope.sercnt == 1) {
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
            var geoSpatialFilter = "";
            // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

            // Below function will gets the UUID and frame the Filter string.
            var uuid = Common.getUuid();

            // Below function will gets the Entitlement customer Id and frame the Filter string.
            var entitlementUrl = Common.getWellEntitlementUrl(); 
            if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }
            
            // Below function will loads Production Well clusters in Map with respect to current filter string.
            $rootScope.GenerateGrds(WellService.allWellFilter, geoSpatialFilter, WellService.wellQueryBuilder, uuid, entitlementUrl ,"");

            var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "Production", "0", "20", "", "", "");

            //Calling http service request to get LAS data            
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }

    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.Productionitems = response.data.content; //Assign Production Data
            $scope.Productioncount = response.data.totalElements;
            if (response.data.totalElements < 10000) {
                $scope.wellProductionPagesCount = response.data.totalElements;
            }
            else {
                $scope.wellProductionPagesCount = 10000;
            }
        }
        else {
            $scope.Productionitems = []; //Assign Production Data
            angular.element(document).find('.norecords').text('No records found.');
            $scope.wellProductionPagesCount = 0;
            $scope.Productioncount = 0;
        }
        
        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }


    //This function will call on click of pager and fetches the Production data based on the current filter.
    $rootScope.wellProductionpager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";
        // If polygon is drawn,get the Well LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
        
            // Below function will gets the UUID and frame the Filter string.
            var uuid = Common.getUuid();
        
            // Below function will gets the Entitlement customer Id and frame the Filter string.
            var entitlementUrl = Common.getWellEntitlementUrl();
            if(entitlementUrl == "" && $rootScope.WellEntitleUrl)
            {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }

        $scope.Productionitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
        $scope.clickedpage = page - 1;        
        var request = Common.getPostReqParams(WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, "", uuid, entitlementUrl, "Well", "Production", $scope.clickedpage, "20", "", "", "");
        $http(request).then(successCallback,errorCallback);
    }
});