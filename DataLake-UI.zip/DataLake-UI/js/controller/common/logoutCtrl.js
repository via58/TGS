/*
File Name:- logoutCtrl.js
Summary:- Logouts the user from the current session.
*/

angular.module('TGSApp').controller('logoutCtrl', function ($scope, $rootScope, $http, WellService) {

    $scope.logoutApp = function () {
        
var logoutUrl = "bigdecisions/authentication/user/logout";        
        var request = {
            method: 'POST',
            url: WellService.urlValue + logoutUrl,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': $rootScope.accessToken}
        }
            $http(request)
                    window.access= false;
                    $rootScope.sessionIdExist=false;
                    window.close();
    }
});