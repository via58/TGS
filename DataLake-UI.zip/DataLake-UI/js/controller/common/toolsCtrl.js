/*
File Name:- toolsCtrl.js
Summary:- Gets the user Role and assigns the user Role.
*/

angular.module('TGSApp').controller('toolsCtrl', function ($scope, $location, $rootScope, $uibModal, $http, WellService, SurveyService,Common) {
    angular.element('.Wellfltrgrp').addClass('hide');
    angular.element(document).find('.mapSidepanelbtn').hide();
    $rootScope.detailView = true;
    $rootScope.appgname="Seismic";
    var downloadWellUrl = "downloadCSV";
    $rootScope.filterNameGroup = "Seismic";
    $scope.currentTab = "SURVEY";
    $scope.appgname = "Seismic";
    $scope.csv_link = WellService.urlValue + downloadWellUrl;
    $rootScope.isWellClicked = false; 
    $rootScope.isSeismicClicked = false; 
    $rootScope.downloadCSV = function (sourceData) {

        if(sourceData == "")
        sourceData = "SURVEY";
        if (sourceData !== "" && sourceData !== undefined) {                       
            var geoSpatialFilter = "";            
            var request = "";
            if (sourceData == "WELL") {
                //Form polygon filter
                if(window.drawPolygon) {
                    if(WellService.allWellFilter != "") {
                        geoSpatialFilter = " AND LatLongGeoShape:" +  window.geocoorinates;                        
                    }
                    else {
                        geoSpatialFilter = "LatLongGeoShape:" +  window.geocoorinates;                        
                    }                                               
                } 
                //Form Entitlement filter for customer
                var entitlementUrl = Common.getWellEntitlementUrl();                
                
                //Form Well CSV download request 
                var request = Common.getHomeCSVDownload(WellService.allWellFilter, geoSpatialFilter,tabName="Well",entitlementUrl)                

            }
            if (sourceData == "SURVEY" || sourceData=="") {
                //Form polygon filter
                if(window.drawPolygon) {
                    if(SurveyService.allSurveyFilter != "") {
                        geoSpatialFilter = " AND SurveyGeoShape:" +  window.geocoorinates;
                        
                    }
                    else {
                        geoSpatialFilter = "SurveyGeoShape:" +  window.geocoorinates;                        
                    }                                           
                }
                //Form Entitlement filter for customer
                var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();                                
                
                //Form Survey CSV download request 
                var request = Common.getHomeCSVDownload(SurveyService.allSurveyFilter, geoSpatialFilter,tabName="Seismic",surveyEntitlementUrl)
            }
            
            angular.element(document).find('.csvprogrss').text("Downloading File....");
            angular.element(document).find('.csvprogrss').fadeIn("slow");
            setTimeout(function(){
                angular.element(document).find('.csvprogrss').fadeOut("slow");
            },2000);                        

            //Set the download timeout to 1 minit
            $http(request, {timeout:300000}).
                then(function (response) {                    
                        if (response.data !== null && response.data !== undefined) {           
                        var blob = new Blob([response.data]);                        
                        var anchor = angular.element('<a>');
                        anchor.css({ display: 'none' }); // Make sure it's not visible
                        angular.element(document.body).append(anchor); // Attach to document
                        var today = new Date();
                        var dd = today.getDate();
                        var mm = today.getMonth() + 1; //January is 0!
                        var yyyy = today.getFullYear();
                        var hour = today.getHours();
                        var minu = today.getMinutes();
                        var sec = today.getSeconds();
                        var filename = sourceData + "_details_" + dd + "-" + mm + "-" + yyyy + "-" + hour + "-" + minu + "-" + sec;

                        anchor.attr({
                            href: window.URL.createObjectURL(blob, { type: "text/plain" }),
                            download: filename + '.csv'
                        })[0].click();

                        anchor.remove();
                        if(response.status==200){
                            angular.element(document).find('.csvprogrss').text("Download Completed");
                            angular.element(document).find('.csvprogrss').fadeIn("slow");
                            setTimeout(function(){
                                angular.element(document).find('.csvprogrss').fadeOut("slow");
                            },2000);
                        }                        
                    }                   

                }).catch(function (response) {
                    if (response.status !== 200){

                        var errorMessage = "Download Failed";
                        if(response.xhrStatus === "timeout"){
                            errorMessage="Download failed. File size is too large to download."
                        }                        
                        angular.element(document).find('.csvprogrss').attr('style','border:solid 4px red').text(errorMessage);
                        angular.element(document).find('.csvprogrss').fadeIn("slow");
                        
                        setTimeout(function(){
                            angular.element(document).find('.csvprogrss').fadeOut("slow");                              
                            angular.element(document).find('.csvprogrss').removeAttr('style');                       
                        },5000);
                    }					
				});
        }
    }

    //Downloads the CSV file Well/Seismic
    $scope.downloadhomeCSV = function () {
        $rootScope.downloadCSV($scope.currentTab);
    }

    //Show QueryBuilder filter in applied filters
    $rootScope.qbappenable = function(){
        angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').removeClass('hide');
        angular.element('[data-fgname="surveyqb"]').parent('div').parent('.applied-filter-group').removeClass('hide');
        angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').removeClass('hide');
        angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
    }

    //Hide QueryBuilder filter in applied filters
    $rootScope.qbappdisable = function(){
        angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').addClass('hide');
        angular.element('[data-fgname="surveyqb"]').parent('div').parent('.applied-filter-group').addClass('hide');
        angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').addClass('hide');
        angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
    }

    //Hide Filters Applied text in applied filters`
    $rootScope.apptxtdisable = function(){
        
        angular.element(document).find('.applied-filter-section').find('button span:first').text('No filters applied');
        angular.element(document).find('.applied-filter-section').find('.btn-info').removeClass('filter-applied');
        angular.element(document).find('.detail-view-collapse-panel').removeClass('collapse in');
        angular.element(document).find('.detail-view-collapse-panel').addClass('collapse');
    }
    //Show Filters Applied text in applied filters
    $rootScope.apptxtenable = function(){
        angular.element(document).find('.applied-filter-section').find('button span:first').text('Filters applied');
        angular.element(document).find('.applied-filter-section').find('.btn-info').addClass('filter-applied');
        angular.element(document).find('.detail-view-collapse-panel').removeClass('collapse');
        angular.element(document).find('.detail-view-collapse-panel').addClass('collapse in');
    }
    
    //Set the applied filter text basedon the filter selected
    $rootScope.showAppliedtxt = function () {  
        var mapenable = angular.element('.mapappliedgrp').hasClass('hide');
         if($rootScope.detailView){
            $rootScope.qbappdisable(); // hide query builder in home screen
            if($rootScope.appgname=="Seismic"){
                $rootScope.apptxtdisable();
                angular.element('[data-fgname="surveyqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="sfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="surveyswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                if(angular.element('[data-fgname="sfcommon"]').length > 0 ){
                    $rootScope.apptxtenable();
                    angular.element('[data-fgname="sfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                }
                else if(!mapenable){
                    $rootScope.apptxtenable();
                }
            }
            else if($rootScope.appgname=="Well"){
                $rootScope.apptxtdisable();
                angular.element('[data-fgname="wfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                if(angular.element('[data-fgname="wfcommon"]').length > 0 ){
                    $rootScope.apptxtenable();
                    angular.element('[data-fgname="wfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                }
                else if(!mapenable){
                    $rootScope.apptxtenable();
                }
            }
        }
        else{
            $rootScope.qbappenable(); // show query builder in detail screen
            if($rootScope.appgname=="Seismic"){
                $rootScope.apptxtdisable();
                angular.element('[data-fgname="sfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="surveyqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="surveyswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                if(angular.element('[data-fgname="sfcommon"]').length > 0 || angular.element('[data-fgname="surveyqb"]').length > 0 || angular.element('[data-fgname="surveyswitch"]').length == 1){
                    $rootScope.apptxtenable();
                    if(angular.element('[data-fgname="sfcommon"]').length > 0 ){
                        angular.element('[data-fgname="sfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                    if(angular.element('[data-fgname="surveyswitch"]').length > 0 ){
                        angular.element('[data-fgname="surveyswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                    if(angular.element('[data-fgname="surveyqb"]').length > 0){
                        angular.element('[data-fgname="surveyqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                }
                else if(!mapenable){
                    $rootScope.apptxtenable();
                }
            }
            else if($rootScope.appgname=="Well"){
                $rootScope.apptxtdisable();
                angular.element('[data-fgname="wfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                if(angular.element('[data-fgname="wfcommon"]').length > 0 || angular.element('[data-fgname="wellqb"]').length > 0 || angular.element('[data-fgname="wellswitch"]').length > 0 ){
                    $rootScope.apptxtenable();
                    if(angular.element('[data-fgname="wfcommon"]').length > 0 ){
                        angular.element('[data-fgname="wfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                    if(angular.element('[data-fgname="wellswitch"]').length > 0 ){
                        angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                    if(angular.element('[data-fgname="wellqb"]').length > 0){
                        angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                }
                else if(!mapenable){
                    $rootScope.apptxtenable();
                }
            }
            else if($rootScope.appgname=="Interpretive"){
                $rootScope.apptxtdisable();
                angular.element('[data-fgname="wfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').addClass('hide');
                if(angular.element('[data-fgname="wfcommon"]').length > 0 || angular.element('[data-fgname="ipqb"]').length > 0){
                    $rootScope.apptxtenable();                    
                    if(angular.element('[data-fgname="wfcommon"]').length > 0){
                        angular.element('[data-fgname="wfcommon"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                        angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                    if(angular.element('[data-fgname="ipqb"]').length > 0){
                        angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').prev('.flt-title').removeClass('hide');
                    }
                }
                else if (!mapenable){
                    $rootScope.apptxtenable();
                }                
            }          
        }
    }

    //Goto details view page
    $scope.goDetail = function () {
        $rootScope.detailView = false;
        $rootScope.callsegyfromhome=false;
        angular.element('.surveySummaryPanel').hide();
       //If survey tile is selected, add it to surveyselectedValArr filter list       
        if (angular.element('.survey-tile-active').length > 0) {                        
            var surveyName = angular.element('.survey-tile-active').text();            
            if (SurveyService.allSurveyFilter == "") {
                SurveyService.allSurveyFilter = "SurveyName:" + surveyName;
                $rootScope.surveycollectFilterData("SurveyName", surveyName, "SurveyName");
                var obj = new Object();
                obj.value = [surveyName];
                obj.title = "SurveyName";
                obj.fgname = "sfcommon";
                $rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;
                $rootScope.surveyaplFilterData[$rootScope.surveyaplFilterData.length] = surveyName;
            }

            else {
                if (!SurveyService.allSurveyFilter.includes("SurveyName:")) {
                    SurveyService.allSurveyFilter = SurveyService.allSurveyFilter + " AND SurveyName:" + surveyName;
                    SurveyService.allSurveyFilter = "SurveyName:" + surveyName;
                    $rootScope.surveycollectFilterData("SurveyName", surveyName, "SurveyName");
                    var obj = new Object();
                    obj.value = [surveyName];
                    obj.title = "SurveyName";
                    obj.fgname = "sfcommon";
                    $rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;

                    $rootScope.surveyaplFilterData[$rootScope.surveyaplFilterData.length] = surveyName;
                }
            }

            $rootScope.callsegyfromhome=true;
            $location.path('/detail');       
            //Cascade data for the selected Survey tile     
            $rootScope.surveyHometoDetailCascade(surveyName);

        } else {            
            $location.path('/detail');
            var toggletxtNew = angular.element('.tools-section .btn-group label.active').text();
            if (toggletxtNew == "WELL") {
                window.fromwell = true;
                setTimeout(function () {
                    angular.element('.wellappliedgrp').find('.applied-filter-group').each(function () {
                        if(angular.element(this).find('.detail-view-label').text()=="SeismictoWellSwitch"){
                         angular.element(this).find('.detail-view-label').parent().parent().show()
                         
                     }});
                    angular.element('.nav.nav-tabs:first').find('li:nth-child(2)').find('a').click();
                    angular.element('.Wellfltrdetgrp').removeClass('hide');
                    angular.element('.Seismicfltrgrp').addClass('hide');
                    $scope.showQueryBuilderFilter();
                    $rootScope.filterNameGroup = "Well";
                }, 700);
            }
            if (toggletxtNew == "SURVEY") {
                window.fromwell = false;
                $rootScope.callsegyfromhome=true;
                setTimeout(function () {
                    angular.element('.surveyappliedgrp').find('.applied-filter-group').each(function () {
                        if(angular.element(this).find('.detail-view-label').text()=="WelltoSurveySwitch"){
                         angular.element(this).find('.detail-view-label').parent().parent().show()
                         
                     }});                    
                    angular.element('.Seismicfltrdetgrp').removeClass('hide');
                    angular.element('.Wellfltrgrp').addClass('hide');
                    $scope.showQueryBuilderFilter();
                    $rootScope.curTab = "SEGY";
                    $rootScope.filterNameGroup = "Seismic";
                }, 300);
            }
        }
        //Set uuid empty while coming from home to detail        
        $rootScope.uuid = "";                
    }

    //Shows QueryBuilderFilter values in applied filter
    $rootScope.showQueryBuilderFilter = function () {
        angular.element('.applied-filter-group').each(function () {
            if (angular.element(this).find('.detail-view-label').text() == "Query Builder Filter") {
                angular.element(this).find('.detail-view-label').parent('div').parent('div').show();
            }
        });
    }

    angular.element(document).on('click', '.tools-section .btn-group label', function () {
        var toggleTxt = angular.element(this).text();
        if (toggleTxt == "SURVEY") {
            $rootScope.appgname = "Seismic";
        	$rootScope.isSeismicClicked = true; 
            angular.element('.well-list-details').hide();
            angular.element('.survey-list-details').show();
            angular.element('.well-all-details').addClass('hide');
            angular.element('.Seismicfltrgrp').removeClass('hide');
            angular.element('.Wellfltrgrp').addClass('hide');
            angular.element('.Iprtvegrp').addClass('hide');
            $scope.currentTab = "";
            $rootScope.filterNameGroup = "Seismic";
            angular.element('.surveyappliedgrp').show();
            angular.element('.surveyappliedgrp').removeClass('hide');
            angular.element('.wellappliedgrp').hide();                        
            angular.element('.surveyappliedgrp').find('.applied-filter-group').each(function () {
                if (angular.element(this).find('.detail-view-label').text() == "WelltoSurveySwitch") {
                  angular.element(this).find('.detail-view-label').parent().parent().hide();    
                }
              });
            $rootScope.showAppliedtxt();            
            $rootScope.$broadcast("event:applySeismicFilters", {SurveyNames: window.mapallSurveyname, selectedTab: toggleTxt});
        }
        if (toggleTxt == "WELL") {            
            $rootScope.appgname = "Well";
            $rootScope.isWellClicked = true;
            WellService.allWellInfoService = WellService.homeUrl;
            angular.element('.surveySummaryPanel').hide();
            angular.element('.well-list-details').show();
            angular.element('.survey-list-details').hide();
            angular.element('.well-all-details').removeClass('hide');
            angular.element('.Wellfltrgrp').removeClass('hide');
            angular.element('.Seismicfltrgrp').addClass('hide');
            angular.element('.Iprtvegrp').addClass('hide');
            $scope.currentTab = "WELL";
            $rootScope.filterNameGroup = "Well";
            angular.element('.surveyappliedgrp').hide();
            angular.element('.wellappliedgrp').removeClass('hide');
            angular.element('.wellappliedgrp').show(); 
            $rootScope.$broadcast("event:applyWellFilters", {filterInfo:$rootScope.selectedFieldsDetails, selectedTab: toggleTxt});
            angular.element('.wellappliedgrp').find('.applied-filter-group').each(function () {
                if (angular.element(this).find('.detail-view-label').text() == "SeismictoWellSwitch") {
                  angular.element(this).find('.detail-view-label').parent().parent().hide()
                }
            });
            $rootScope.showAppliedtxt();
        }
    });

    angular.element(document).on('click', '.map-toggle-down', function () {        
        angular.element(".homecontentlist").hide();
        angular.element(".wellpagger").hide();        
        angular.element(".map-toggle-down").addClass('hide');
        angular.element(".map-toggle-up").removeClass('hide');
        angular.element(".applied-filter-section").addClass('show');        
    var sheight = window.innerHeight;
        angular.element('#viewDiv').css('height', sheight - 175+"px");        
    });

    angular.element(document).on('click', '.map-toggle-up', function () {
        angular.element(".homecontentlist").show();
        angular.element(".wellpagger").show();
        angular.element(".map-toggle-up").addClass('hide');
        angular.element(".map-toggle-down").removeClass('hide');        
        var sheight = window.innerHeight;
        angular.element('#viewDiv').css('height', sheight - 290+"px");        
    });
})
