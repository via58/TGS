/*
File Name:- detailsController.js
Summary:- Loads the details for the current tab.
*/

angular.module('TGSApp').controller('detailsController', function ($scope, $uibModal, $rootScope, $http, WellService, SurveyService, Common, InterpretiveService) {
    $rootScope.curTab = "";
    $rootScope.filterNameForNavigation = "";
    angular.element('.Wellfltrgrp').addClass('hide');
    $rootScope.wellSwitchFlag = false;
    $rootScope.seismicSwitchFlag = false;



    angular.element('.Seismicfltrdetgrp').removeClass('hide');

    angular.element('.sub-header').find('.imaginary_container').hide();

    angular.element('.sub-header').find('.showhome').show();

    angular.element(document).find('.mapSidepanelbtn').show();
    localStorage.clear();
    angular.element('.sub-header').find('.importmapicon').hide();
    //Sets/Removes the Filters Applied message in applied filters
    $rootScope.showAppliedtxt();   

    //Shows the settings details for the current tab
    $scope.openModal = function () {
        $scope.modalInstance = $uibModal.open({
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            templateUrl: 'partials/common/settingModal.html',
            controller: 'settingsModelController',
            controllerAs: '$ctrl',
            size: 'lg',

            resolve: {

                "args": function () {
                    return {
                        currentTab: $rootScope.curTab
                    }
                }
            }
        });
    }

    //Downloads the current tab data as csv file
    $rootScope.dpdownload = function (sourceData) {

        if (sourceData !== "" && sourceData !== undefined) {

            var downloadUrl = "";
            var downloadRequest = "";
            var geoSpatialFilter = "";
            var LatLongGeoShapeFilter = "";
            var surveyEntitlementUrl = "";

            if ((sourceData == "LAS" || sourceData == "Production" || sourceData == "Raster" || sourceData == 'VWH'
                || sourceData == "InterpretiveLas" || sourceData == "InterpretiveDocLibrary" || sourceData == "interpretiveDSDP" || sourceData == "interpretivePWA" || sourceData == "BioStratTops"
                || sourceData == "ChronoStratTops" || sourceData == "CoreTops" || sourceData == "EnvFaciesTops" || sourceData == "LithoStratTops" || sourceData == "LithologyTops"
                || sourceData == "MaturityTypeTops" || sourceData == "RockEvaluationTops" || sourceData == "SequenceStratTops" || sourceData == "Showtops" || sourceData == "VisualMaceralTops") && window.drawPolygon) {
                geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
            }
            else if ((sourceData == "Horizon" || sourceData == "Velocity" || sourceData == "AeroMag" || sourceData == "GravMag") && window.drawPolygon) {
                geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);
            }

            var entitlementUrl = Common.getWellEntitlementUrl();
            if (entitlementUrl == "" && $rootScope.WellEntitleUrl) {
                entitlementUrl = $rootScope.WellEntitleUrl;
            }
            //Get uuid when download csv in switch
            var uuid = Common.getUuid();

            if (sourceData == "SEGY" && window.drawPolygon) {
                geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);
                LatLongGeoShapeFilter = Common.getLatLongGeoShapeFilter();
            }

            if (sourceData == "VWH") {
                downloadRequest = Common.getDetailCSVDownload("Well", "VWH", WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "Raster") {
                downloadRequest = Common.getDetailCSVDownload("Well", "Raster", WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "LAS") {
                downloadRequest = Common.getDetailCSVDownload("Well", "Las", WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "Production") {
                downloadRequest = Common.getDetailCSVDownload("Well", "Production", WellService.allWellFilter, geoSpatialFilter, "", WellService.wellQueryBuilder, entitlementUrl, "", uuid);
            }
            // Interpretive
            else if (sourceData == "InterpretiveLas") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "FmbLas", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }

            else if (sourceData == "InterpretiveDocLibrary") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "DocLib", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "interpretiveDSDP") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "DSDP", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "interpretivePWA") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "PWA", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            //Formations
            else if (sourceData == "BioStratTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "BioStratTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "ChronoStratTops") {

                downloadRequest = Common.getDetailCSVDownload("Interpretive", "ChronoStratTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "CoreTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "CoreTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "EnvFaciesTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "EnvironmentFaciesTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "LithoStratTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "LithoStratTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "LithologyTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "LithologyTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "MaturityTypeTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "MaturityTypeTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "RockEvaluationTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "RockEvaluationTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "SequenceStratTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "SequenceStratTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "Showtops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "ShowTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            else if (sourceData == "VisualMaceralTops") {
                downloadRequest = Common.getDetailCSVDownload("Interpretive", "VisualMaceralTops", WellService.allWellFilter, geoSpatialFilter, "", InterpretiveService.ipQueryBuilder, entitlementUrl, "", uuid);
            }
            //Seismic
            else if (sourceData == "SEGY") {
                surveyEntitlementUrl = Common.getSurveyEntitlementUrl();
                if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
                    surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
                }

                downloadRequest = Common.getDetailCSVDownload("Seismic", 'SEGY', SurveyService.allSurveyFilter, geoSpatialFilter, LatLongGeoShapeFilter, SurveyService.surveyQueryBuilder, surveyEntitlementUrl, "", uuid);
            }
            else if (sourceData == "Horizon") {
                var projNameFilterExist = false;
                surveyEntitlementUrl = Common.getSurveyHorizonEntitlementUrl();
                if (surveyEntitlementUrl == "" && $rootScope.horizonEntitlementUrl) {
                    surveyEntitlementUrl = $rootScope.horizonEntitlementUrl;
                }
                if (surveyEntitlementUrl !== "") {
                    for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                        if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "ProjectName") {
                            projNameFilterExist = true;
                        }
                    }
                    if ($rootScope.surveyselectedValArr.length > 0) {
                        for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                            var QBObj = $rootScope.surveyselectedValArr[i].value;
                            for (var j = 0; j < QBObj.length; j++) {
                                if (QBObj[j].includes("ProjectName:")) {
                                    projNameFilterExist = true;
                                }
                            }
                        }
                    }

                    if (!projNameFilterExist) {
                        $.alertable.alert("Please apply 'Project Name' filter to download csv file data.");
                        return false;
                    }
                }
                if (surveyEntitlementUrl) {
                    downloadRequest = Common.getDetailCSVDownload("Seismic", 'Horizon', SurveyService.allSurveyFilter, geoSpatialFilter, "", SurveyService.surveyQueryBuilder, surveyEntitlementUrl, $rootScope.horizonsurveyType, uuid);
                }
                else {
                    downloadRequest = Common.getDetailCSVDownload("Seismic", 'Horizon', SurveyService.allSurveyFilter, geoSpatialFilter, "", SurveyService.surveyQueryBuilder, surveyEntitlementUrl, "", uuid);
                }
                //  downloadUrl = downloadHorizonUrl + SurveyService.allSurveyFilter + geoSpatialFilter + SurveyService.surveyQueryBuilder + surveyEntitlementUrl;
            }
            else if (sourceData == "Velocity") {
                surveyEntitlementUrl = Common.getSurveyEntitlementUrl();
                if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
                    surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
                }
                downloadRequest = Common.getDetailCSVDownload("Seismic", 'Velocity', SurveyService.allSurveyFilter, geoSpatialFilter, "", SurveyService.surveyQueryBuilder, surveyEntitlementUrl, "", uuid);
            }
            else if (sourceData == "AeroMag") {
                var projNameFilterExist = false;
                surveyEntitlementUrl = Common.getSurveyAeroMagEntitlementUrl();

                if (surveyEntitlementUrl == "" && $rootScope.aeroMagEntitlementUrl) {
                    surveyEntitlementUrl = $rootScope.aeroMagEntitlementUrl;
                }
                if (surveyEntitlementUrl !== "") {
                    for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                        if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "ProjectName") {
                            projNameFilterExist = true;
                        }
                    }
                    if ($rootScope.surveyselectedValArr.length > 0) {
                        for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                            var QBObj = $rootScope.surveyselectedValArr[i].value;
                            for (var j = 0; j < QBObj.length; j++) {
                                if (QBObj[j].includes("ProjectName:")) {
                                    projNameFilterExist = true;
                                }
                            }
                        }
                    }
                    if (!projNameFilterExist) {
                        $.alertable.alert("Please apply 'Project Name' filter to download csv file data.");
                        return false;
                    }
                }
                if (surveyEntitlementUrl) {
                    downloadRequest = Common.getDetailCSVDownload("Seismic", "AeroMag", SurveyService.allSurveyFilter, geoSpatialFilter, "", SurveyService.surveyQueryBuilder, surveyEntitlementUrl, $rootScope.AeroMagSurveyType, uuid);
                }
                else {
                    downloadRequest = Common.getDetailCSVDownload("Seismic", "AeroMag", SurveyService.allSurveyFilter, geoSpatialFilter, "", SurveyService.surveyQueryBuilder, surveyEntitlementUrl, "", uuid);
                }
            }
            else if (sourceData == "GravMag") {
                var projNameFilterExist = false;
                surveyEntitlementUrl = Common.getSurveyGravMagEntitlementUrl();
                if (surveyEntitlementUrl == "" && $rootScope.gravMagEntitlementUrl) {
                    surveyEntitlementUrl = $rootScope.gravMagEntitlementUrl;
                }
                if (surveyEntitlementUrl !== "") {
                    for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                        if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "ProjectName") {
                            projNameFilterExist = true;
                        }
                    }

                    if ($rootScope.surveyselectedValArr.length > 0) {
                        for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                            var QBObj = $rootScope.surveyselectedValArr[i].value;
                            for (var j = 0; j < QBObj.length; j++) {
                                if (QBObj[j].includes("ProjectName:")) {
                                    projNameFilterExist = true;
                                }
                            }
                        }
                    }

                    if (!projNameFilterExist) {
                        $.alertable.alert("Please apply 'Project Name' filter to download csv file data.");
                        return false;
                    }
                }
                if (surveyEntitlementUrl) {
                    downloadRequest = Common.getDetailCSVDownload("Seismic", "GravMag", SurveyService.allSurveyFilter, geoSpatialFilter, "", SurveyService.surveyQueryBuilder, surveyEntitlementUrl, $rootScope.GravMagSurveyType, uuid);
                }
                else {
                    downloadRequest = Common.getDetailCSVDownload("Seismic", "GravMag", SurveyService.allSurveyFilter, geoSpatialFilter, "", SurveyService.surveyQueryBuilder, surveyEntitlementUrl, "", uuid);
                }
            }

            angular.element(document).find('.csvprogrss').text("Downloading File...");
            angular.element(document).find('.csvprogrss').fadeIn("slow");
            setTimeout(function () {
                angular.element(document).find('.csvprogrss').fadeOut("slow");
            }, 2000);

            $http(downloadRequest, { timeout: 300000 }).
                then(function (response) {
                    if (response.data !== null && response.data !== undefined) {
                        var blob = new Blob([response.data]);
                        var anchor = angular.element('<a>');
                        anchor.css({ display: 'none' }); // Make sure it's not visible
                        angular.element(document.body).append(anchor); // Attach to document
                        var today = new Date();
                        var dd = today.getDate();
                        var mm = today.getMonth() + 1; //January is 0!
                        var yyyy = today.getFullYear();
                        var hour = today.getHours();
                        var minu = today.getMinutes();
                        var sec = today.getSeconds();
                        var filename = sourceData + "_details_" + dd + "-" + mm + "-" + yyyy + "-" + hour + "-" + minu + "-" + sec;

                        anchor.attr({
                            href: window.URL.createObjectURL(blob, { type: "text/plain" }),
                            download: filename + '.csv'
                        })[0].click();
                        anchor.remove();
                        if (response.status == 200) {

                            angular.element(document).find('.csvprogrss').text("Download Completed");
                            angular.element(document).find('.csvprogrss').fadeIn("slow");
                            setTimeout(function () {
                                angular.element(document).find('.csvprogrss').fadeOut("slow");
                            }, 2000);
                        }
                    }
                }).catch(function (response) {
                    if (response.status !== 200) {
                        var errorMessage = "Download Failed";
                        if (response.xhrStatus === "timeout") {
                            errorMessage = "Download failed. File size is too large to download."
                        }
                        angular.element(document).find('.csvprogrss').attr('style', 'border:solid 4px red').text(errorMessage);
                        angular.element(document).find('.csvprogrss').fadeIn("slow");
                        setTimeout(function () {
                            angular.element(document).find('.csvprogrss').fadeOut("slow");
                            angular.element(document).find('.csvprogrss').removeAttr('style');
                        }, 5000);
                    }
                });
        }
    }


    $scope.downloaddpCSV = function () {
        $rootScope.dpdownload($rootScope.curTab);
    }

    //Downloads trace file data as csv file
    $scope.downloadTraceCSV = function (item) {
        $rootScope.downloadTraceFile($rootScope.curTab, item);
    }

    $rootScope.downloadTraceFile = function (sourceData, fileData) {
        var downloadSEGYUrl = "";
        var downloadvelocityUrl = "";
        var geoSpatialFilter = "";
        var LatLongGeoShapeFilter = "";

        if (sourceData !== "" && sourceData !== undefined) {

            if (sourceData == "SEGY") {
                if (window.drawPolygon) {
                    geoSpatialFilter = Common.getTraceGeoSpatialFilter();
                    //LatLongGeoShapeFilter = Common.getLatLongGeoShapeFilter();
                }

                if ($rootScope.isExternalUser) {
                    var surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    if (fileData.ProjectType[0] == "2D")
                        var downloadSEGYObj = {
                            tabName: "SEGY",
                            ProjectID: fileData.ProjectID[0],
                            LineNumber: fileData.LineNumber[0],
                            surveyType: "2D",
                            S3FileName: fileData.S3FileName[0],
                            S3VelocityFileName: "",
                            customerId: surveyEntitlementUrl
                        }

                    else {
                        var downloadSEGYObj = {
                            tabName: "SEGY",
                            ProjectID: fileData.ProjectID[0],
                            LineNumber: "",
                            surveyType: "3D",
                            S3FileName: fileData.S3FileName[0],
                            S3VelocityFileName: "",
                            customerId: surveyEntitlementUrl
                        }
                    }
                }
                else {
                    if ($rootScope.surveyCustomer !== undefined && $rootScope.surveyCustomer !== "") {
                        var surveyEntitlementUrl = $rootScope.surveyCustomer.customerId;
                        if (fileData.ProjectType[0] == "2D")
                            var downloadSEGYObj = {
                                tabName: "SEGY",
                                ProjectID: fileData.ProjectID[0],
                                LineNumber: fileData.LineNumber[0],
                                surveyType: "2D",
                                S3FileName: fileData.S3FileName[0],
                                S3VelocityFileName: "",
                                customerId: surveyEntitlementUrl
                            }
                        else
                            var downloadSEGYObj = {
                                tabName: "SEGY",
                                ProjectID: fileData.ProjectID[0],
                                LineNumber: "",
                                surveyType: "3D",
                                S3FileName: fileData.S3FileName[0],
                                S3VelocityFileName: "",
                                customerId: surveyEntitlementUrl
                            }
                    }
                    else {
                        var surveyEntitlementUrl = "";
                        var downloadSEGYObj = {
                            tabName: "SEGY",
                            ProjectID: "",
                            LineNumber: "",
                            surveyType: "",
                            S3FileName: fileData.S3FileName[0],
                            S3VelocityFileName: "",
                            customerId: surveyEntitlementUrl
                        }
                    }
                }
            }
            if (sourceData == "Velocity") {
                if (window.drawPolygon) {
                    geoSpatialFilter = Common.getTraceGeoSpatialFilter();
                }

                if ($rootScope.isExternalUser) {
                    var surveyEntitlementUrl = $rootScope.externalUser.seismicCustomerID;
                    if (fileData.ProjectType[0] == "2D")
                        var downloadvelocityObj = {
                            tabName: "Velocity",
                            ProjectID: fileData.ProjectID[0],
                            surveyType: "2D",
                            S3FileName: "",
                            S3VelocityFileName: fileData.S3VelocityFileName[0],
                            customerId: surveyEntitlementUrl
                        }
                    else
                        var downloadvelocityObj = {
                            tabName: "Velocity",
                            ProjectID: fileData.ProjectID[0],
                            surveyType: "3D",
                            S3FileName: "",
                            S3VelocityFileName: fileData.S3VelocityFileName[0],
                            customerId: surveyEntitlementUrl
                        }

                }
                else {
                    if ($rootScope.surveyCustomer !== undefined && $rootScope.surveyCustomer !== "") {
                        var surveyEntitlementUrl = $rootScope.surveyCustomer.customerId;
                        if (fileData.ProjectType[0] == "2D")
                            var downloadvelocityObj = {
                                tabName: "Velocity",
                                ProjectID: fileData.ProjectID[0],
                                surveyType: "2D",
                                S3FileName: "",
                                S3VelocityFileName: fileData.S3VelocityFileName[0],
                                customerId: surveyEntitlementUrl
                            }
                        else
                            var downloadvelocityObj = {
                                tabName: "Velocity",
                                ProjectID: fileData.ProjectID[0],
                                surveyType: "3D",
                                S3FileName: "",
                                S3VelocityFileName: fileData.S3VelocityFileName[0],
                                customerId: surveyEntitlementUrl
                            }
                    }
                    else {
                        var surveyEntitlementUrl = "";
                        var downloadvelocityObj = {
                            tabName: "Velocity",
                            ProjectID: fileData.ProjectID[0],
                            surveyType: "",
                            S3FileName: "",
                            S3VelocityFileName: fileData.S3VelocityFileName[0],
                            customerId: surveyEntitlementUrl
                        }
                    }
                }
            }
            //Seismic 
            var downloadRequest = "";

            if (sourceData == "SEGY") {
                downloadRequest = Common.getTraceLevelCSVDownload(downloadSEGYObj, SurveyService.allSurveyFilter,
                    geoSpatialFilter, SurveyService.surveyQueryBuilder)
            }

            else if (sourceData == "Velocity") {
                downloadRequest = Common.getTraceLevelCSVDownload(downloadvelocityObj, SurveyService.allSurveyFilter,
                    geoSpatialFilter, SurveyService.surveyQueryBuilder)
            }

            angular.element(document).find('.csvprogrss').text("Downloading File....");
            angular.element(document).find('.csvprogrss').fadeIn("slow");
            setTimeout(function () {
                angular.element(document).find('.csvprogrss').fadeOut("slow");
            }, 2000);

            $http(downloadRequest, { timeout: 300000 })
                .then(function (response) {
                    if (response.data !== null && response.data !== undefined) {
                        var blob = new Blob([response.data]);
                        var anchor = angular.element('<a>');
                        anchor.css({ display: 'none' }); // Make sure it's not visible
                        angular.element(document.body).append(anchor);
                        var today = new Date();
                        var dd = today.getDate();
                        var mm = today.getMonth() + 1; //January is 0!
                        var yyyy = today.getFullYear();
                        var hour = today.getHours();
                        var minu = today.getMinutes();
                        var sec = today.getSeconds();
                        var filename = sourceData + "_details_" + dd + "-" + mm + "-" + yyyy + "-" + hour + "-" + minu + "-" + sec;

                        anchor.attr({
                            href: window.URL.createObjectURL(blob, { type: "text/plain" }),
                            download: filename + '.csv'
                        })[0].click();

                        anchor.remove();

                        if (response.status == 200) {
                            angular.element(document).find('.csvprogrss').text("Download Completed");
                            angular.element(document).find('.csvprogrss').fadeIn("slow");
                            setTimeout(function () {
                                angular.element(document).find('.csvprogrss').fadeOut("slow");
                            }, 2000);
                        }
                    }

                }).catch(function (response) {
                    if (response.status !== 200) {
                        var errorMessage = "Download Failed";
                        if (response.xhrStatus === "timeout") {
                            errorMessage = "Download failed. File size is too large to download."
                        }
                        angular.element(document).find('.csvprogrss').attr('style', 'border:solid 4px red').text(errorMessage);
                        angular.element(document).find('.csvprogrss').fadeIn("slow");
                        setTimeout(function () {
                            angular.element(document).find('.csvprogrss').fadeOut("slow");
                            angular.element(document).find('.csvprogrss').removeAttr('style');
                        }, 5000);
                    }
                });
        }
    }

    //Form the UUID filter for Well
    $rootScope.welluuidformFilter = function () {

        var SeismicfilterStr = "";
        $rootScope.surveyaplFilterData = [];
        $rootScope.surveyaplFilterTitle = [];
        for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
            if ($rootScope.surveyselectedFieldsDetails[i].fieldValue !== "" && $rootScope.surveyselectedFieldsDetails[i].fieldName == "WelltoSurveySwitch") {
                $rootScope.surveyaplFilterData[$rootScope.surveyaplFilterData.length] = $rootScope.surveyselectedFieldsDetails[i].displayName;
                $rootScope.surveyaplFilterTitle[$rootScope.surveyaplFilterTitle.length] = $rootScope.surveyselectedFieldsDetails[i].titleName;
            }
        }

        var obj = new Object();
        obj.value = ["WelltoSurveySwitch"];
        obj.title = "WelltoSurveySwitch";
        obj.fgname = "surveyswitch";
        obj.type = "switchfiltr";
        if ($rootScope.surveyselectedValArr.length == 0)
            $rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;
        else {
            var surveySwitchexist = false;
            for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                if ($rootScope.surveyselectedValArr[i].title == "WelltoSurveySwitch")
                    surveySwitchexist = true;
            }
            if (!surveySwitchexist)
                $rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;
        }
    }

    //Form the UUID filter for Seismic
    $rootScope.surveyuuidformFilter = function () {

        var SeismicfilterStr = "";
        $rootScope.aplFilterData = [];
        $rootScope.aplFilterTitle = [];
        for (var i = 0; i < $rootScope.selectedFieldsDetails.length; i++) {
            if ($rootScope.selectedFieldsDetails[i].fieldValue !== "" && $rootScope.selectedFieldsDetails[i].fieldName == "SeismictoWellSwitch") {
                $rootScope.aplFilterData[$rootScope.surveyaplFilterData.length] = $rootScope.selectedFieldsDetails[i].displayName;
                $rootScope.aplFilterTitle[$rootScope.surveyaplFilterTitle.length] = $rootScope.selectedFieldsDetails[i].titleName;
            }
        }

        var obj = new Object();
        obj.value = ["SeismictoWellSwitch"];
        obj.title = "SeismictoWellSwitch";
        obj.fgname = "wellswitch";
        obj.type = "switchfiltr";
        if ($rootScope.selectedValArr.length == 0)
            $rootScope.selectedValArr[$rootScope.selectedValArr.length] = obj;
        else {
            var wellSwitchexist = false;
            for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
                if ($rootScope.selectedValArr[i].title == "SeismictoWellSwitch")
                    wellSwitchexist = true;
            }
            if (!wellSwitchexist)
                $rootScope.selectedValArr[$rootScope.selectedValArr.length] = obj;
        }
    }

    //Collects the Well UUID filter data
    $scope.collectwellUUIDData = function (fieldName, uuid, titleName) {
        if ($rootScope.surveyselectedFieldsDetails.length > 0) {
            var isSwitchExist = false;
            for (var c = 0; c < $rootScope.surveyselectedFieldsDetails.length; c++) {
                if ($rootScope.surveyselectedFieldsDetails[c].fieldName == "WelltoSurveySwitch") {
                    $rootScope.uuid = uuid;
                    isSwitchExist = true;
                }
            }
            if (!isSwitchExist) {
                var obj = new Object();
                obj.fieldName = fieldName;
                obj.fieldValue = uuid;
                obj.titleName = titleName;
                obj.displayName = fieldName;

                $rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
            }

        }
        else {
            var obj = new Object();
            obj.fieldName = fieldName;
            obj.fieldValue = uuid;
            obj.titleName = titleName;
            obj.displayName = fieldName;
            $rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
        }
    }

    //Collects the Survey UUID filter data
    $scope.collectsurveyUUIDData = function (fieldName, uuid, titleName) {
        if ($rootScope.selectedFieldsDetails.length > 0) {
            var isSwitchExist = false;
            for (var c = 0; c < $rootScope.selectedFieldsDetails.length; c++) {
                if ($rootScope.selectedFieldsDetails[c].fieldName == "SeismictoWellSwitch") {
                    $rootScope.uuid = uuid;
                    isSwitchExist = true;
                }
            }
            if (!isSwitchExist) {
                var obj = new Object();
                obj.fieldName = fieldName;
                obj.fieldValue = uuid;
                obj.titleName = titleName;
                obj.displayName = fieldName;
                $rootScope.selectedFieldsDetails[$rootScope.selectedFieldsDetails.length] = obj;
            }

        }
        else {
            var obj = new Object();
            obj.fieldName = fieldName;
            obj.fieldValue = uuid;
            obj.titleName = titleName;
            obj.displayName = fieldName;
            $rootScope.selectedFieldsDetails[$rootScope.selectedFieldsDetails.length] = obj;
        }
    }

    $rootScope.prevTab = ['SEGY'];

    //Loads current tab details
    angular.element(document).on('click', '.nav.nav-tabs li a', function (e) {

        //Disable the tabs while loading data
        angular.element(document).find('.nav.nav-tabs').find('.isTabDisable').removeClass('hide');
        if (angular.element(this).text() == "SEISMIC") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.appgname = "Seismic";

            angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').hide();
            $rootScope.filterNameForNavigation = "SEISMIC";

            if ($rootScope.filterNameGroup == "Seismic") {
                $rootScope.seismicSegYtab();
            }
            if ($rootScope.seismicSwitchfliterFlag) {
                $rootScope.seismicSegYtab();
            }
            angular.element('.Seismicfltrgrp').removeClass('hide');
            angular.element('.Seismicfltrdetgrp').removeClass('hide');
            angular.element('.Wellfltrgrp').addClass('hide');
            angular.element('.Wellfltrdetgrp').addClass('hide');
            angular.element('.Iprtvegrp').addClass('hide');
            angular.element('.detail-view-tab > .filter-setting').removeClass('hide');
            if ($rootScope.filterNameGroup == "Well" && !$rootScope.isSeismicClicked) {
                $rootScope.seismicSwitchFlag = true;

                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

                if (WellService.allWellFilter !== "" || WellService.wellQueryBuilder !== "") {
                    $scope.segData = [];
                    var newuuid = Common.getUuid();
                    angular.element(document.body).append('<div id="overlay"><div class="spinner"></div></div>');

                    // Gets the customerId filter                    
                    var customerFilter = Common.getWellEntitlementUrl();
                    if (customerFilter == "" && $rootScope.WellEntitleUrl) {
                        customerFilter = $rootScope.WellEntitleUrl;
                    }

                    var request = Common.getSwitchPostReqParams(WellService.allWellFilter, geoSpatialFilter, WellService.wellQueryBuilder,
                        newuuid, $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                    $rootScope.filterNameGroup = "Seismic";
                    $rootScope.curTab = "SEGY";
                    $rootScope.prevTab = [];
                    $rootScope.prevTab.push($rootScope.curTab);
                    $http(request).
                        then(function (response) {
                            $rootScope.uuid = "";
                            $rootScope.uuid = response.data;
                            $rootScope.surveyuuid = $rootScope.uuid;
                            $rootScope.seismicSwitchFlag = false;
                            $scope.collectwellUUIDData("WelltoSurveySwitch", $rootScope.uuid, "WelltoSurveySwitch");
                            $rootScope.welluuidformFilter();
                            $rootScope.seismicSegYtab();

                            setTimeout(function () {
                                $rootScope.showAppliedtxt();
                                angular.element(document.body).find('#overlay').remove();
                                //angular.element(document.body).find('.pagerspinner').remove();
                            }, 2000);
                        }).catch(function (response) {
                            if (response.status == 500) {
                                angular.element(document.body).find('#overlay').remove();
                                //angular.element(document.body).find('.pagerspinner').remove();
                            }
                        });
                }
                else {
                    $rootScope.seismicSwitchFlag = false;
                    $rootScope.filterNameGroup == "Seismic"
                    if ($rootScope.uuid !== "" && $rootScope.uuid !== undefined) {
                        $rootScope.surveyuuid = "";
                        $rootScope.uuid = "";
                    }
                    angular.element('[data-fgname="surveyswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').hide();
                    angular.element('[data-fgname="surveyswitch"]').parent('div').parent('.applied-filter-group').remove();
                    for (j = 0; j < $rootScope.surveyselectedValArr.length; j++) {
                        if ($rootScope.surveyselectedValArr[j].title == "WelltoSurveySwitch")
                            $rootScope.surveyselectedValArr.splice(j, 1);
                    }

                    for (k = 0; k < $rootScope.surveyselectedFieldsDetails.length; k++) {
                        if ($rootScope.surveyselectedFieldsDetails[k].fieldName == "WelltoSurveySwitch")
                            $rootScope.surveyselectedFieldsDetails.splice(k, 1);
                    }
                    $rootScope.segyCount = 1;
                    setTimeout(function () {
                        if ($rootScope.segyCount == 1) {
                            $rootScope.seismicSegYtab();
                            $rootScope.showAppliedtxt();
                            $rootScope.segyCount += 1;
                        }
                    }, 400);
                }
            }
            else if ($rootScope.filterNameGroup == "interpretive") {
                $rootScope.filterNameGroup = "Seismic";
                $rootScope.curTab = "SEGY";
                $rootScope.uuid = "";
                for (j = 0; j < $rootScope.surveyselectedValArr.length; j++) {
                    if ($rootScope.surveyselectedValArr[j].title == "WelltoSurveySwitch")
                        $rootScope.surveyselectedValArr.splice(j, 1);
                }

                for (k = 0; k < $rootScope.surveyselectedFieldsDetails.length; k++) {
                    if ($rootScope.surveyselectedFieldsDetails[k].fieldName == "WelltoSurveySwitch")
                        $rootScope.surveyselectedFieldsDetails.splice(k, 1);
                }
                $rootScope.seismicSegYtab();
                setTimeout(function () {
                    $rootScope.showAppliedtxt();
                }, 1500)
            }

            setTimeout(function () {
                $rootScope.filterNameGroup = "Seismic";
                $rootScope.curTab = "SEGY";
                $rootScope.prevTab = [];
                $rootScope.prevTab.push($rootScope.curTab);
                setTimeout($rootScope.retainFields, 4000);
                $rootScope.showAppliedtxt();
            }, 1000);
            angular.element('.ipappliedgrp').addClass('hide');
            angular.element('.wellappliedgrp').addClass('hide');
            angular.element('.surveyappliedgrp').removeClass('hide');
            angular.element('.surveyappliedgrp').show();

            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.nav-tabs').find('li:first').addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.tab-content').find('.tab-pane').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.tab-content').find('.tab-pane:first').addClass('active');

            angular.element('[data-fgname="surveyqb"]').parent('div').parent('.applied-filter-group').show();
        }
        else if (angular.element(this).text() == "SEGY") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            if ($rootScope.filterNameGroup == "Well" && !$rootScope.isSeismicClicked) {
                $rootScope.seismicSwitchFlag = true;

                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);
            }
            $rootScope.isWellClicked = false;
            $rootScope.isSeismicClicked = false;
            $rootScope.curTab = "SEGY";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.isWellClicked = false;
            $rootScope.isSeismicClicked = false;
            $rootScope.segyCnt = 1;
            setTimeout(function () {
                if ($rootScope.segyCnt == 1) {
                    $rootScope.seismicSegYtab();
                    $rootScope.filterNameGroup = "Seismic";
                    angular.element('.surveyappliedgrp').show();
                    angular.element('.wellappliedgrp').hide();
                    $rootScope.segyCnt += 1;
                }
            }, 1000);
        }
        else if (angular.element(this).text() == "Horizon") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');

            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            if ($rootScope.filterNameGroup == "Well") {

                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

                // Gets the customerId Filter.
                var customerFilter = Common.getWellEntitlementUrl();
                if (customerFilter == "" && $rootScope.WellEntitleUrl) {
                    customerFilter = $rootScope.WellEntitleUrl;
                }

                var request = Common.getSwitchPostReqParams(WellService.allWellFilter, geoSpatialFilter,
                    WellService.wellQueryBuilder, "", $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request).
                    then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                        if (response.status == 500) {

                            angular.element(document.body).find('#overlay').remove();
                        }
                    });
            }
            $rootScope.curTab = "Horizon";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.horCnt = 1;
            setTimeout(function () {
                if ($rootScope.horCnt == 1) {
                    $rootScope.filterNameGroup = "Seismic";
                    $rootScope.seismicHorizontab();
                    $rootScope.horCnt += 1;
                }
            }, 1000);
            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(2)').addClass('active');
        }
        else if (angular.element(this).text() == "Velocity") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter          
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            if ($rootScope.filterNameGroup == "Well") {

                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

                // gets the customer Id Filter.
                var customerFilter = Common.getWellEntitlementUrl();
                if (customerFilter == "" && $rootScope.WellEntitleUrl) {
                    customerFilter = $rootScope.WellEntitleUrl;
                }

                var request = Common.getSwitchPostReqParams(WellService.allWellFilter, geoSpatialFilter,
                    WellService.wellQueryBuilder, "", $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request)
                    .then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                    });
            }
            $rootScope.curTab = "Velocity";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.velCnt = 1;
            setTimeout(function () {
                if ($rootScope.velCnt == 1) {
                    $rootScope.filterNameGroup = "Seismic";
                    $rootScope.seismicVelocitytab();
                    $rootScope.velCnt += 1;
                }
            }, 1000);
            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(3)').addClass('active');
        }
        else if (angular.element(this).text() == "GravMag") {

            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            if ($rootScope.filterNameGroup == "Well") {

                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

                // Gets the customer Id Filter.
                var customerFilter = Common.getWellEntitlementUrl();
                if (customerFilter == "" && $rootScope.WellEntitleUrl) {
                    customerFilter = $rootScope.WellEntitleUrl;
                }

                var request = Common.getSwitchPostReqParams(WellService.allWellFilter, geoSpatialFilter,
                    WellService.wellQueryBuilder, "", $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request)
                    .then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                    });
            }
            $rootScope.curTab = "GravMag";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.grmgCnt = 1;
            setTimeout(function () {
                if ($rootScope.grmgCnt == 1) {
                    $rootScope.filterNameGroup = "Seismic";
                    $rootScope.seismicGravMagtab();
                    $rootScope.grmgCnt += 1;
                }
            }, 1000);
            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(5)').addClass('active');
        }
        else if (angular.element(this).text() == "AeroMag") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            if ($rootScope.filterNameGroup == "Well") {

                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

                // Gets the customer Id Filter.
                var customerFilter = Common.getWellEntitlementUrl();
                if (customerFilter == "" && $rootScope.WellEntitleUrl) {
                    customerFilter = $rootScope.WellEntitleUrl;
                }

                var request = Common.getSwitchPostReqParams(WellService.allWellFilter, geoSpatialFilter,
                    WellService.wellQueryBuilder, "", $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request)
                    .then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                    });
            }
            $rootScope.curTab = "AeroMag";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.armgCnt = 1;
            setTimeout(function () {
                if ($rootScope.armgCnt == 1) {
                    $rootScope.filterNameGroup = "Seismic";
                    $rootScope.seismicAeroMagtab();
                    $rootScope.armgCnt += 1;
                }
            }, 1000);
            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(4)').addClass('active');

        }
        else if (angular.element(this).text() == "Spec Sheets") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            if ($rootScope.filterNameGroup == "Well") {
                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getWellgeoSpatialFilter(WellService.allWellFilter);

                // Gets the customer Id Filter.
                var customerFilter = Common.getWellEntitlementUrl();
                if (customerFilter == "" && $rootScope.WellEntitleUrl) {
                    customerFilter = $rootScope.WellEntitleUrl;
                }

                var request = Common.getSwitchPostReqParams(WellService.allWellFilter, geoSpatialFilter,
                    WellService.wellQueryBuilder, "", $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request)
                    .then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                        if (response.status == 500) {
                            angular.element(document.body).find('#overlay').remove();
                        }
                    });
            }

            $rootScope.curTab = "Spec Sheets";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push("SpecSheet");
            $rootScope.emptySearchField();
            $rootScope.spshCnt = 1;
            setTimeout(function () {
                if ($rootScope.spshCnt == 1) {
                    $rootScope.filterNameGroup = "Seismic";
                    $rootScope.seismicSpecSheettab();
                    setTimeout($rootScope.retainFields, 1000);
                    $rootScope.spshCnt += 1;
                }
            }, 1000);
            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(6)').addClass('active');
        }
        else if (angular.element(this).text() == "WELLS") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.appgname = "Well";
            angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
            $rootScope.latlongType = "SurfaceLatLong";
            if (window.fromwell) {
                $rootScope.filterNameGroup = "Well";
                $rootScope.filterNameForNavigation = "WELLS";
                $rootScope.curTab = "LAS";
                $rootScope.prevTab = [];
                $rootScope.prevTab.push("Las");
                $rootScope.isSeismicClicked = false;
                $rootScope.wellLastab();
                $rootScope.showAppliedtxt();
                window.fromwell = false;
                $rootScope.isSeismicClicked = false;
            }

            $rootScope.filterNameForNavigation = "WELLS";
            if ($rootScope.filterNameGroup == "Seismic") {

                var geoSpatialFilter = "";
                if (window.drawPolygon) {
                    if ($rootScope.prevTab.length > 0 && ($rootScope.prevTab[0] == "SEGY" || $rootScope.prevTab[0] == "SpecSheet")) {
                        geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);
                    }
                    else {
                        geoSpatialFilter = Common.getLatLongGeoShapeFilter(SurveyService.allSurveyFilter);
                    }
                }
                $scope.Lasitems = [];
                if (SurveyService.allSurveyFilter !== "" || SurveyService.surveyQueryBuilder !== "") {
                    var newuuid = Common.getUuid();
                    angular.element(document.body).append('<div id="overlay"><div class="spinner"></div></div>');

                    //Get the customer Id filter                    
                    var customerFilter = Common.getSurveyEntitlementUrl();

                    if (customerFilter == "" && $rootScope.surveyEntitlementUrl) {
                        customerFilter = $rootScope.surveyEntitlementUrl;
                    }
                    var request = Common.getSwitchPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, SurveyService.surveyQueryBuilder,
                        newuuid, $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                    $rootScope.filterNameGroup = 'Well';
                    $rootScope.curTab = "LAS";
                    $rootScope.prevTab = [];
                    $rootScope.prevTab.push("Las");

                    $http(request)
                        .then(function (response) {
                            $rootScope.uuid = "";
                            $rootScope.uuid = response.data;
                            $rootScope.welluuid = $rootScope.uuid;
                            $scope.collectsurveyUUIDData("SeismictoWellSwitch", $rootScope.uuid, "SeismictoWellSwitch");
                            $rootScope.surveyuuidformFilter();
                            $rootScope.wellLastab();
                            angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').show();
                            setTimeout(function () {
                                $rootScope.showAppliedtxt();
                                angular.element(document.body).find('#overlay').remove();
                            }, 2000);
                            $rootScope.seismicSwitchfliterFlag = false;
                            $rootScope.isSeismicClicked = false;
                        }).catch(function (response) {
                            if (response.status == 500) {
                                angular.element(document.body).find('#overlay').remove();
                            }
                        });
                }
                else {
                    if ($rootScope.callFromHomePage == true) {
                        if ($rootScope.uuid !== "" && $rootScope.uuid !== undefined) {
                            var newuuid = $rootScope.welluuid;
                            $rootScope.uuid = newuuid;
                            $rootScope.curTab = "LAS";
                            $rootScope.prevTab = [];
                            $rootScope.prevTab.push("Las");
                        }
                        $rootScope.filterNameGroup = 'Well';
                        $rootScope.curTab = "LAS";
                        $rootScope.wellLastab();
                        angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').remove();
                        $rootScope.showAppliedtxt();
                    }
                    else {
                        $rootScope.seismicSwitchfliterFlag = false;
                        $rootScope.seismicSwitchFlag = false;

                        if ($rootScope.uuid !== "" && $rootScope.uuid !== undefined) {
                            $rootScope.welluuid = "";
                            $rootScope.uuid = "";
                        }
                        $rootScope.filterNameGroup = 'Well';
                        $rootScope.curTab = "LAS";
                        $rootScope.prevTab = [];
                        $rootScope.prevTab.push("Las");

                        angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').prev('.flt-title').hide();
                        angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').remove();
                        for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
                            if ($rootScope.selectedValArr[i].title == "SeismictoWellSwitch")
                                $rootScope.selectedValArr.splice(i, 1);
                        }
                        for (l = 0; l < $rootScope.selectedFieldsDetails.length; l++) {
                            if ($rootScope.selectedFieldsDetails[l].fieldName == "SeismictoWellSwitch")
                                $rootScope.selectedFieldsDetails.splice(l, 1);
                        }
                        $rootScope.wellLastab();
                        $rootScope.showAppliedtxt();

                    }
                }
            }
            else if ($rootScope.filterNameGroup == "interpretive") {
                angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').show();
                angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').hide();
                $rootScope.curTab = "LAS";
                $rootScope.filterNameGroup = "Well";
                $rootScope.prevTab = [];
                $rootScope.prevTab.push("Las");
                $rootScope.uuid = "";

                for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
                    if ($rootScope.selectedValArr[i].title == "SeismictoWellSwitch")
                        $rootScope.selectedValArr.splice(i, 1);
                }
                for (l = 0; l < $rootScope.selectedFieldsDetails.length; l++) {
                    if ($rootScope.selectedFieldsDetails[l].fieldName == "SeismictoWellSwitch")
                        $rootScope.selectedFieldsDetails.splice(l, 1);
                }

                $rootScope.wellLastab();
                setTimeout(function () {
                    $rootScope.showAppliedtxt();
                }, 1500)
            }
            else {
                if (!window.fromwell) {
                    $rootScope.curTab = "LAS";
                    $rootScope.prevTab = [];
                    $rootScope.prevTab.push("Las");
                    window.fromwell = false;
                    $rootScope.wellLastab();
                    $rootScope.showAppliedtxt();
                }
            }
            $rootScope.moduleName = 'LAS';
            angular.element('.Seismicfltrgrp').addClass('hide');
            angular.element('.Seismicfltrdetgrp').addClass('hide');
            angular.element('.Wellfltrgrp').removeClass('hide');
            angular.element('.Wellfltrdetgrp').removeClass('hide');
            angular.element('.Iprtvegrp').addClass('hide');
            angular.element('.detail-view-tab > .filter-setting').addClass('hide');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.nav-tabs').find('li:first').addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.tab-content').find('.tab-pane').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.tab-content').find('.tab-pane:first').addClass('active');
            angular.element('.ipappliedgrp').addClass('hide');
            angular.element('.surveyappliedgrp').addClass('hide');
            angular.element('.wellappliedgrp').removeClass('hide');
            angular.element('.wellappliedgrp').show();
            // showing well qb in Well, when navigate from IP
            angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').show();
        }

        else if (angular.element(this).text() == "LAS") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.appgname = "Well";
            angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
            $rootScope.latlongType = "SurfaceLatLong";
            if (window.fromwell) {
                $rootScope.filterNameGroup = "Well";
            }
            $rootScope.isWellClicked = false;
            $rootScope.isSeismicClicked = false;
            //$rootScope.filterNameGroup = "Well";
            $rootScope.curTab = "LAS";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push("Las");
            $rootScope.lasCnt = 1;
            setTimeout(function () {
                if ($rootScope.filterNameGroup == "Well" && $rootScope.lasCnt == 1) {

                    $rootScope.wellLastab();
                    $rootScope.lasCnt += 1;
                }
                angular.element(document).find('table').find('th.settingApplied').addClass('hide');
                angular.element(document).find('table').find('td.settingApplied').addClass('hide');
                angular.element(document).find('table').find('th').removeClass('settingApplied');
                angular.element(document).find('table').find('td').removeClass('settingApplied');
                $rootScope.filterNameGroup = "Well";
                angular.element('.surveyappliedgrp').hide();
                angular.element('.wellappliedgrp').show();
                $rootScope.showAppliedtxt();
            }, 2000)
        }
        else if (angular.element(this).text() == "Production") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
            $rootScope.latlongType = "SurfaceLatLong";
            if ($rootScope.filterNameGroup == "Seismic") {
                var newuuid = Common.getUuid();
                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);

                //Get customerId filter
                var customerFilter = Common.getSurveyEntitlementUrl();

                if (customerFilter == "" && $rootScope.surveyEntitlementUrl) {
                    customerFilter = $rootScope.surveyEntitlementUrl;
                }

                var request = Common.getSwitchPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter,
                    SurveyService.surveyQueryBuilder, newuuid, $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request).
                    // $http.get(SurveyService.urlValue + serviceurl).
                    then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                        if (response.status == 500) {

                            angular.element(document.body).find('#overlay').remove();
                        }
                    });
            }
            $rootScope.seismicSwitchfliterFlag = false;
            $rootScope.isSeismicClicked = false;
            $rootScope.curTab = "Production";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.prodCnt = 1;
            setTimeout(function () {
                if ($rootScope.prodCnt == 1) {
                    $rootScope.welproductiontab();
                    angular.element(document).find('table').find('th.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('td.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('th').removeClass('settingApplied');
                    angular.element(document).find('table').find('td').removeClass('settingApplied');
                    $rootScope.filterNameGroup = "Well";
                    $rootScope.prodCnt += 1;
                }
            }, 1000)

            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(2)').addClass('active');
        }
        else if (angular.element(this).text() == "Raster") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
            $rootScope.latlongType = "SurfaceLatLong";
            if ($rootScope.filterNameGroup == "Seismic") {

                var newuuid = Common.getUuid();
                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);

                //Get customer Id filter
                var customerFilter = Common.getSurveyEntitlementUrl();

                if (customerFilter == "" && $rootScope.surveyEntitlementUrl) {
                    customerFilter = $rootScope.surveyEntitlementUrl;
                }
                var request = Common.getSwitchPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter,
                    SurveyService.surveyQueryBuilder, newuuid, $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request).
                    then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                        if (response.status == 500) {

                            angular.element(document.body).find('#overlay').remove();
                        }
                    });
            }
            $rootScope.seismicSwitchfliterFlag = false;
            $rootScope.isSeismicClicked = false;
            $rootScope.curTab = "Raster";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.rasterCnt = 1;
            setTimeout(function () {
                if ($rootScope.rasterCnt == 1) {
                    $rootScope.wellRastertab()
                    angular.element(document).find('table').find('th.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('td.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('th').removeClass('settingApplied');
                    angular.element(document).find('table').find('td').removeClass('settingApplied');
                    $rootScope.filterNameGroup = "Well";
                    $rootScope.rasterCnt += 1;
                }
            }, 1000)
            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(3)').addClass('active');
        }
        else if (angular.element(this).text() == "VWH") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
            $rootScope.latlongType = "SurfaceLatLong";
            if ($rootScope.filterNameGroup == "Seismic") {
                var newuuid = Common.getUuid();
                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);

                //Get customer Id filter
                var customerFilter = Common.getSurveyEntitlementUrl();

                if (customerFilter == "" && $rootScope.surveyEntitlementUrl) {
                    customerFilter = $rootScope.surveyEntitlementUrl;
                }

                var request = Common.getSwitchPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter,
                    SurveyService.surveyQueryBuilder, newuuid, $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request)
                    .then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                        if (response.status == 500) {

                            angular.element(document.body).find('#overlay').remove();
                        }
                    });
            }
            $rootScope.seismicSwitchfliterFlag = false;
            $rootScope.isSeismicClicked = false;
            $rootScope.curTab = "VWH";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.vwhCnt = 1;
            setTimeout(function () {
                if ($rootScope.vwhCnt == 1) {
                    $rootScope.wellVWHtab();
                    angular.element(document).find('table').find('th.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('td.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('th').removeClass('settingApplied');
                    angular.element(document).find('table').find('td').removeClass('settingApplied');
                    $rootScope.filterNameGroup = "Well";
                    $rootScope.vwhCnt += 1;
                }
            }, 1000)

            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(4)').addClass('active');
        }
        else if (angular.element(this).text() == "Well File") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            angular.element(this).parents('.nav.nav-tabs').find('li:first').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:first').removeClass('active');
            angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
            $rootScope.latlongType = "SurfaceLatLong";
            if ($rootScope.filterNameGroup == "Seismic") {
                var newuuid = Common.getUuid();
                var geoSpatialFilter = "";
                if (window.drawPolygon)
                    geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);

                //Get customer Id filter
                var customerFilter = Common.getSurveyEntitlementUrl();

                if (customerFilter == "" && $rootScope.surveyEntitlementUrl) {
                    customerFilter = $rootScope.surveyEntitlementUrl;
                }

                var request = Common.getSwitchPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter,
                    SurveyService.surveyQueryBuilder, newuuid, $rootScope.filterNameGroup, $rootScope.prevTab, customerFilter);

                $http(request)
                    .then(function (response) {
                        $rootScope.uuid = "";
                        $rootScope.uuid = response.data;
                    }).catch(function (response) {
                        //('Error', response.status, response.data);
                        if (response.status == 500) {

                            angular.element(document.body).find('#overlay').remove();
                        }
                    });
            }
            $rootScope.seismicSwitchfliterFlag = false;
            $rootScope.isSeismicClicked = false;
            $rootScope.curTab = "WellFile";
            $rootScope.prevTab = [];
            $rootScope.prevTab.push($rootScope.curTab);
            $rootScope.emptySearchFieldwellfile();
            $rootScope.wfCnt = 1;
            setTimeout(function () {
                if ($rootScope.wfCnt == 1) {
                    $rootScope.wellWFtab();
                    angular.element(document).find('table').find('th.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('td.settingApplied').addClass('hide');
                    angular.element(document).find('table').find('th').removeClass('settingApplied');
                    angular.element(document).find('table').find('td').removeClass('settingApplied');
                    $rootScope.filterNameGroup = "Well";
                    $rootScope.wfCnt += 1;
                }
            }, 1000)
            angular.element(this).parent().addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(5)').addClass('active');
        }

        if (angular.element(this).text() == "INTERPRETIVE") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.appgname = "Interpretive";
            $rootScope.filterNameGroup = "interpretive";
            $rootScope.filterNameForNavigation = "INTERPRETIVE";
            angular.element(document.body).find('#surfaceLatLong')[0].checked = true;
            $rootScope.latlongType = "SurfaceLatLong";
            angular.element('.Seismicfltrgrp').addClass('hide');
            angular.element('.Seismicfltrdetgrp').addClass('hide');
            angular.element('.Wellfltrgrp').addClass('hide');
            angular.element('.cusWellfltrgrp').removeClass('hide');
            angular.element('.Wellfltrdetgrp').addClass('hide');
            angular.element('.Iprtvegrp').removeClass('hide');
            angular.element('.detail-view-tab > .filter-setting').removeClass('hide');
            // angular.element('.detail-view-tab > .filter-setting').addClass('hide');            
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.nav-tabs').find('li:first').addClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.tab-content').find('.tab-pane').removeClass('active');
            angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane').find('.tab-content').find('.tab-pane:first').addClass('active');
            angular.element('.ipappliedgrp').removeClass('hide');
            angular.element('.ipappliedgrp').removeClass('hide');
            angular.element('.surveyappliedgrp').addClass('hide');
            angular.element('.ipappliedgrp').show();
            angular.element('[data-fgname="ipqb"]').parent('div').parent('.applied-filter-group').show();
            angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
            angular.element('[data-fgname="wellswitch"]').parent('div').parent('.applied-filter-group').hide();
            angular.element('[data-fgname="surveyqb"]').parent('div').parent('.applied-filter-group').hide();
            // angular.element('.detail-view-tab > .filter-setting').removeClass('hide');
            $rootScope.iptools = true;
            $rootScope.intCnt = 1;

            for (var i = 0; i < $rootScope.selectedValArr.length; i++) {
                if ($rootScope.selectedValArr[i].title == "SeismictoWellSwitch")
                    $rootScope.selectedValArr.splice(i, 1);
            }

            for (l = 0; l < $rootScope.selectedFieldsDetails.length; l++) {
                if ($rootScope.selectedFieldsDetails[l].fieldName == "SeismictoWellSwitch")
                    $rootScope.selectedFieldsDetails.splice(l, 1);
            }
            setTimeout(function () {
                if ($rootScope.intCnt == 1) {
                    $rootScope.interpretiveLasTab();
                    $rootScope.intCnt += 1;
                }
            }, 400);
            setTimeout(function () {
                $rootScope.showAppliedtxt();
                angular.element('.wellappliedgrp').show();
                angular.element('.wellappliedgrp').removeClass('hide');
                angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
            }, 2500);
        }
        if (angular.element(this).text() == "Interpretive LAS") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.curTab = "InterpretiveLas";
            $rootScope.iptools = true;
            $rootScope.intLasCnt = 1;
            setTimeout(function () {
                if ($rootScope.intLasCnt == 1) {
                    $rootScope.interpretiveLasTab();
                    $rootScope.intLasCnt += 1;
                }
            }, 400);
            angular.element(this).parent().find('li:first-child').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parent().addClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane.active').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:first-child').addClass('active');
        }
        if (angular.element(this).text() == "Interpretive Doc Library") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.curTab = "InterpretiveDocLibrary";
            $rootScope.iptools = true;
            $rootScope.docLibCnt = 1;
            setTimeout(function () {
                if ($rootScope.docLibCnt == 1) {
                    $rootScope.interdoclibtab();
                    $rootScope.docLibCnt += 1;
                }
            }, 400);
            angular.element(this).parent().find('li:first-child').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parent().addClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane.active').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(2)').addClass('active');
        }
        if (angular.element(this).text() == "PWA") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.curTab = "interpretivePWA";
            $rootScope.iptools = true;
            $rootScope.pwaCnt = 1;
            setTimeout(function () {
                if ($rootScope.pwaCnt == 1) {
                    $rootScope.interpretivePWATab();
                    $rootScope.pwaCnt += 1;
                }
            }, 400);
            angular.element(this).parent().find('li:first-child').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parent().addClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane.active').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(4)').addClass('active');
        }

        if (angular.element(this).text() == "DSDP") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.curTab = "interpretiveDSDP";
            $rootScope.iptools = true;
            $rootScope.dsdpCnt = 1;
            setTimeout(function () {
                if ($rootScope.dsdpCnt == 1) {
                    $rootScope.interpretiveDSDPTab();
                    $rootScope.dsdpCnt += 1;
                }
            }, 400);
            angular.element(this).parent().find('li:first-child').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parent().addClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane.active').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:nth-child(3)').addClass('active');
        }
        if (angular.element(this).text() == "Formation") {
            angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
            $rootScope.iptools = false;
            $rootScope.intbioStCnt = 1;
            angular.element(this).parent().parent().parent().find('.nav-tabs').find('li').removeClass('active');
            angular.element(this).parent().addClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:last-child').find('.formationtabcontent').find('.nav-tabs').find('li:first-child').click();
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane.active').removeClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:last-child').addClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:last-child').find('.formationtabcontent').find('.nav-tabs').find('li:first-child').addClass('active');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:last-child').find('.formationtabcontent').find('.tab-content').find('.well-list-details').addClass('ng-hide');
            angular.element(this).parent().parent().parent().find('.nav-tabs').next('.tab-content').find('.tab-pane:last-child').find('.formationtabcontent').find('.tab-content').find('.well-list-details:first').removeClass('ng-hide');
        }
    });

    $rootScope.retainFields = function () {
        let tabName = $rootScope.curTab;
        let settingRetain = JSON.parse(localStorage.getItem("sessionVariables"));
        if (settingRetain != null) {
            for (let i = 0; (settingRetain[tabName] !== undefined && i <= settingRetain[tabName].length - 1); i++) {
                let colmnval = settingRetain[tabName][i];
                angular.element('.' + tabName).find('[data-column-val="' + colmnval + '"]').removeClass('hide');
                angular.element('.' + tabName).find('[data-column-val="' + colmnval + '"]').addClass('settingApplied')
            }
        }
        if ($rootScope.curTab == "Spec Sheets") {
            for (let i = 0; (settingRetain["SpecSheets"] !== undefined && i <= settingRetain["SpecSheets"].length - 1); i++) {

                let colmnval = settingRetain["SpecSheets"][i];
                angular.element('.SpecSheets').find('[data-column-val="' + colmnval + '"]').removeClass('hide');
                angular.element('.SpecSheets').find('[data-column-val="' + colmnval + '"]').addClass('settingApplied')
            }
        }
    }


    angular.element(document).on('click', '.custom-chkbk-container input', function (e) {
        var checkedCount = angular.element('.custom-chkbk-container input:checked').length;
        if (checkedCount > 25) {
            $.alertable.alert('Maximum of 25 fields can be selected.');
            return false;
        }
        var checkedValue = angular.element(this);
        if (checkedValue[0].checked == true) {
            angular.element(this).addClass('settingApplied');
            angular.element(this).removeClass('removeApplied');
            var fieldName = angular.element(this).attr('datafield');
            if ($rootScope.curTab == "SEGY")
                getSelectedSettings(fieldName);
            if ($rootScope.curTab == "Horizon")
                getHorizonSelectedSettings(fieldName);
            if ($rootScope.curTab == "Velocity")
                getVelSelectedSettings(fieldName);
            if ($rootScope.curTab == "Spec Sheets")
                getSpecSheetSelectedSettings(fieldName);
            if ($rootScope.curTab == "AeroMag")
                getAeroMagSelectedSettings(fieldName);
            if ($rootScope.curTab == "GravMag")
                getGravMagSelectedSettings(fieldName);
            if ($rootScope.curTab == "WellFile")
                getWellFileSelectedSettings(fieldName);
        }
        else {
            angular.element(this).removeClass('settingApplied');
            angular.element(this).addClass('removeApplied');
            var fieldName = angular.element(this).attr('datafield');
            if ($rootScope.curTab == "SEGY")
                removeSelectedSettings(fieldName);
            if ($rootScope.curTab == "Horizon")
                removeHorizonSelectedSettings(fieldName);
            if ($rootScope.curTab == "Velocity")
                removeVelSelectedSettings(fieldName);
            if ($rootScope.curTab == "Spec Sheets")
                removeSpecSheetSelectedSettings(fieldName);
            if ($rootScope.curTab == "AeroMag")
                removeAeroMagtSelectedSettings(fieldName);
            if ($rootScope.curTab == "GravMag")
                removeGravMagtSelectedSettings(fieldName);
            if ($rootScope.curTab == "WellFile")
                removeWellFileSelectedSettings(fieldName);
        }
    });

    //Get the selected fields for SEGY tab
    var getSelectedSettings = function (field) {

        if ($rootScope.segySelected == undefined || $rootScope.segySelected == "")
            $rootScope.segySelected = field;
        else {
            $rootScope.segySelected = $scope.checkIsSelectedFieldExist($rootScope.segySelected, field)
        }
        return $rootScope.segySelected;
    }

    //Remove selected fields for SEGY tab
    var removeSelectedSettings = function (field) {
        var fieldVal = [];
        var fields = "";
        fieldVal = $rootScope.segySelected.split(',')
        for (var i = 0; i < fieldVal.length; i++) {
            if (fieldVal[i] == field)
                fieldVal.splice(i, 1);
        }
        for (var i = 0; i < fieldVal.length; i++) {
            if (fields == "")
                fields = fieldVal[i];
            else
                fields = fields + "," + fieldVal[i];
        }
        $rootScope.segySelected = fields;
        return $rootScope.segySelected;
    }

    //Get the selected fields for Horizon tab
    var getHorizonSelectedSettings = function (field) {
        if ($rootScope.horizonSelected == undefined || $rootScope.horizonSelected == "")
            $rootScope.horizonSelected = field;
        else {
            $rootScope.horizonSelected = $scope.checkIsSelectedFieldExist($rootScope.horizonSelected, field)
        }
        return $rootScope.horizonSelected;
    }

    //Remove selected fields for Horizon tab
    var removeHorizonSelectedSettings = function (field) {
        var fieldVal = [];
        var fields = "";
        fieldVal = $rootScope.horizonSelected.split(',')
        for (var i = 0; i < fieldVal.length; i++) {
            if (fieldVal[i] == field)
                fieldVal.splice(i, 1);
        }
        for (var i = 0; i < fieldVal.length; i++) {
            if (fields == "")
                fields = fieldVal[i];
            else
                fields = fields + "," + fieldVal[i];
        }
        $rootScope.horizonSelected = fields;
        return $rootScope.horizonSelected;
    }

    //Get the selected fields for Velocity tab
    var getVelSelectedSettings = function (field) {
        if ($rootScope.velocitySelected == undefined || $rootScope.velocitySelected == "")
            $rootScope.velocitySelected = field;
        else {
            $rootScope.velocitySelected = $scope.checkIsSelectedFieldExist($rootScope.velocitySelected, field)
        }
        return $rootScope.velocitySelected;
    }

    //Remove selected fields for Velocity tab
    var removeVelSelectedSettings = function (field) {
        var fieldVal = [];
        var fields = "";
        fieldVal = $rootScope.velocitySelected.split(',')
        for (var i = 0; i < fieldVal.length; i++) {
            if (fieldVal[i] == field)
                fieldVal.splice(i, 1);
        }
        for (var i = 0; i < fieldVal.length; i++) {
            if (fields == "")
                fields = fieldVal[i];
            else
                fields = fields + "," + fieldVal[i];
        }
        $rootScope.velocitySelected = fields;
        return $rootScope.velocitySelected;
    }

    //Get the selected fields for SpecSheet tab
    var getSpecSheetSelectedSettings = function (field) {
        if ($rootScope.specSheetSelected == undefined || $rootScope.specSheetSelected == "")
            $rootScope.specSheetSelected = field;
        else {
            $rootScope.specSheetSelected = $scope.checkIsSelectedFieldExist($rootScope.specSheetSelected, field)
        }
        return $rootScope.specSheetSelected;
    }

    //Remove selected fields for SpecSheet tab
    var removeSpecSheetSelectedSettings = function (field) {
        var fieldVal = [];
        var fields = "";
        fieldVal = $rootScope.specSheetSelected.split(',')
        for (var i = 0; i < fieldVal.length; i++) {
            if (fieldVal[i] == field)
                fieldVal.splice(i, 1);
        }
        for (var i = 0; i < fieldVal.length; i++) {
            if (fields == "")
                fields = fieldVal[i];
            else
                fields = fields + "," + fieldVal[i];
        }
        $rootScope.specSheetSelected = fields;
        return $rootScope.specSheetSelected;
    }

    //Get the selected fields for Aeromag tab
    var getAeroMagSelectedSettings = function (field) {

        if ($rootScope.aeroMagSelected == undefined || $rootScope.aeroMagSelected == "")
            $rootScope.aeroMagSelected = field;
        else {
            $rootScope.aeroMagSelected = $scope.checkIsSelectedFieldExist($rootScope.aeroMagSelected, field)
        }
        return $rootScope.aeroMagSelected;
    }
    //Remove selected fields for Aeromag tab
    var removeAeroMagtSelectedSettings = function (field) {
        var fieldVal = [];
        var fields = "";
        fieldVal = $rootScope.aeroMagSelected.split(',')
        for (var i = 0; i < fieldVal.length; i++) {
            if (fieldVal[i] == field)
                fieldVal.splice(i, 1);
        }
        for (var i = 0; i < fieldVal.length; i++) {
            if (fields == "")
                fields = fieldVal[i];
            else
                fields = fields + "," + fieldVal[i];
        }
        $rootScope.aeroMagSelected = fields;
        return $rootScope.aeroMagSelected;
    }

    //Get the selected fields for Gravmag tab
    var getGravMagSelectedSettings = function (field) {

        if ($rootScope.gravMagSelected == undefined || $rootScope.gravMagSelected == "") {
            $rootScope.gravMagSelected = field;
        }
        else {
            $rootScope.gravMagSelected = $scope.checkIsSelectedFieldExist($rootScope.gravMagSelected, field)
        }
        return $rootScope.gravMagSelected;
    }

    //Check if the settins field is already exist or not. If not it will append to selected settings list.
    $scope.checkIsSelectedFieldExist = function (selectedFields, newField) {
        var isFieldExist = false;
        var selectedFieldsArr = selectedFields.split(',');
        for (var i = 0; i < selectedFieldsArr.length; i++) {
            if (selectedFieldsArr[i] == newField) {
                isFieldExist = true;
                break;
            }
        }
        selectedFields = isFieldExist ? selectedFields : selectedFields + "," + newField;
        return selectedFields;
    }


    //Remove selected fields for Gravmag tab
    var removeGravMagtSelectedSettings = function (field) {
        var fieldVal = [];
        var fields = "";
        fieldVal = $rootScope.gravMagSelected.split(',')
        for (var i = 0; i < fieldVal.length; i++) {
            if (fieldVal[i] == field)
                fieldVal.splice(i, 1);
        }
        for (var i = 0; i < fieldVal.length; i++) {
            if (fields == "")
                fields = fieldVal[i];
            else
                fields = fields + "," + fieldVal[i];
        }
        $rootScope.gravMagSelected = fields;
        return $rootScope.gravMagSelected;
    }

    //Get the selected fields for Well File tab
    var getWellFileSelectedSettings = function (field) {

        if ($rootScope.wellFileSelected == undefined || $rootScope.wellFileSelected == "")
            $rootScope.wellFileSelected = field;
        else {
            $rootScope.wellFileSelected = $scope.checkIsSelectedFieldExist($rootScope.wellFileSelected, field)
        }
        return $rootScope.wellFileSelected;
    }

    //Remove selected fields for Well File tab
    var removeWellFileSelectedSettings = function (field) {
        var fieldVal = [];
        var fields = "";
        fieldVal = $rootScope.wellFileSelected.split(',')
        for (var i = 0; i < fieldVal.length; i++) {
            if (fieldVal[i] == field)
                fieldVal.splice(i, 1);
        }
        for (var i = 0; i < fieldVal.length; i++) {
            if (fields == "")
                fields = fieldVal[i];
            else
                fields = fields + "," + fieldVal[i];
        }
        $rootScope.wellFileSelected = fields;
        return $rootScope.wellFileSelected;
    }

    //Create session object for setting fields
    let sessionObject = {
        SEGY: [],
        Horizon: [],
        Velocity: [],
        SpecSheets: [],
        AeroMag: [],
        GravMag: [],

        LAS: [],
        Production: [],
        Raster: [],
        VWH: [],
        WellFile: [],

        InterpretiveLas: [],
        InterpretiveDocLibrary: [],
        interpretiveDSDP: [],
        interpretivePWA: [],

        BioStratTops: [],
        ChronoStratTops: [],
        CoreTops: [],
        EnvFaciesTops: [],
        LithoStratTops: [],
        LithologyTops: [],
        MaturityTypeTops: [],
        RockEvaluationTops: [],
        SequenceStratTops: [],
        Showtops: [],
        VisualMaceralTops: []
    }

    localStorage.setItem("sessionVariables", JSON.stringify(sessionObject))

    //SEGY File Cut Code - Start
    $scope.openSEGYCutModelPopup = function () {
        
        //File cut request has been sent successfully. You Will get mail notification ones the process is completed or failed.
        //$.alertable.confirm("This will remove all applied filters. Do you want to continue?").then(function () {});
        var geoSpatialFilter = "";
        var LatLongGeoShapeFilter = "";

        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon) {
            geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);
            LatLongGeoShapeFilter = Common.getLatLongGeoShapeFilter();
        }

        // This below function will gets the Selected segy fields and frame the Filter string.
        // Looks this not required in Segy File Cut request
         //var selectedFields = Common.getSegySelectedFields();
         var selectedFields = "";
        // This below function will gets the UUid and frame the Filter string.
        var uuid = Common.getUuid();

        // This below function will gets the customer Id and frame the Filter string.
        var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();

        if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
            surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
        }

        var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, LatLongGeoShapeFilter,
            SurveyService.surveyQueryBuilder, selectedFields, uuid, surveyEntitlementUrl, "Seismic", "SEGY"
            , "0", "", "", "", "",false)
            request.url = Common.urlValue + "getSegFileSizeMethod";          
        console.log(request);
        //Test Data - File list
        $scope.SEGYFileList = [
            { "name": "File Name1", "value": "FAR ANGEL STACK 1.0", "size": "20.2" },
            { "name": "File Name2", "value": "FAR ANGEL STACK 2.0", "size": "4.12" },
            { "name": "File Name3", "value": "FAR ANGEL STACK 3.0", "size": "20.2" },
            { "name": "File Name4", "value": "FAR ANGEL STACK 4.0", "size": "4.12" },
            { "name": "File Name5", "value": "FAR ANGEL STACK 5.0", "size": "20.2" },
            { "name": "File Name6", "value": "FAR ANGEL STACK 6.0", "size": "4.12" },
            { "name": "File Name7", "value": "FAR ANGEL STACK 7.0", "size": "20.2" },
            { "name": "File Name8", "value": "FAR ANGEL STACK 8.0", "size": "4.12" },
            { "name": "File Name7", "value": "FAR ANGEL STACK 7.0", "size": "20.2" },
            { "name": "File Name8", "value": "FAR ANGEL STACK 8.0", "size": "4.12" },       
            { "name": "File Name7", "value": "FAR ANGEL STACK 7.0", "size": "20.2" },
            { "name": "File Name8", "value": "FAR ANGEL STACK 8.0", "size": "4.12" }
           ];
    //Test Data - Product list
        $scope.SEGYProductList= [
            {"name":"PSTM-GATHERS 1.0 "},
            {"name":"Near Angle 1.0"},
            {"name":"Near Angle 2.0"},
            {"name":"FAR ANGEL Stack 1.0"},
            {"name":"FAR ANGEL Stack 2.0"}
        ];
        var response = [];
        response.push($scope.SEGYFileList);
        response.push($scope.SEGYProductList);
        //$http(request).then(function (response) {
            
            $scope.modalInstance = $uibModal.open({
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl: 'partials/seismic/SEGYCutModal.html',
                controller: 'SEGYCutModalController',            
                size: 'lg',
                resolve: {
                    "args": function () {
                        return {
                            responseData: response
                        }
                    }

                }
            });
            //     request.url = Common.urlValue + "segFileCutMethod"; 
            //     if(confirm("Are you sure you want to send the SEGY file cut request .."))
            //     {
            //         $http(req).then(function(){
            //             $.alertable.alert("Request sent for processing. You will get a notification ones the segy file cut is complete.");
            //         });
            //     }                
            // }
        //}).catch(function (response) { 

        //})


        
    }

    //Initiate Segy file cut process 
    $scope.initiateSegyFileCut = function()
    {
        
        
    }
    // var successCallback = function (response) {
    //         // if (response.data != "" && response.data.content.length > 0) {
    //             $.alertable.alert("Request sent for processing. You will get notification ones the segy file cut is complete.");
    //         // }
    //     }   

    // var errorCallback = function (reason) {
    //     // $scope.sercnt = 0;
    //     // angular.element(document.body).find('.pagerspinner').remove();        
    //     // angular.element(document).find('.norecords').text('No records found.');
    //     Common.redirectToCore(reason);
    // }
    $scope.getSelectedProductNames = function(e)
    {
        var products = "ProjectName:Gigante 2D - Campeche"; 
        //Proj Names        
        //Gigante 2D - Campeche
        // angular.element(document).on('click', '.custom-chkbk-product input', function (e) {

        //     var checkedCount = angular.element('.custom-chkbk-product input:checked').length;
        //     if (checkedCount == 0) {
        //         $.alertable.alert('There should be minimun one product needs to select.');
        //         return false;
        //     }
        //     var checkedValue = angular.element(this);
        //     if (checkedValue[0].checked == true) {
        //         products = products+ "," + checkedValue[0].value;
        //     }
        //     console.log(products);
        // });
            //Call products filter to fetch filenames
            var serviceUrl = "getSeismicFieldDistinctValuesFilter";//"getSearchFieldName"; 
            //S3FileName  S3VelocityFileName
          var paramInfo = {
            source: "S3FileName",
            module: "Seismic",
            //searchStr: products,
            filterStr: products,
            requestTimestamp : Common.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
          }
          //paramInfo.searchStr == "" ? delete paramInfo.searchStr : paramInfo.searchStr;
          paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
          paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
    
          var paramInfoList = $.param(paramInfo);
    
          var request = {
            method: 'POST',
            url: SurveyService.urlValue + serviceUrl,
            data: paramInfoList,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded'  }
          }
          console.log(request);
          $http(request).then(function (response) {
              console.log(response);
          }).catch(function (err) {
           console.log(err)
        });
    } 
    
    //SEGY File Cut Code - End  

})

