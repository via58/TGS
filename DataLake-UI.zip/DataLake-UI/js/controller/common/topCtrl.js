/*
File Name:- logoutCtrl.js
Summary:- Gets the user Role and assigns the user Role.
*/

angular.module('TGSApp').controller('topCtrl', function ($scope, $location, $rootScope, $http, WellService, $routeParams) {
               
      //Sets the Chevron Role      
            if ($rootScope.userRole.split(' ')[0] == 'External') {
                  var externalUserUrl = "getEntitlementCustomerRoleDetails";                  
                  var paramInfo = {
                        roleName: $rootScope.userRole,
                        token: $rootScope.sessionToken,
                        access_token: $rootScope.accessToken
                    }

                    paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
                    paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

                    var paramInfoList = $.param(paramInfo);
            
                    //Form request object
                    var request = {
                        method: 'POST',
                        url: WellService.urlValue + externalUserUrl,
                        data: paramInfoList,
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                    }
                  $http(request).
                        then(function (response) {       
                              if (response.data.length > 0) {
                                    $rootScope.externalUser = response.data[0];                                   
                              }
                        }).catch(function (response) {                              
                        });
                  $rootScope.isExternalUser = true;
                  $rootScope.disEntitlement = $rootScope.userRole;
                  $rootScope.disCSV = $rootScope.userRole;
            }            
            //Sets the Administrator Role
            else if ($rootScope.userRole == 'Administrator' || $rootScope.userRole == 'TGS Business User') {
                  $rootScope.isAdminUser = true;
                  $rootScope.disEntitlement = $rootScope.userRole;
            }
            //Sets the Research User Role
            else if ($rootScope.userRole == 'Research User') {
                  $rootScope.disEntitlement = $rootScope.userRole;
            }
            //Sets the Catalog User Role
            else if ($rootScope.userRole == 'Catalog User') {
                  $rootScope.disEntitlement = $rootScope.userRole;
                  $rootScope.disCSV = $rootScope.userRole;
            }  
            
            //Navigate to Home page    
            $scope.goHome = function () {
            $location.path('/');
            WellService.allWellInfoService = WellService.homeUrl;
            $rootScope.curTab = "home";

            if (angular.element(document).find('.applied-form-control').find('span:first-child').text() == "") {
                  WellService.allWellFilter = "";
                  WellService.wellQueryBuilder = "";
            }


            setTimeout(function () {
                  angular.element(document).find('.Wellfltrgrp').addClass('hide');
                  angular.element(document).find('.Iprtvegrp').addClass('hide');
                  angular.element(document).find('.Seismicfltrdetgrp').addClass('hide');
                  angular.element(document).find('.Wellfltrdetgrp').addClass('hide');
                  angular.element(document).find('.Seismicfltrgrp').removeClass('hide');
                  $rootScope.filterNameGroup = "Seismic";

            }, 1000);
            angular.element('.surveyappliedgrp').show();
            angular.element('.wellappliedgrp').hide();
      }
});
