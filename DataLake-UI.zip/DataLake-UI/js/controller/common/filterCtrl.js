/*
File Name:- filterCtrl.js
Summary:- Resets the applied filter and loads the current tab data.
*/

angular.module('TGSApp').controller('filterCtrl', function ($scope, $rootScope, WellService, SurveyService, InterpretiveService, Common) {
    $scope.oneAtATime = true;
    $scope.status = {
        isCustomHeaderOpen: true,
        isWellHeaderOpen: true,
        isFirstOpen: true,
        isFirstDisabled: false
    };

    angular.element(document).on('change', '#file-input', function (e) {
        $rootScope.$broadcast("event:uploadShapeFile", { event: e });
        setTimeout(function () {
            $rootScope.showAppliedtxt();
        }, 1000)
    });

    angular.element(document).on('click', '#filterId', function (e) {

        $(".dropdown-menu-accorrdion").animate({ width: 'toggle' }, 100);
    });

    angular.element(document).on('click', '.filter-container .dropdown-menu', function (e) {
        e.stopPropagation();
    });

    angular.element(document).on('click', '.btn.btn-sm.btn-danger', function (e) {
        e.stopPropagation();
    });
    angular.element(document).on('click', '.ui-select-match-close', function (e) {
        e.stopPropagation();
    });
   
    window.addEventListener("click", function (e) {        
        var element = e.srcElement;             
        if (!angular.element(element).parents('#filterId').hasClass('dropdown-toggle')
            && !angular.element(element).parent('li').hasClass("uib-typeahead-match")
            && !angular.element(element).parent().parent().hasClass("uib-typeahead-match")
            && !angular.element(element).parents().hasClass("table-condensed")
            && !angular.element(element).parent().hasClass("drp-buttons")
            && !angular.element(element).hasClass("alertable-ok")) {
            angular.element(document).find(".popover").hide();
            angular.element('.tgsfilterblk').hide();
        }
    });


    angular.element(document).on('click', '.dropdown', function (e) {
        if (angular.element(this).hasClass('open')) {
            angular.element('.custom-form-group').find('.dropdown').removeClass('open');
            angular.element(this).addClass('open');
        }
    });

    angular.element(document).on('mouseleave', '.dropdown, .dropdown-menu', function (e) {
        angular.element('.custom-form-group').find('.dropdown').removeClass('open');

    });
    angular.element(document).on('click', '.ui-select-choices-row', function (e) {
        angular.element('.ui-select-choices').addClass('ng-hide');
        angular.element('.ui-select-choices').css('opacity', '0');
        e.stopPropagation();
    });
    angular.element(document).on('click', '.cancel-filter', function (e) {
        angular.element('.filter-touched').prop('selectedIndex', 0);
        angular.element('input.filter-touched').val('');
    });

    $scope.filterResetMsg = function () {
        if ($rootScope.IPselectedValArr.length == 0 && $rootScope.selectedValArr.length == 0 && $rootScope.surveyselectedValArr.length == 0 && !window.drawPolygon) {
            $.alertable.alert("No filter is applied to reset.")
            return false;
        }
        angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
        angular.element('.surveySummaryPanel').hide();

        $.alertable.confirm("This will remove all applied filters. Do you want to continue?").then(function () {
            $rootScope.isResetAllFilter = true;
            if ($rootScope.wellCustomer !== undefined) //set wellCustomer object empty
                $rootScope.wellCustomer = "";
            if ($rootScope.surveyCustomer !== undefined) //set surveyCustomer object empty
                $rootScope.surveyCustomer = "";

            $rootScope.surveyEntitlementUrl = ""; //set Survey Entitlement url empty
            $rootScope.horizonEntitlementUrl = "";
            $rootScope.aeroMagEntitlementUrl = "";
            $rootScope.gravMagEntitlementUrl = "";
            $rootScope.projShapeEntitlementUrl = "";

            $rootScope.WellEntitleUrl = ""; //set Well Entitlement url empty

            let sessionObject = {
                SEGY: [],
                Horizon: [],
                Velocity: [],
                SpecSheets: [],
                AeroMag: [],
                GravMag: [],
                LAS: [],
                Production: [],
                Raster: [],
                VWH: [],
                WellFile: [],
                InterpretiveLas: [],
                InterpretiveDocLibrary: [],
                interpretiveDSDP: [],
                interpretivePWA: [],

                BioStratTops: [],
                ChronoStratTops: [],
                CoreTops: [],
                EnvFaciesTops: [],
                LithoStratTops: [],
                LithologyTops: [],
                MaturityTypeTops: [],
                RockEvaluationTops: [],
                SequenceStratTops: [],
                Showtops: [],
                VisualMaceralTops: []
            }
            localStorage.setItem("sessionVariables", JSON.stringify(sessionObject));

            $rootScope.segySelected = "";       //set additional Selected fields url empty
            $rootScope.velocitySelected = "";
            $rootScope.specSheetSelected = "";
            $rootScope.aeroMagSelected = "";
            $rootScope.gravMagSelected = "";
            $rootScope.wellFileSelected = "";
            $rootScope.horizonSelected = "";
            $rootScope.horizonsurveyType = "";
            $rootScope.AeroMagSurveyType = "";
            $rootScope.GravMagSurveyType = "";
            $rootScope.filterSurveyType = "";

            window.drawPolygon = false;
            angular.element('.Seismicfltrgrp').find('.dropdown-menu').find('li').find('a').find('i').removeClass('icon-ok').addClass('icon-empty');
            angular.element('.Wellfltrgrp').find('.dropdown-menu').find('li').find('a').find('i').removeClass('icon-ok').addClass('icon-empty');
            $rootScope.selectedValArr = [];
            $rootScope.surveyselectedValArr = [];
            $rootScope.IPselectedValArr = [];
            $rootScope.tmArr = [];
            $rootScope.surveytmArr = [];
            $rootScope.iptmArr = [];
            $rootScope.selectedFieldsDetails = [];
            $rootScope.surveyselectedFieldsDetails = [];
            WellService.allWellFilter = "";
            WellService.wellQueryBuilder = "";
            SurveyService.allSurveyFilter = "";
            SurveyService.surveyQueryBuilder = "";
            InterpretiveService.ipQueryBuilder = "";
            $rootScope.seismicQBFilterArr = [];
            $rootScope.WellQBFilterArr = []
            $rootScope.uuid = "";
            $rootScope.QBFilterArr = [];
            angular.element(document).find('.detail-view-collapse-panel').find('.applied-filter-group').remove();
            angular.element(document).find('.detail-view-label').text('');
            angular.element(document).find('.detail-view-list').find('span:first-child').text('');
            angular.element(document).find('.applied-filter-section').find('.detail-view').find('.no-filter-applied').removeClass('hide');
            $scope.moduleName = $rootScope.curTab;
            $rootScope.loadFilterData();
            $rootScope.surveyloadFilterData();
            if ($scope.moduleName === undefined) {                
                $rootScope.loadSurveyDetails();
            }
            else if ($scope.moduleName === "home") {                
                $rootScope.loadSurveyDetails();
            }
            else if ($scope.moduleName === "LAS") {
                $rootScope.wellLastab();
            }
            else if ($scope.moduleName === "Raster") {
                $rootScope.wellRastertab();
            }
            else if ($scope.moduleName === "Production") {
                $rootScope.welproductiontab();
            }
            else if ($scope.moduleName === "VWH") {
                $rootScope.wellVWHtab();
            }
            else if ($scope.moduleName === "WellFile") {
                $rootScope.wellWFtab();
            }
            else if ($scope.moduleName === "SEGY") {
                $rootScope.seismicSegYtab();
            }
            else if ($scope.moduleName === "Horizon") {
                $rootScope.seismicHorizontab();
            }
            else if ($scope.moduleName === "Velocity") {
                $rootScope.seismicVelocitytab();
            }
            else if ($scope.moduleName === "GravMag") {
                $rootScope.seismicGravMagtab();
            }
            else if ($scope.moduleName === "AeroMag") {
                $rootScope.seismicAeroMagtab();
            }
            else if ($scope.moduleName === "Spec Sheets") {
                $rootScope.seismicSpecSheettab();
            }
            else if ($scope.moduleName === "INTERPRETIVE") {
                angular.element(this).parents('.nav.nav-tabs').next('.tab-content').find('.tab-pane.active').find('.nav.nav-tabs:first').find('li:first').find('a').click();
            }

            else if ($scope.moduleName === "InterpretiveDocLibrary") {
                $rootScope.interdoclibtab();
            }
            else if ($scope.moduleName === "interpretivePWA") {
                $rootScope.interpretivePWATab();
            }
            else if ($scope.moduleName === "InterpretiveLas") {
                $rootScope.interpretiveLasTab();
            }
            else if ($scope.moduleName === "interpretiveDSDP") {
                $rootScope.interpretiveDSDPTab();
            }
            else if ($scope.moduleName === "BioStratTops") {
                $rootScope.interbiostrattop();
            }
            else if ($scope.moduleName === "ChronoStratTops") {
                $rootScope.interchronostrattop();
            }
            else if ($scope.moduleName === "CoreTops") {
                $rootScope.interCoreTops();
            }
            else if ($scope.moduleName === "EnvFaciesTops") {
                $rootScope.interEnvFaciesTops();
            }
            else if ($scope.moduleName === "LithoStratTops") {
                $rootScope.interLithoStratTops();
            }
            else if ($scope.moduleName === "LithologyTops") {
                $rootScope.interLithologyTops();
            }
            else if ($scope.moduleName === "MaturityTypeTops") {
                $rootScope.interMaturitytypetop();
            }
            else if ($scope.moduleName === "RockEvaluationTops") {
                $rootScope.interrockevaluationtop();
            }
            else if ($scope.moduleName === "SequenceStratTops") {
                $rootScope.intersequencestrattop();
            }
            else if ($scope.moduleName === "Showtops") {
                $rootScope.interShowtop();
            }
            else if ($scope.moduleName === "VisualMaceralTops") {
                $rootScope.intervisualmaceraltop();
            }

            var dataToggle = angular.element(document.querySelector('#filterId'));
            $rootScope.show2d3dEnable();
            setTimeout(function () {

                $rootScope.showAppliedtxt();
                $rootScope.$broadcast("event:removePolygon", {});
            }, 1000);       

        });
    }

    $scope.filterCancel = function () {
        var dataToggle = angular.element(document.querySelector('#filterId'));
        // dataToggle.dropdown('toggle');
        $(".dropdown-menu-accorrdion").animate({ width: 'toggle' }, 100);
        angular.element('.QueryBuilder-container .QueryBuilder-condition:not(:first-child)').remove();
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('select:first').prop("selectedIndex", 0);
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('select:nth-child(2)').prop("selectedIndex", 0);
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHS').addClass('hide');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHS').val('');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHS').removeClass('RHSFldVal');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHSdisable').removeClass('hide');
    }

    $rootScope.show2d3dEnable = function () {
        if ($rootScope.isExternalUser || $rootScope.surveyCustomer)
            $rootScope.show2d3d = true;
        else
            $rootScope.show2d3d = false;
    }

    $rootScope.applyFilterAction = function (flag) {
        $rootScope.isDuplicate = false;
        angular.element('.mapSidepanel').hide(); //hide LHS Side Panel After resetting the Filter
        angular.element('.surveySummaryPanel').hide();
        $scope.moduleName = $rootScope.curTab;
        $scope.show2d3dEnable();

        if ($rootScope.filterNameGroup === "Seismic") {
            $rootScope.checkSeismicQBDuplicateValue($rootScope.seismicQBFilterArr);
            if ($rootScope.isDuplicate)
                return false;

            $rootScope.surveyselectedValArr = [];
            angular.element(document).find('.surveyappliedgrp').find('.detail-view-collapse-panel').find('.applied-filter-group').remove();
            angular.element(document).find('.surveyappliedgrp').find('.detail-view-label').text('');
            angular.element(document).find('.surveyappliedgrp').find('.detail-view-list').find('span:first-child').text('');

            //check if Etitlecustome is selected or not            
            //Seismic - Frame the Entitlement Url external user 
            $rootScope.surveyEntitlementUrl = Common.getAdminEntitlementUrl();
            $rootScope.horizonEntitlementUrl = Common.getAdminHorizonEntUrl();
            $rootScope.aeroMagEntitlementUrl = Common.getAdminAeroMagEntUrl();
            $rootScope.gravMagEntitlementUrl = Common.getAdminGravMagEntUrl();
            $rootScope.projShapeEntitlementUrl = Common.getAdminEntUserForMap();

            if ($rootScope.surveyCustomer && $rootScope.surveyCustomer.name) {
                $scope.custName = $rootScope.surveyCustomer.name
            }
            //Collect Seismic Entitlement customer data
            if ($rootScope.surveyEntitlementUrl || $rootScope.horizonEntitlementUrl || $rootScope.aeroMagEntitlementUrl
                || $rootScope.gravMagEntitlementUrl || $rootScope.projShapeEntitlementUrl) {
                $scope.collectsurveyEntitlementData("CustomerName", $rootScope.surveyCustomer, "CustomerName");
            }
            //Collect Well Entitlement customer data 

            $rootScope.getSurveyDateVaues();
            $rootScope.getQbSurveyData();
            $rootScope.surveyformFilter();
            $rootScope.surveyformQueryBuilder();
            $rootScope.surveyappliedFilterData();
        }
        else if ($rootScope.filterNameGroup === "interpretive") {
            $rootScope.checkIPQBDuplicateValue($rootScope.IPQBFilterArr);
            if ($rootScope.isDuplicate)
                return false;

            $rootScope.getBoundingBoxValues();
            $rootScope.IPselectedValArr = [];
            $rootScope.selectedValArr = [];
            angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
            angular.element(document).find('.ipappliedgrp').find('.applied-filter-group').remove();
            angular.element(document).find('.ipappliedgrp').find('.detail-view-label').text('');
            angular.element(document).find('.ipappliedgrp').find('.detail-view-list').find('span:first-child').text('');
            angular.element(document).find('.wellappliedgrp').find('.applied-filter-group').remove();
            angular.element(document).find('.wellappliedgrp').find('.detail-view-label').text('');
            angular.element(document).find('.wellappliedgrp').find('.detail-view-list').find('span:first-child').text('');
            $rootScope.getTextAndDateVaues();
            $rootScope.getQbWellData();
            $rootScope.formFilter();
            $rootScope.ipformQueryBuilder();
            $rootScope.formQueryBuilder();
            $rootScope.appliedFilterData();
            $rootScope.IPappliedFilterData();
            setTimeout(function () {
                angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
            }, 2500);
        }
        else {

            $rootScope.checkWellQBDuplicateValue($rootScope.WellQBFilterArr);
            if ($rootScope.isDuplicate)
                return false;

            $rootScope.getBoundingBoxValues();
            //If duplicate BoundingBoxValues are found exit from the process
            if ($rootScope.isDuplicate)
                return false;

            //Well - Frame the Entitlement Url external user 
            $rootScope.WellEntitleUrl = Common.getWellAdminEntitlementUrl();

            if ($rootScope.wellCustomer && $rootScope.wellCustomer.name) {
                $scope.WellCustName = $rootScope.wellCustomer.name
            }
            if ($rootScope.WellEntitleUrl) {
                $scope.collectWellEntitlementData("CustomerName", $rootScope.wellCustomer, "CustomerName");
            }

            $rootScope.selectedValArr = [];
            angular.element(document).find('.wellappliedgrp').find('.detail-view-collapse-panel').find('.applied-filter-group').remove();
            angular.element(document).find('.wellappliedgrp').find('.detail-view-label').text('');
            angular.element(document).find('.wellappliedgrp').find('.detail-view-list').find('span:first-child').text('');
            
            $rootScope.getTextAndDateVaues();
            $rootScope.getQbWellData();
            $rootScope.formFilter();
            $rootScope.formQueryBuilder();
            $rootScope.appliedFilterData();
            
        }

        if ($scope.moduleName === undefined) {
            if ($rootScope.filterNameGroup == 'Seismic') {
                $rootScope.loadSurveyDetails();
            }
            if ($rootScope.filterNameGroup == 'Well') {
                if ($rootScope.BBFilter == true) {
                    $rootScope.$broadcast("event:surveyPolygonDraw", {});
                    $rootScope.$broadcast("event:wellPolygonDraw", {});
                    if (angular.element('.mapappliedgrp').hasClass('hide'))
                        $('.mapappliedgrp').removeClass('hide');
                    $rootScope.showAppliedtxt();
                    $rootScope.BBFilter = false;
                }
                else {
                    $rootScope.loadWellDetails();
                    $rootScope.allwellmap();
                }
            }
        }
        else if ($scope.moduleName === "home") {
            if ($rootScope.filterNameGroup == 'Seismic') {
                $rootScope.loadSurveyDetails();
            }
            if ($rootScope.filterNameGroup == 'Well') {
                if ($rootScope.BBFilter == true) {
                    $rootScope.$broadcast("event:surveyPolygonDraw", {});
                    $rootScope.$broadcast("event:wellPolygonDraw", {});
                    if (angular.element('.mapappliedgrp').hasClass('hide'))
                        $('.mapappliedgrp').removeClass('hide');
                    $rootScope.showAppliedtxt();
                    $rootScope.BBFilter = false;
                }
                else {
                    $rootScope.loadWellDetails();
                    $rootScope.allwellmap();
                }
            }
        }
        else if ($scope.moduleName === "LAS") {
            $rootScope.wellLastab();
        }
        else if ($scope.moduleName === "Raster") {
            $rootScope.wellRastertab();
        }
        else if ($scope.moduleName === "Production") {
            $rootScope.welproductiontab();
        }
        else if ($scope.moduleName === "VWH") {
            $rootScope.wellVWHtab();
        }
        else if ($scope.moduleName === "WellFile") {
            $rootScope.wellWFtab();
        }
        else if ($scope.moduleName === "SEGY") {
            $rootScope.seismicSwitchFlag = false;
            $rootScope.seismicSegYtab();
        }
        else if ($scope.moduleName === "Horizon") {
            $rootScope.seismicHorizontab();
        }
        else if ($scope.moduleName === "Velocity") {
            $rootScope.seismicVelocitytab();
        }
        else if ($scope.moduleName === "GravMag") {
            $rootScope.seismicGravMagtab();
        }
        else if ($scope.moduleName === "AeroMag") {
            $rootScope.seismicAeroMagtab();
        }
        else if ($scope.moduleName === "Spec Sheets") {
            $rootScope.seismicSpecSheettab();
        }
        else if ($scope.moduleName === "InterpretiveDocLibrary") {
            $rootScope.interdoclibtab();
        }
        else if ($scope.moduleName === "interpretivePWA") {
            $rootScope.interpretivePWATab();
        }
        else if ($scope.moduleName === "InterpretiveLas") {
            $rootScope.interpretiveLasTab();
        }
        else if ($scope.moduleName === "interpretiveDSDP") {
            $rootScope.interpretiveDSDPTab();
        }
        else if ($scope.moduleName === "BioStratTops") {
            $rootScope.interbiostrattop();
        }
        else if ($scope.moduleName === "ChronoStratTops") {
            $rootScope.interchronostrattop();
        }
        else if ($scope.moduleName === "CoreTops") {
            $rootScope.interCoreTops();
        }
        else if ($scope.moduleName === "EnvFaciesTops") {
            $rootScope.interEnvFaciesTops();
        }
        else if ($scope.moduleName === "LithoStratTops") {
            $rootScope.interLithoStratTops();
        }
        else if ($scope.moduleName === "LithologyTops") {
            $rootScope.interLithologyTops();
        }
        else if ($scope.moduleName === "MaturityTypeTops") {
            $rootScope.interMaturitytypetop();
        }
        else if ($scope.moduleName === "RockEvaluationTops") {
            $rootScope.interrockevaluationtop();
        }
        else if ($scope.moduleName === "SequenceStratTops") {
            $rootScope.intersequencestrattop();
        }
        else if ($scope.moduleName === "Showtops") {
            $rootScope.interShowtop();
        }
        else if ($scope.moduleName === "VisualMaceralTops") {
            $rootScope.intervisualmaceraltop();
        }

        $rootScope.clearTextAndDateVaues();
        if ($rootScope.filterNameGroup === "Seismic") {            
            angular.element('.ipappliedgrp').hide();
            angular.element('.surveyappliedgrp').show();
            angular.element('.wellappliedgrp').hide();
        }
        else if ($rootScope.filterNameGroup === "interpretive") {            
            angular.element('.surveyappliedgrp').hide();
            angular.element('.ipappliedgrp').show();
            angular.element('.wellappliedgrp').show();
        }
        else {            
            angular.element('.ipappliedgrp').hide();
            angular.element('.surveyappliedgrp').hide();
            angular.element('.wellappliedgrp').show();
        }

        setTimeout(function () {
            $rootScope.showAppliedtxt();
            angular.element(document).find('.detail-view-collapse-panel').removeClass('in');
            angular.element(document).find('.detail-view-collapse-panel').addClass('in');
        }, 2000);
        if (!flag) {
            $(".dropdown-menu-accorrdion").animate({ width: 'toggle' }, 100);
        }
        //Query builder reset
        angular.element('.QueryBuilder-container .QueryBuilder-condition:not(:first-child)').remove();
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('select:first').prop("selectedIndex", 0);
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('select:nth-child(2)').prop("selectedIndex", 0);
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('select:nth-child(3)').attr("disabled", 'disabled');
        angular.element('#space-for-buttons-interpretive').find('.QueryBuilder-condition').find('select:nth-child(2)').addClass('hide');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('select:nth-child(3)').prop("selectedIndex", 0);
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('select:nth-child(4)').prop("selectedIndex", 0);
        angular.element('#space-for-buttons-interpretive').find('.QueryBuilder-condition').find('select:nth-child(3)').attr("disabled", 'disabled');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHS').addClass('hide');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHS').val('');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHS').removeClass('RHSFldVal');
        angular.element('.QueryBuilder-container .QueryBuilder-condition').find('.RHSdisable').removeClass('hide');
        angular.element('.selectedEntitleUser').prop("selectedIndex", 0);
        angular.element('.selectedwellEntitleUser').prop("selectedIndex", 0);
    }

    //Collects the selected Meta Data values
    $scope.collectsurveyEntitlementData = function (fieldName, customer, titleName) {
        if (customer.name) {
            var fieldVal = customer.name.includes(',') ? customer.name.replace(',', '~~') : customer.name;

            if ($rootScope.surveyselectedFieldsDetails.length > 0) {
                var isCustomerExist = false;
                for (var c = 0; c < $rootScope.surveyselectedFieldsDetails.length; c++) {
                    if ($rootScope.surveyselectedFieldsDetails[c].fieldName == "CustomerName") {
                        $rootScope.surveyselectedFieldsDetails[c].fieldValue = fieldVal;
                        $rootScope.surveyselectedFieldsDetails[c].customerId = customer.customerId;
                        $rootScope.surveyCustomer = $rootScope.surveyselectedFieldsDetails[c];
                        isCustomerExist = true;
                    }
                }
                if (!isCustomerExist) {
                    var obj = new Object();
                    obj.customerId = customer.customerId;
                    obj.fieldName = fieldName;
                    obj.fieldValue = fieldVal;
                    obj.titleName = titleName;
                    obj.displayName = fieldName;
                    $rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
                }

            }
            else {
                var obj = new Object();
                obj.customerId = customer.customerId;
                obj.fieldName = fieldName;
                obj.fieldValue = fieldVal;
                obj.titleName = titleName;
                obj.displayName = fieldName;
                $rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
            }
        }
    }

    //Collects the selected Meta Data values
    $scope.collectWellEntitlementData = function (fieldName, customer, titleName) {
        if (customer.name) {
            if ($rootScope.selectedFieldsDetails.length > 0) {
                var isCustomerExist = false;
                for (var c = 0; c < $rootScope.selectedFieldsDetails.length; c++) {
                    if ($rootScope.selectedFieldsDetails[c].fieldName == "CustomerName") {
                        $rootScope.selectedFieldsDetails[c].fieldValue = customer.name;
                        $rootScope.selectedFieldsDetails[c].customerId = customer.customerId;
                        $rootScope.wellCustomer = $rootScope.selectedFieldsDetails[c];
                        isCustomerExist = true;
                    }
                }
                if (!isCustomerExist) {
                    var obj = new Object();
                    obj.customerId = customer.customerId;
                    obj.fieldName = fieldName;
                    obj.fieldValue = customer.name;
                    obj.titleName = titleName;
                    obj.displayName = fieldName;
                    $rootScope.selectedFieldsDetails[$rootScope.selectedFieldsDetails.length] = obj;
                }

            }
            else {
                var obj = new Object();
                obj.customerId = customer.customerId;
                obj.fieldName = fieldName;
                obj.fieldValue = customer.name;
                obj.titleName = titleName;
                obj.displayName = fieldName;
                $rootScope.selectedFieldsDetails[$rootScope.selectedFieldsDetails.length] = obj;
            }
        }
    }
});
