/*
File Name:- accessCtrl.js
Summary:- Gets ths user role and SessionId.
*/

angular.module('TGSApp').controller('accessCtrl', function ($scope, $location, $rootScope, $http, $routeParams, Common) {    
    
    $scope.userinfo1 = $routeParams.usrrole;
    $scope.userToken = $scope.userinfo1.split('&&');
    $rootScope.sessionToken = $scope.userToken[0];
    $scope.acsToken = $scope.userToken[1];
    //$scope.rfsToken = $scope.userToken[2];
    $rootScope.userName = $scope.userToken[2] +' '+ $scope.userToken[3];   
    $rootScope.sessionIdexist = false;
    console.log($rootScope.sessionToken + "&&" + $scope.acsToken + "&&" + $scope.userToken[2] + "&&" + $scope.userToken[3]);
    var proxyUrl = Common.urlValue+"getUserDetails";  
    //var proxyUrl = "https://ui.datalake.tgs.com/getUserDetails";   //Proxy Prod
    var paramInfo = {
        requestTimestamp : Common.getCurrentDateTime(),
        token: $rootScope.sessionToken,
        access_token: $scope.acsToken
    }

    var paramInfoList = $.param(paramInfo);

    var request = {
        method: 'POST',
        url: proxyUrl,
        data: paramInfoList,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }

    }    
    $http(request)
        .then(function (response) {            
            $rootScope.userRole = response.data.ROLE.split(',')[0];  // Assign user Role
            $rootScope.accessToken = $scope.acsToken;                // Assign Access Token
            $rootScope.sessionId = response.data.SESSION_ID;         // Assign SessionId
            if ($rootScope.sessionId) {
                window.access = true;
                $rootScope.sessionIdExist = true;
                $location.path('/homeView');
            }
            else {
                window.access = false;
                $rootScope.sessionIdExist = false;
                window.location.assign(Common.urlValue);
            }
        }).catch(function (error) {                                
       $.alertable.alert("Unauthorized access. Please login again."); 
            window.location.assign(Common.urlValue);
        });   
    
});

