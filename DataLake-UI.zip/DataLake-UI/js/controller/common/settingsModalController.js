/*
File Name:- toolsCtrl.js
Summary:- Gets the user Role and assigns the user Role.
*/

angular.module('TGSApp').controller("settingsModelController", function ($scope, $uibModalInstance, args, $rootScope, SettingsService) {
    var tab = args.currentTab;
    setTimeout(function () {
        let CheckBoxValues = JSON.parse(localStorage.getItem("sessionVariables"));
        for (var item in CheckBoxValues[tab]) {
            let Field = CheckBoxValues[tab][item];
            angular.element(document).find('[data-rme-class="' + Field + '"]').addClass('selectedFld');
        }
        if (tab == "Spec Sheets") {
            for (var item in CheckBoxValues["SpecSheets"]) {
                let Field = CheckBoxValues["SpecSheets"][item];
                angular.element(document).find('[data-rme-class="' + Field + '"]').addClass('selectedFld');
            }
        }
        angular.element(document).find('.selectedFld').each(function () {
            angular.element(this).click();
        });

        if ($rootScope.userRole == 'Catalog User') {
            angular.element(document).find('[data-chk-container="S3 File Location"]').addClass('hide');
            angular.element(document).find('[data-chk-container="S3 File Path"]').addClass('hide');
        };

    });

    $scope.columnRefresh = function () {
        angular.element(document).find('.settingApplied').each(function () {
            angular.element(this).removeClass('settingApplied');
            angular.element(this).addClass('hide');
        });

        angular.element(document).find('.removeApplied').each(function () {
            angular.element(this).removeClass('removeApplied');
            angular.element(this).addClass('hide');
        });
    }

    //Reset the selected fields in settings popup
    $scope.resetColumns = function () {

        if (tab == "SEGY") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.SEGY = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "Horizon") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.Horizon = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "Velocity") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.Velocity = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "Spec Sheets") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.SpecSheets = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "LAS") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.LAS = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "AeroMag") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.AeroMag = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "GravMag") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.GravMag = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "Production") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.Production = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "Raster") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.Raster = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $rootScope.wellRastertab();
            $scope.columnRefresh();
        }
        else if (tab == "VWH") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.VWH = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "WellFile") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.WellFile = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "InterpretiveLas") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.InterpretiveLas = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "InterpretiveDocLibrary") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.InterpretiveDocLibrary = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "interpretiveDSDP") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.interpretiveDSDP = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "interpretivePWA") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.interpretivePWA = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }

        else if (tab == "BioStratTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.BioStratTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "ChronoStratTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.ChronoStratTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "CoreTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.CoreTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }

        else if (tab == "EnvFaciesTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.EnvFaciesTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "LithoStratTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.LithoStratTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "LithologyTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.LithologyTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }

        else if (tab == "MaturityTypeTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.MaturityTypeTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "RockEvaluationTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.RockEvaluationTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "SequenceStratTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.SequenceStratTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "Showtops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.Showtops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
        else if (tab == "VisualMaceralTops") {
            temp = JSON.parse(localStorage.getItem("sessionVariables"));
            temp.VisualMaceralTops = [];
            localStorage.setItem("sessionVariables", JSON.stringify(temp))
            $scope.columnRefresh();
        }
    }

    if ($rootScope.currentsettingTab !== args.currentTab) {
        $rootScope.currentsettingTab = args.currentTab;
        $scope.columnRefresh();
    }
    var settings = SettingsService.settings;

    $scope.currentTabSettings = '';

    //Set the current tab settings to show in Settings popup
    if (tab == "LAS") {
        $scope.currentTabSettings = settings.las;

    }
    else if (tab == "Production") {
        $scope.currentTabSettings = settings.production;
    }
    else if (tab == "Raster") {
        $scope.currentTabSettings = settings.raster;
    }
    else if (tab == "VWH") {
        $scope.currentTabSettings = settings.vwh;
    }
    else if (tab == "SEGY") {
        $scope.currentTabSettings = settings.segy;
    }
    else if (tab == "Velocity") {
        $scope.currentTabSettings = settings.velocity;
    }
    else if (tab == "Horizon") {
        $scope.currentTabSettings = settings.horizon;
    }
    else if (tab == "AeroMag") {
        $scope.currentTabSettings = settings.aeromag;
    }
    else if (tab == "GravMag") {
        $scope.currentTabSettings = settings.gravmag;
    }
    else if (tab == "Spec Sheets") {
        $scope.currentTabSettings = settings.specsheets;
    }
    else if (tab == "WellFile") {
        $scope.currentTabSettings = settings.wellFile;
    }
    else if (tab == "InterpretiveLas") {
        $scope.currentTabSettings = settings.interpretiveLas;
    }
    else if (tab == "interpretiveDSDP") {
        $scope.currentTabSettings = settings.DSDP;
    }
    else if (tab == "InterpretiveDocLibrary") {
        $scope.currentTabSettings = settings.DocLib;
    }
    else if (tab == "interpretivePWA") {
        $scope.currentTabSettings = settings.PWA;
    }
    else if (tab == "BioStratTops") {
        $scope.currentTabSettings = settings.BioStratsTops;
    }
    else if (tab == "ChronoStratTops") {
        $scope.currentTabSettings = settings.ChronoStratTops;
    }
    else if (tab == "CoreTops") {
        $scope.currentTabSettings = settings.CoreTops;
    }
    else if (tab == "EnvFaciesTops") {
        $scope.currentTabSettings = settings.EnvironmentFaciesTops;
    }
    else if (tab == "LithoStratTops") {
        $scope.currentTabSettings = settings.LithoStartTops;
    }
    else if (tab == "LithologyTops") {
        $scope.currentTabSettings = settings.LithologyTops;
    }
    else if (tab == "MaturityTypeTops") {
        $scope.currentTabSettings = settings.MaturityTypeTops;
    }
    else if (tab == "RockEvaluationTops") {
        $scope.currentTabSettings = settings.RockEvaluationTops;
    }
    else if (tab == "SequenceStratTops") {
        $scope.currentTabSettings = settings.SequenceStratTops;
    }
    else if (tab == "Showtops") {
        $scope.currentTabSettings = settings.ShowTops;
    }
    else if (tab == "VisualMaceralTops") {
        $scope.currentTabSettings = settings.VisualMaceralTops;
    }

    //Reset the selected fields in settings
    $scope.resetModal = function () {
        $uibModalInstance.dismiss('close');        
        $scope.resetColumns();
    }
    
    //Adds the selected fields in settings 
    var selectColumns = function () {
        let temp;
        angular.element(document).find('.settingApplied').each(function () {
            var colmnVal = angular.element(this).attr('data-rme-class');

            if (tab == "SEGY" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.SEGY.push(colmnVal);
                temp.SEGY = [...new Set(temp.SEGY)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Horizon" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.Horizon.push(colmnVal);
                temp.Horizon = [...new Set(temp.Horizon)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Velocity" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.Velocity.push(colmnVal);
                temp.Velocity = [...new Set(temp.Velocity)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Spec Sheets" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.SpecSheets.push(colmnVal);
                temp.SpecSheets = [...new Set(temp.SpecSheets)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "AeroMag" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.AeroMag.push(colmnVal);
                temp.AeroMag = [...new Set(temp.AeroMag)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "GravMag" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.GravMag.push(colmnVal);
                temp.GravMag = [...new Set(temp.GravMag)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "LAS" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.LAS.push(colmnVal);
                temp.LAS = [...new Set(temp.LAS)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Production" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.Production.push(colmnVal);
                temp.Production = [...new Set(temp.Production)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Raster" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.Raster.push(colmnVal);
                temp.Raster = [...new Set(temp.Raster)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "VWH" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.VWH.push(colmnVal);
                temp.VWH = [...new Set(temp.VWH)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "WellFile" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.WellFile.push(colmnVal);
                temp.WellFile = [...new Set(temp.WellFile)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }

            else if (tab == "InterpretiveLas" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.InterpretiveLas.push(colmnVal);
                temp.InterpretiveLas = [...new Set(temp.InterpretiveLas)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "InterpretiveDocLibrary" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.InterpretiveDocLibrary.push(colmnVal);
                temp.InterpretiveDocLibrary = [...new Set(temp.InterpretiveDocLibrary)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "interpretiveDSDP" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.interpretiveDSDP.push(colmnVal);
                temp.interpretiveDSDP = [...new Set(temp.interpretiveDSDP)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "interpretivePWA" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.interpretivePWA.push(colmnVal);
                temp.interpretivePWA = [...new Set(temp.interpretivePWA)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "BioStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.BioStratTops.push(colmnVal);
                temp.BioStratTops = [...new Set(temp.BioStratTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "ChronoStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.ChronoStratTops.push(colmnVal);
                temp.ChronoStratTops = [...new Set(temp.ChronoStratTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "CoreTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.CoreTops.push(colmnVal);
                temp.CoreTops = [...new Set(temp.CoreTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "EnvFaciesTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.EnvFaciesTops.push(colmnVal);
                temp.EnvFaciesTops = [...new Set(temp.EnvFaciesTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "LithoStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.LithoStratTops.push(colmnVal);
                temp.LithoStratTops = [...new Set(temp.LithoStratTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "LithologyTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.LithologyTops.push(colmnVal);
                temp.LithologyTops = [...new Set(temp.LithologyTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "MaturityTypeTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.MaturityTypeTops.push(colmnVal);
                temp.MaturityTypeTops = [...new Set(temp.MaturityTypeTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "RockEvaluationTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.RockEvaluationTops.push(colmnVal);
                temp.RockEvaluationTops = [...new Set(temp.RockEvaluationTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "SequenceStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.SequenceStratTops.push(colmnVal);
                temp.SequenceStratTops = [...new Set(temp.SequenceStratTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Showtops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.Showtops.push(colmnVal);
                temp.Showtops = [...new Set(temp.Showtops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "VisualMaceralTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                temp.VisualMaceralTops.push(colmnVal);
                temp.VisualMaceralTops = [...new Set(temp.VisualMaceralTops)]
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            if (tab == "Spec Sheets") {
                angular.element('.SpecSheets').find('[data-column-val="' + colmnVal + '"]').removeClass('hide');
                angular.element('.SpecSheets').find('[data-column-val="' + colmnVal + '"]').addClass('settingApplied')
            } else {
                angular.element('.' + tab + '').find('[data-column-val="' + colmnVal + '"]').removeClass('hide');
                angular.element('.' + tab + '').find('[data-column-val="' + colmnVal + '"]').addClass('settingApplied')
            }
        });
    }
    
    //Removes the selected fields in settings 
    var deselectColumns = function () {
        angular.element(document).find('.removeApplied').each(function () {
            var colmnVal = angular.element(this).attr('data-rme-class');

            if (tab == "SEGY" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.SEGY.indexOf(colmnVal)
                if (index > -1) {
                    temp.SEGY.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Horizon" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.Horizon.indexOf(colmnVal)
                if (index > -1) {
                    temp.Horizon.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Velocity" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.Velocity.indexOf(colmnVal)
                if (index > -1) {
                    temp.Velocity.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "AeroMag" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.AeroMag.indexOf(colmnVal)
                if (index > -1) {
                    temp.AeroMag.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "GravMag" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.GravMag.indexOf(colmnVal)
                if (index > -1) {
                    temp.GravMag.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Spec Sheets" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.SpecSheets.indexOf(colmnVal)
                if (index > -1) {
                    temp.SpecSheets.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "LAS" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.LAS.indexOf(colmnVal)
                if (index > -1) {
                    temp.LAS.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))

            }
            else if (tab == "Production" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.Production.indexOf(colmnVal)
                if (index > -1) {
                    temp.Production.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Raster" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.Raster.indexOf(colmnVal)
                if (index > -1) {
                    temp.Raster.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "VWH" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.VWH.indexOf(colmnVal)
                if (index > -1) {
                    temp.VWH.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "WellFile" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.WellFile.indexOf(colmnVal)
                if (index > -1) {
                    temp.WellFile.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }

            else if (tab == "InterpretiveLas" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.InterpretiveLas.indexOf(colmnVal)
                if (index > -1) {
                    temp.InterpretiveLas.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "InterpretiveDocLibrary" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.InterpretiveDocLibrary.indexOf(colmnVal)
                if (index > -1) {
                    temp.InterpretiveDocLibrary.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "interpretiveDSDP" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.interpretiveDSDP.indexOf(colmnVal)
                if (index > -1) {
                    temp.interpretiveDSDP.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "interpretivePWA" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.interpretivePWA.indexOf(colmnVal)
                if (index > -1) {
                    temp.interpretivePWA.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "BioStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.BioStratTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.BioStratTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "ChronoStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.ChronoStratTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.ChronoStratTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "CoreTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.CoreTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.CoreTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "EnvFaciesTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.EnvFaciesTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.EnvFaciesTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "LithoStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.LithoStratTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.LithoStratTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "LithologyTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.LithologyTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.LithologyTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "MaturityTypeTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.MaturityTypeTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.MaturityTypeTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "RockEvaluationTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.RockEvaluationTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.RockEvaluationTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "SequenceStratTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.SequenceStratTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.SequenceStratTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "Showtops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.Showtops.indexOf(colmnVal)
                if (index > -1) {
                    temp.Showtops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }
            else if (tab == "VisualMaceralTops" && colmnVal != null) {
                temp = JSON.parse(localStorage.getItem("sessionVariables"));
                let index = temp.VisualMaceralTops.indexOf(colmnVal)
                if (index > -1) {
                    temp.VisualMaceralTops.splice(index, 1);
                }
                localStorage.setItem("sessionVariables", JSON.stringify(temp))
            }

            if (tab == "Spec Sheets") {
                angular.element('.SpecSheets').find('[data-column-val="' + colmnVal + '"]').addClass('hide')
                angular.element('.SpecSheets').find('[data-column-val="' + colmnVal + '"]').removeClass('settingApplied');
            } else {
                angular.element('.' + tab + '').find('[data-column-val="' + colmnVal + '"]').addClass('hide')
                angular.element('.' + tab + '').find('[data-column-val="' + colmnVal + '"]').removeClass('settingApplied');
            }
        });
    }

    //Adds the selected fields in settings and loads current tab data
    $scope.ok = function () {
        selectColumns();
        deselectColumns();
        angular.element('.mapSidepanel').hide() //hide LHS Side Panel After Applying the Settings
        if (tab == "SEGY") {
            setTimeout(function () {                
                $rootScope.seismicSegYtab();
            }, 500)
        }
        if (tab == "Horizon") {
            setTimeout(function () {
                $rootScope.seismicHorizontab();
            }, 300)
        }

        if (tab == "Spec Sheets") {
            setTimeout(function () {
                $rootScope.seismicSpecSheettab();
            }, 300)
        }

        if (tab == "Velocity") {
            setTimeout(function () {
                $rootScope.seismicVelocitytab();
            }, 300)
        }
        if (tab == "AeroMag") {
            setTimeout(function () {
                $rootScope.seismicAeroMagtab();
            }, 300)
        }
        if (tab == "GravMag") {
            setTimeout(function () {
                $rootScope.seismicGravMagtab();
            }, 300)
        }
        if (tab == "WellFile") {
            setTimeout(function () {
                $rootScope.wellWFtab();
            }, 300)
        }

        $uibModalInstance.close('save');;        
    }

    $scope.closeModel = function (e) {
        $uibModalInstance.close('close');
    }
});