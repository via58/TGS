/*
File Name:- appliedFltrCtrl.js
Summary:- Applies the selected filter and removes the filter.
*/

angular.module('TGSApp').controller('appliedFltrCtrl', function ($scope, $location, $rootScope, WellService, InterpretiveService, SurveyService) {
  $rootScope.aplFilter = [];
  $rootScope.surveyaplFilter = [];
  $rootScope.IPFilter = [];

  $rootScope.selectedValArr = [];
  $rootScope.surveyselectedValArr = [];
  $rootScope.IPselectedValArr = [];

  $rootScope.aplFilterTitle = [];
  $rootScope.surveyaplFilterTitle = [];
  $rootScope.IPaplFilterTitle = [];

  //Broadcast the removePolygon method in Map when Polygon is deleted
  $scope.polygonrmAppliedFltr = function () {
    $rootScope.$broadcast("event:removePolygon", {});
  }

  //Executes when a filter is removed from well applied filters
  $scope.rmAppliedFltr = function (obj) {
    angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
    angular.element('.surveySummaryPanel').hide();
    $scope.moduleName = $rootScope.curTab;
    var applycntrlParnt = obj.currentTarget.parentNode.parentNode.parentNode.parentNode;
    var applycntrl = obj.currentTarget.parentNode

    var apyfilterlen = angular.element(applycntrlParnt).find('.detail-view-list').find('.applied-form-control').length;

    if (apyfilterlen > 1) {
      angular.element(applycntrl).remove()
    }
    else {
      angular.element(applycntrlParnt).remove();
    }

    if ($rootScope.selectedValArr != null && $rootScope.selectedValArr.length > 0) {
      for (var k = 0; k < $rootScope.selectedValArr.length; k++) {
        var tempObj = $rootScope.selectedValArr[k];

        if (tempObj.title == angular.element(applycntrlParnt).find('.detail-view-label').text()) {
          var tempArr = tempObj.value;

          for (var l = 0; l < tempArr.length; l++) {
            if (tempArr[l] == angular.element(applycntrl).find('span:first-child').text()) {
              tempArr.splice(l, 1);
              break;
            }
          }
          if (tempObj.title == "CustomerName") {  //Set wellCustomer and WellEntitleUrl empty
            $rootScope.wellCustomer = "";
            $rootScope.WellEntitleUrl = "";
          }
          if (tempObj.title !== "SeismictoWellSwitch") {
            if ($rootScope.selectedValArr.length > 0) {
              var len = $rootScope.selectedValArr.length - 1;
              var fieldName = $rootScope.selectedValArr[len].title;
              var fieldValue = $rootScope.selectedValArr[len].value;
            }
            if (tempArr.length == 0) {
              $rootScope.selectedValArr.splice(k, 1);
            }
            $rootScope.cascadeWellFilterData(fieldName, fieldValue, true);
          }
          else {
            if (tempArr.length == 0) {
              $rootScope.selectedValArr.splice(k, 1); //Remove applied filter
            }
          }
          //If uuid filter is removed, Set uuid empty
          if (tempObj.title == "SeismictoWellSwitch") {
            $rootScope.uuid = "";
          }
        }
      }
      if($rootScope.selectedValArr.length == 0)
        $rootScope.uuid = "";
      $rootScope.show2d3dEnable(); //Enables 2D/3D buttons for Entitlement user

      $rootScope.selectedFieldsDetails = [];
      var arrTmp = [];
      for (var k = 0; k < $rootScope.selectedValArr.length; k++) {
        var tempObj = $rootScope.selectedValArr[k];

        var tempArr = tempObj.value;

        for (var l = 0; l < tempArr.length; l++) {
          if (tempObj.title == "Query Builder Filter") {
            arrTmp = tempArr;
          }
          else {
            $rootScope.collectFilterData(tempObj.title, tempArr[l], tempObj.title); //Collects the current applied filters data
          }

        }
      }
      var queryBuilderStr = "";
      for (var i = 0; i < arrTmp.length; i++) {
        if (i == 0) {
          var field = arrTmp[i].split(":");
          if (field[0] == "CompletionDate" || field[0] == "SpudDate" || field[0] == "TotalDepthDate" || field[0] == "LogDate"
            || field[0] == "CreateDate" || field[0] == "UpdateDate" || field[0] == "WellCreateDate" || field[0] == "WellModifiedDate"
            || field[0] == "CreatedDate" || field[0] == "TDdate" || field[0] == "LogDateFile"){
              if (arrTmp[i].includes(' to ')) {
                var tempDate = arrTmp[i].split(' to ');
                queryBuilderStr = tempDate[0] + " 00:00:00.0<<" + tempDate[1] + " 00:00:00.0";
              }
              else
                queryBuilderStr = arrTmp[i] + " 00:00:00.0"; //for date type fields append the timestamp
          }
          else if(field[1] == "btw"){
            if (arrTmp[i].includes(' to ')){
              queryBuilderStr = arrTmp[i].replace(' to ','<<');
            }
          }
          else {
            if (field[0] == "LASTriple" || field[0] == "LASQuad") {
              var qbValue = field[2] == "1" ? "true" : "false";
              queryBuilderStr = field[0] + ":" + field[1] + ":" + qbValue;
            }
            else {
              queryBuilderStr = arrTmp[i];
            }
          }
        }
        else {
          var field = arrTmp[i].split(":");
          if (field[0] == "CompletionDate" || field[0] == "SpudDate" || field[0] == "TotalDepthDate" || field[0] == "LogDate"
            || field[0] == "CreateDate" || field[0] == "UpdateDate" || field[0] == "WellCreateDate" || field[0] == "WellModifiedDate"
            || field[0] == "CreatedDate" || field[0] == "TDdate" || field[0] == "LogDateFile"){
              if (arrTmp[i].includes(' to ')) {
                var tempDate = arrTmp[i].split(' to ');
                queryBuilderStr = queryBuilderStr + " AND " + tempDate[0] + " 00:00:00.0<<" + tempDate[1] + " 00:00:00.0";
              }
              else
                queryBuilderStr = queryBuilderStr + " AND " + arrTmp[i] + " 00:00:00.0"; //for date type fields append the timestamp
            }
          else if(field[1] == "btw"){
            if (arrTmp[i].includes(' to ')){
              queryBuilderStr = queryBuilderStr + " AND " + arrTmp[i].replace(' to ','<<');
            }
          }
          else {
            if (field[0] == "LASTriple" || field[0] == "LASQuad") {
              var qbValue = field[2] == "1" ? "true" : "false";
              queryBuilderStr = field[0] + ":" + field[1] + ":" + qbValue;
            }
            else {
              queryBuilderStr = queryBuilderStr + " AND " + arrTmp[i];
            }
          }
        }
      }

      WellService.wellQueryBuilder = queryBuilderStr;
      //Forms the Well filter string
      $rootScope.formFilter();
      //If filter is removed from Well applied filters, loads current tab data
      if ($scope.moduleName === undefined) {
        $rootScope.loadWellDetails();
        $rootScope.allwellmap();
      }
      else if ($scope.moduleName === "home") {
        $rootScope.loadWellDetails();
        $rootScope.allwellmap();
      }
      else if ($scope.moduleName === "LAS") {
        $rootScope.wellLastab();
      }
      else if ($scope.moduleName === "Raster") {
        $rootScope.wellRastertab();
      }
      else if ($scope.moduleName === "Production") {
        $rootScope.welproductiontab();
      }
      else if ($scope.moduleName === "VWH") {
        $rootScope.wellVWHtab();
      }
      else if ($scope.moduleName === "WellFile") {
        $rootScope.wellWFtab();
      }
      else if ($scope.moduleName === "InterpretiveDocLibrary") {
        $rootScope.interdoclibtab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "interpretivePWA") {
        $rootScope.interpretivePWATab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "InterpretiveLas") {
        $rootScope.interpretiveLasTab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "interpretiveDSDP") {
        $rootScope.interpretiveDSDPTab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }


      else if ($scope.moduleName === "BioStratTops") {
        $rootScope.interbiostrattop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "ChronoStratTops") {
        $rootScope.interchronostrattop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "CoreTops") {
        $rootScope.interCoreTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "EnvFaciesTops") {
        $rootScope.interEnvFaciesTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);
      }
      else if ($scope.moduleName === "LithoStratTops") {
        $rootScope.interLithoStratTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "LithologyTops") {
        $rootScope.interLithologyTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "MaturityTypeTops") {
        $rootScope.interMaturitytypetop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "RockEvaluationTops") {
        $rootScope.interrockevaluationtop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "SequenceStratTops") {
        $rootScope.intersequencestrattop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "Showtops") {
        $rootScope.interShowtop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "VisualMaceralTops") {
        $rootScope.intervisualmaceraltop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);
      }

      //Show the Filters Applied message in applied filters header      
      setTimeout(function () {
        $rootScope.showAppliedtxt();
      }, 1000);

    }

    setTimeout(function () {
      angular.element('.Wellfltrgrp').find('.dropdown-menu').find('li').find('a').find('i').removeClass('icon-ok').addClass('icon-empty');
      angular.element('.wellappliedgrp').find('.applied-filter-group').each(function () {
        var datalocation = angular.element(this).find('.detail-view-label').text();
        if (angular.element(this).find('.detail-view-label').text() == datalocation) {
          angular.element(this).find('.detail-view-list').find('.applied-form-control').each(function () {
            var datalocationinfo = angular.element(this).find('span:first').text();
            angular.element('.Wellfltrgrp').find('[data-location]').each(function () {
              if (angular.element(this).attr('data-location') == datalocation) {
                angular.element(angular.element(this)).find('.dropdown-menu li').each(function () {
                  if (angular.element(this).find('a').text().trim() == datalocationinfo) {
                    angular.element(this).find('a').find('i').removeClass('icon-empty').addClass('icon-ok');
                  }
                });
              }
            });
          });
        }
      }
      );
    }, 3000)
  }

  //Executes when a filter is removed from interpretive applied filters
  $scope.iprmAppliedFltr = function (obj) {
    angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
    $scope.moduleName = $rootScope.curTab;
    var applycntrlParnt = obj.currentTarget.parentNode.parentNode.parentNode.parentNode;
    var applycntrl = obj.currentTarget.parentNode

    var apyfilterlen = angular.element(applycntrlParnt).find('.detail-view-list').find('.applied-form-control').length;

    if (apyfilterlen > 1) {
      angular.element(applycntrl).remove()
    }
    else {
      angular.element(applycntrlParnt).remove();
    }

    if ($rootScope.IPselectedValArr != null && $rootScope.IPselectedValArr.length > 0) {
      for (var k = 0; k < $rootScope.IPselectedValArr.length; k++) {
        var tempObj = $rootScope.IPselectedValArr[k];

        if (tempObj.title == angular.element(applycntrlParnt).find('.detail-view-label').text()) {
          var tempArr = tempObj.value;

          for (var l = 0; l < tempArr.length; l++) {
            if (tempArr[l] == angular.element(applycntrl).find('span:first-child').text()) {
              tempArr.splice(l, 1);
              break;
            }
          }
          if (tempArr.length == 0) {
            $rootScope.IPselectedValArr.splice(k, 1);
          }
        }
      }

      $rootScope.IPselectedFieldsDetails = [];
      var arrTmp = [];
      for (var k = 0; k < $rootScope.IPselectedValArr.length; k++) {
        var tempObj = $rootScope.IPselectedValArr[k];

        var tempArr = tempObj.value;

        for (var l = 0; l < tempArr.length; l++) {
          if (tempObj.title == "Query Builder Filter") {
            arrTmp = tempArr;
          }

        }
      }

      var queryBuilderStr = "";
      for (var i = 0; i < arrTmp.length; i++) {
        if (i == 0) {
          var field = arrTmp[i].split(":");
          if (field[0] == "CompletionDate" || field[0] == "SpudDate" || field[0] == "TotalDepthDate" || field[0] == "LogDate"
            || field[0] == "CreateDate" || field[0] == "UpdateDate" || field[0] == "WellCreateDate" || field[0] == "WellModifiedDate"
            || field[0] == "CreatedDate" || field[0] == "TDdate" || field[0] == "LogDateFile"){
            if (arrTmp[i].includes(' to ')) {
              var tempDate = arrTmp[i].split(' to ');
              queryBuilderStr = tempDate[0] + " 00:00:00.0<<" + tempDate[1] + " 00:00:00.0";
            }
            else
            queryBuilderStr = arrTmp[i] + " 00:00:00.0"; //for date type fields append the timestamp
          }
          else if(field[1] == "btw"){
            if (arrTmp[i].includes(' to ')){
              queryBuilderStr = arrTmp[i].replace(' to ','<<');
            }
          }
          else
            queryBuilderStr = arrTmp[i];
        }
        else {
          var field = arrTmp[i].split(":");
          if (field[0] == "CompletionDate" || field[0] == "SpudDate" || field[0] == "TotalDepthDate" || field[0] == "LogDate"
            || field[0] == "CreateDate" || field[0] == "UpdateDate" || field[0] == "WellCreateDate" || field[0] == "WellModifiedDate"
            || field[0] == "CreatedDate" || field[0] == "TDdate" || field[0] == "LogDateFile"){
              if (arrTmp[i].includes(' to ')) {
                var tempDate = arrTmp[i].split(' to ');
                queryBuilderStr = queryBuilderStr + " AND " + tempDate[0] + " 00:00:00.0<<" + tempDate[1] + " 00:00:00.0";
            }
            else
            queryBuilderStr = queryBuilderStr + " AND " + arrTmp[i] + " 00:00:00.0";
          }
          else if(field[1] == "btw"){
            if (arrTmp[i].includes(' to ')){
              queryBuilderStr = arrTmp[i].replace(' to ','<<');
            }
          }
          else
            queryBuilderStr = queryBuilderStr + " AND " + arrTmp[i];
        }
      }

      InterpretiveService.ipQueryBuilder = queryBuilderStr;

      //If filter is removed from Interpretive applied filters, loads current tab data
      if ($scope.moduleName === "InterpretiveDocLibrary") {
        $rootScope.interdoclibtab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "interpretivePWA") {
        $rootScope.interpretivePWATab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "InterpretiveLas") {
        $rootScope.interpretiveLasTab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "interpretiveDSDP") {
        $rootScope.interpretiveDSDPTab();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }


      else if ($scope.moduleName === "BioStratTops") {
        $rootScope.interbiostrattop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "ChronoStratTops") {
        $rootScope.interchronostrattop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "CoreTops") {
        $rootScope.interCoreTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "EnvFaciesTops") {
        $rootScope.interEnvFaciesTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);
      }
      else if ($scope.moduleName === "LithoStratTops") {
        $rootScope.interLithoStratTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "LithologyTops") {
        $rootScope.interLithologyTops();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "MaturityTypeTops") {
        $rootScope.interMaturitytypetop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "RockEvaluationTops") {
        $rootScope.interrockevaluationtop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "SequenceStratTops") {
        $rootScope.intersequencestrattop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "Showtops") {
        $rootScope.interShowtop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);

      }
      else if ($scope.moduleName === "VisualMaceralTops") {
        $rootScope.intervisualmaceraltop();
        setTimeout(function () {
          angular.element('[data-fgname="wellqb"]').parent('div').parent('.applied-filter-group').hide();
        }, 2500);
      }
      //Show the Filters Applied message in applied filters header      
      $rootScope.showAppliedtxt();
    }

  }

  //Executes when a filter is removed from Seismic applied filters
  $scope.surveyrmAppliedFltr = function (obj) {
    angular.element('.mapSidepanel').hide() //hide LHS Side Panel After resetting the Filter
    angular.element('.surveySummaryPanel').hide();
    $scope.moduleName = $rootScope.curTab;
    var applycntrlParnt = obj.currentTarget.parentNode.parentNode.parentNode.parentNode;
    var applycntrl = obj.currentTarget.parentNode
    var apyfilterlen = angular.element(applycntrlParnt).find('.detail-view-list').find('.applied-form-control').length;

    if (apyfilterlen > 1) {
      angular.element(applycntrl).remove()
    }
    else {
      angular.element(applycntrlParnt).remove();
    }

    if ($rootScope.surveyselectedValArr != null && $rootScope.surveyselectedValArr.length > 0) {
      for (var k = 0; k < $rootScope.surveyselectedValArr.length; k++) {
        var tempObj = $rootScope.surveyselectedValArr[k];
        if (tempObj.title == angular.element(applycntrlParnt).find('.detail-view-label').text()) {
          var tempArr = tempObj.value;
          for (var l = 0; l < tempArr.length; l++) {
            if (tempArr[l] == angular.element(applycntrl).find('span:first-child').text()) {
              tempArr.splice(l, 1);
              break;
            }
          }

          if (tempObj.title == "CustomerName") {
            $rootScope.surveyCustomer = "";
            $rootScope.surveyEntitlementUrl = "";
            $rootScope.horizonEntitlementUrl = "";
            $rootScope.aeroMagEntitlementUrl = "";
            $rootScope.gravMagEntitlementUrl = "";
            $rootScope.projShapeEntitlementUrl = "";
            $rootScope.horizonsurveyType = "";
            $rootScope.AeroMagSurveyType = "";
            $rootScope.GravMagSurveyType = "";
          }
          if (tempObj.title !== "WelltoSurveySwitch") {
            if ($rootScope.surveyselectedValArr.length > 0) {
              var len = $rootScope.surveyselectedValArr.length - 1;
              var fieldName = $rootScope.surveyselectedValArr[len].title;
              if ($rootScope.surveyselectedValArr[len].value == "OffShore") {
                var fieldValue = "0"
              }
              else if ($rootScope.surveyselectedValArr[len].value == "OnShore") {
                var fieldValue = "1"
              }
              else {
                var fieldValue = $rootScope.surveyselectedValArr[len].value;
              }
            }
            if (tempArr.length == 0) {
              $rootScope.surveyselectedValArr.splice(k, 1);
            }

            $rootScope.cascadeSurveyFilterData(fieldName, fieldValue, true);
          }
          else {
            if (tempArr.length == 0) {
              $rootScope.surveyselectedValArr.splice(k, 1);
            }
          }

          if (tempObj.title == "WelltoSurveySwitch") {
            $rootScope.uuid = "";
          }
        }
      }

      if($rootScope.surveyselectedValArr.length == 0)
        $rootScope.uuid = "";
      $rootScope.show2d3dEnable(); //Enables 2D/3D buttons for Entitlement user

      $rootScope.surveyselectedFieldsDetails = [];
      var arrTmp = [];
      for (var k = 0; k < $rootScope.surveyselectedValArr.length; k++) {
        var tempObj = $rootScope.surveyselectedValArr[k];
        if (tempObj.value == "OnShore") {
          var tempArr = "1"
        } else if (tempObj.value == "OffShore") {
          var tempArr = "0";
        }
        else {
          var tempArr = tempObj.value;
        }
        for (var l = 0; l < tempArr.length; l++) {
          if (tempObj.title == "Query Builder Filter") {
            arrTmp = tempArr;
          }
          else {
            var fildname = tempObj.title == "Offshore / Onshore" ? "Onshore" : tempObj.title;
            $rootScope.surveycollectFilterData(fildname, tempArr[l], tempObj.title);
          }

        }
      }

      var queryBuilderStr = "";
      for (var i = 0; i < arrTmp.length; i++) {
        if (i == 0) {
          var field = arrTmp[i].split(":");
          if (field[0] == "ProjectAttachmentUpdateDate" || field[0] == "SurveyAcquisitionEndDate" || field[0] == "SurveyAcquisitionStartDate") {
            if (arrTmp[i].includes(' to ')) {
              var tempDate = arrTmp[i].split(' to ');
              queryBuilderStr = tempDate[0] + " 00:00:00.0<<" + tempDate[1] + " 00:00:00.0";
            }
            else
              queryBuilderStr = arrTmp[i] + " 00:00:00.0"; //for date type fields append the timestamp
          }
          else
            queryBuilderStr = arrTmp[i];
        }
        else {
          var field = arrTmp[i].split(":");
          if (field[0] == "ProjectAttachmentUpdateDate" || field[0] == "SurveyAcquisitionEndDate" || field[0] == "SurveyAcquisitionStartDate") {
            if (arrTmp[i].includes(' to ')) {
              var tempDate = arrTmp[i].split(' to ');
              queryBuilderStr = queryBuilderStr + " AND " + tempDate[0] + " 00:00:00.0<<" + tempDate[1] + " 00:00:00.0";
            }
            else
              queryBuilderStr = queryBuilderStr + " AND " + arrTmp[i] + " 00:00:00.0"; //for date type fields append the timestamp
          }
          else
            queryBuilderStr = queryBuilderStr + " AND " + arrTmp[i];
        }
      }

      SurveyService.surveyQueryBuilder = queryBuilderStr;
      //Forms the Seismic filter string
      $rootScope.surveyformFilter();
      //If filter is removed from Seismic applied filters, loads current tab data
      if ($scope.moduleName === undefined) {
        $rootScope.loadSurveyDetails();
      }
      else if ($scope.moduleName === "home") {
        $rootScope.loadSurveyDetails();
      }
      else if ($scope.moduleName === "SEGY") {
        $rootScope.seismicSegYtab();
      }
      else if ($scope.moduleName === "Horizon") {
        $rootScope.seismicHorizontab();
      }
      else if ($scope.moduleName === "Velocity") {
        $rootScope.seismicVelocitytab();
      }
      else if ($scope.moduleName === "GravMag") {
        $rootScope.seismicGravMagtab();
      }
      else if ($scope.moduleName === "AeroMag") {
        $rootScope.seismicAeroMagtab();
      }
      else if ($scope.moduleName === "Spec Sheets") {
        $rootScope.seismicSpecSheettab();
      }
      //Show the Filters Applied message in applied filters header
      $rootScope.showAppliedtxt();
    }

    setTimeout(function () {
      angular.element(document).find('.Seismicfltrgrp').find('.dropdown-menu').find('li').find('a').find('i').removeClass('icon-ok').addClass('icon-empty');
      angular.element('.surveyappliedgrp').find('.applied-filter-group').each(function () {
        var datalocation = angular.element(this).find('.detail-view-label').text();
        if (angular.element(this).find('.detail-view-label').text() == datalocation) {
          angular.element(this).find('.detail-view-list').find('.applied-form-control').each(function () {
            var datalocationinfo = angular.element(this).find('span:first').text();
            angular.element('.Seismicfltrgrp').find('[data-location]').each(function () {
              if (angular.element(this).attr('data-location') == datalocation) {
                angular.element(angular.element(this)).find('.dropdown-menu li').each(function () {
                  if (angular.element(this).find('a').text().trim() == datalocationinfo) {
                    angular.element(this).find('a').find('i').removeClass('icon-empty').addClass('icon-ok');
                  }
                });
              }
            });
          });
        }
      }
      );
    }, 3000)
  }

  angular.element(document).on('click', '.btn-info.btn-filter-active', function () {
    if (angular.element(this).hasClass('collapsed')) {
      angular.element(this).find('span.glyphicon-chevron-down').removeClass('hide');
      angular.element(this).find('span.glyphicon-chevron-up').addClass('hide');
    }
    else {
      angular.element(this).find('span.glyphicon-chevron-down').addClass('hide');
      angular.element(this).find('span.glyphicon-chevron-up').removeClass('hide');
    }
  })

  angular.element(document).on('click', '.expand-fieldset', function () {
    let box = document.getElementById('applied-filter-panel')
    box.style.maxHeight = 'none';
  }
  )
  angular.element(document).on('click', '.contract-fieldset', function () {
    let box = document.getElementById('applied-filter-panel')
    box.style.maxHeight = '150px';
  }
  )
});