/*
File Name:- seismicMultiSelectCtrl.js
Summary:- This page will collects the Meta Data fields, form filter string to fetch the Seismic details .
*/

angular.module('TGSApp').controller('seismicMultiSelectCtrl', function ($scope, $rootScope, $http, $timeout, $interval, $compile, SurveyService, Common) {
	$rootScope.surveytmArr = [];
	//Geographics	
	$scope.surveypregion = [];
	$scope.selectedsurveypregion = [];	
	$scope.surveycountry = [];
	$scope.selectedsurveycountry = [];	
	$scope.surveyonshoreoffshore = [];
	$scope.selectedsurveyonshoreoffshore = [];	
	$scope.surveysname = [];
	$scope.selectedsurveysname = [];	
	$scope.surveystype = [];
	$scope.selectedsurveystype = [];	
	$scope.surveyactualsstatus = [];
	$scope.selectedsurveyactualsstatus = [];	
	$scope.surveysstatus = [];
	$scope.selectedsurveysstatus = [];	
	$scope.surveyastartdate = [];
	$scope.selectedsurveyastartdate = [];	
	$scope.surveyaenddate = [];
	$scope.selectedsurveyaenddate = [];	
	$scope.surveyprojectname = [];
	$scope.selectedsurveyprojectname = [];	
	$scope.surveyprojecttype = [];
	$scope.selectedsurveyprojecttype = [];	
	$scope.surveyprojectgroupname = [];
	$scope.selectedsurveyprojectgroupname = [];	
	$scope.surveyprojectsubtype = [];
	$scope.selectedsurveyprojectsubtype = [];	
	$scope.surveyproducttype = [];
	$scope.selectedsurveyproducttype = [];	
	$scope.surveyproductname = [];
	$scope.selectedsurveyproductname = [];	
	$scope.surveyproductabbreviation = [];
	$scope.selectedsurveyproductabbreviation = [];	
	$scope.surveyproductdescription = [];
	$scope.selectedsurveyproductdescription = [];	
	$scope.surveywebcaregory = [];
	$scope.selectedsurveywebcaregory = [];	
	$scope.surveyproductgroup = [];
	$scope.selectedsurveyproductgroup = [];	
	$scope.surveylinenumber = [];
	$scope.selectedsurveylinenumber = [];

	$scope.hasQuerybuilder = false;;
	$scope.selectedtd = [];
	$rootScope.surveyaplFilter = [];
	$rootScope.surveyselectedFieldsDetails = [];
	$scope.cntrys = [];

	$rootScope.surveyaplFilterData = [];

	// This function fetches the Seismic Filter data .
	$rootScope.surveyloadFilterData = function () {

		// angular.element(document).find("#viewDiv").addClass('mapoverlay');
		// angular.element(document).find("#viewDiv").append('<div id="spinnerDiv" class="spinner"></div>');

		//Form Post request for all Seismic Geography Metadata filter combo values
		var paramInfo = {
			requestTimestamp : Common.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
		}

		paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      	paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

		var paramInfoList = $.param(paramInfo);

		var request = {
			method: 'POST',
			data: paramInfoList,
			url: SurveyService.urlValue + SurveyService.SeismicGeographyMetaDataFilters,			
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
		  }
		//   Calling http service request to get SeismicGeographyMetaDataFilters data
		$http(request).
			then(function (response) {
				$scope.surveypregion = $scope.surveyfillData(response.data.regionList, "Region", "Region");
				$scope.surveycountry = $scope.surveyfillData(response.data.countryNamesList, "Country", "Country");
				$scope.surveyonshoreoffshore = $scope.OnshoreOffshore(response.data.onshoreList, "Onshore", "Onshore");

				// angular.element(document).find("#viewDiv").addClass('mapoverlay');
				// angular.element(document).find("#viewDiv").append('<div id="spinnerDiv" class="spinner"></div>');

			}).catch(function (response) {
				angular.element(document.body).find('#spinnerDiv').remove();
				// angular.element(document).find("#viewDiv").removeClass('mapoverlay');
			});
			//Form Post request for to get SeismicSurveyMetaDataFilters data
			var paramInfo = {
			requestTimestamp : Common.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
			}
			paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      		paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
			
			var paramInfoList = $.param(paramInfo);

			var request = {
				method: 'POST',
				data: paramInfoList,
				url: SurveyService.urlValue + SurveyService.SeismicSurveyMetaDataFilters,			
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
			  }
		//   Calling http service request to get SeismicSurveyMetaDataFilters data.
		$http(request).
			then(function (response) {
				$scope.surveysname = $scope.surveyfillData(response.data.surveyNamesList, "SurveyName", "SurveyName");
				$scope.surveystype = $scope.surveyfillData(response.data.surveyTypesList, "SurveyType", "SurveyType");
				$scope.surveyactualsstatus = $scope.surveyfillData(response.data.actualSurveyStatusList, "ActualSurveyStatus", "ActualSurveyStatus");
				$scope.surveysstatus = $scope.surveyfillData(response.data.surveyStatusList, "SurveyStatus", "SurveyStatus");
				$scope.surveyselectedFieldsDetails = [];
				angular.element(document.body).find('#spinnerDiv').remove();				

			}).catch(function (response) {
				angular.element(document.body).find('#spinnerDiv').remove();
								
			});

			//Form Post request for to get SeismicProjectMetaDataFilters data
			var paramInfo = {
				requestTimestamp : Common.getCurrentDateTime(),
				token: $rootScope.sessionToken,
				access_token: $rootScope.accessToken
				}

				paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      			paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
				
			var paramInfoList = $.param(paramInfo);
		
			var request = {
				method: 'POST',
				data: paramInfoList,
				url: SurveyService.urlValue + SurveyService.SeismicProjectMetaDataFilters,			
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
			  }
		//   Calling http service request to get SeismicProjectMetaDataFilters data.
			$http(request).
			then(function (response) {
				$scope.surveyprojectname = $scope.surveyfillData(response.data.projectNameList, "ProjectName", "ProjectName");
				$scope.surveyprojecttype = $scope.surveyfillData(response.data.projectTypeList, "ProjectType", "ProjectType");
				$scope.surveyprojectgroupname = $scope.surveyfillData(response.data.projectGroupNameList, "ProjectGroupName", "ProjectGroupName");
				$scope.surveyprojectsubtype = $scope.surveyfillData(response.data.projectSubTypeList, "ProjectSubType", "ProjectSubType");
				$scope.surveyselectedFieldsDetails = [];

				angular.element(document.body).find('#spinnerDiv').remove();				

			}).catch(function (response) {
			});
			//Form Post request for to get SeismicProductMetaDataFilters data
			var paramInfo = {
				requestTimestamp : Common.getCurrentDateTime(),
				token: $rootScope.sessionToken,
				access_token: $rootScope.accessToken
			}
			moment
			paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      		paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
			
			var paramInfoList = $.param(paramInfo);
	
			var request = {
				method: 'POST',
				data: paramInfoList,
				url: SurveyService.urlValue + SurveyService.SeismicProductMetaDataFilters,			
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
			  }

		//   Calling http service request to get SeismicProductMetaDataFilters data .
			$http(request).
			then(function (response) {
				$scope.surveyproductname = $scope.surveyfillData(response.data.productNameList, "ProductName", "ProductName");
				$scope.surveyproducttype = $scope.surveyfillData(response.data.productTypeList, "ProductType", "ProductType");
				$scope.surveyproductabbreviation = $scope.surveyfillData(response.data.productAbrevList, "ProductAbrev", "ProductAbrev");
				$scope.surveyproductdescription = $scope.surveyfillData(response.data.productDescList, "ProductDesc", "ProductDesc");
				$scope.surveywebcaregory = $scope.surveyfillData(response.data.webCategoryList, "ProductWebCategory", "ProductWebCategory");
				$scope.surveyproductgroup = $scope.surveyfillData(response.data.productGroupList, "ProductGroup", "ProductGroup");
				$scope.surveylinenumber = $scope.surveyfillData(response.data.lineNumberList, "LineNumber", "LineNumber");

				$scope.surveyselectedFieldsDetails = [];
				angular.element(document.body).find('#spinnerDiv').remove();				
			}).catch(function (response) {
				angular.element(document.body).find('#spinnerDiv').remove();								
			});
		//   Calling http service request to get Entitlement data .

		var paramInfo = {
			module: "Seismic",
			requestTimestamp : Common.getCurrentDateTime(),
            token: $rootScope.sessionToken,
            access_token: $rootScope.accessToken
		}

		paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      	paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

		var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent

		var request = {
			method: 'POST',
			url: SurveyService.urlValue + SurveyService.allCustomer,
			data: paramInfoList,
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' }

		}
		$http(request)
			.then(function (response) {
				var CustomerNames = $scope.surveyEntitlementtFillData(response.data, "CustomerName", "CustomerName");
				var surveyCustomeroption = '';
				for (var i = 0; i < CustomerNames.length; i++) {
					surveyCustomeroption = surveyCustomeroption + "<option value='" + CustomerNames[i].customerId + "'>" + CustomerNames[i].name + "</option>";
				}
				angular.element('.selectedEntitleUser').append(surveyCustomeroption);
			}).catch(function (response) {				
			});
	}
	//Invoking the above function whenever this controller loads.
	$scope.surveyloadFilterData();

	//Fills the Metadata values
	$scope.surveyfillData = function (fieldArr, fieldName, titleName) {
		var arr = [];
		var count = 0;
		if (fieldArr !== null && fieldArr.length > 0) {
			for (var i = 0; i < fieldArr.length; i++) {
				if (fieldArr[i].trim() != "") {
					var obj = new Object();
					obj.id = count + 1;
					obj.name = fieldArr[i];
					obj.fieldName = fieldName;
					obj.titleName = titleName;
					obj.displayName = "";
					arr[arr.length] = obj;
					count++;
				}
			}
			return arr;
		}
	}

	//This function gets the survey fields as input and returns array of object for EntitlementtFilter
	$scope.surveyEntitlementtFillData = function (fieldArr, fieldName, titleName) {
		var arr = [];
		if (fieldArr.length > 0) {
			for (var i = 0; i < fieldArr.length; i++) {
				if (fieldArr[i] != "") {
					var obj = new Object();
					obj.name = fieldArr[i].CustId;
					obj.customerId = fieldArr[i].CustomerId;
					obj.fieldName = fieldName;
					obj.titleName = titleName;
					obj.displayName = "";
					arr[arr.length] = obj;
				}
			}
		}
		return arr;
	}
	//Get the well Entitlement user details
	$scope.getSeismicCustomerData = function () {

		var sel = document.getElementById('seismicent');
		var opt = sel.options[sel.selectedIndex];
		var custId = opt.value;
		var custName = opt.text;
		if (custName !== "Select Customer" && custId !== "") {
			$rootScope.surveyCustomer = { customerId: custId, name: custName };
			//$scope.collectsurveyEntitlementData("CustomerName", $rootScope.surveyCustomer, "CustomerName");
		}
	}
		
	// Set Onshore/OffShore value
	$scope.OnshoreOffshore = function (fieldArr, fieldName, titleName) {
		var arr = [];
		var count = 0;
		if (fieldArr !== null && fieldArr.length > 0) {
			for (var i = 0; i < fieldArr.length; i++) {
				if (fieldArr[i].trim() != "") {
					var obj = new Object();
					obj.id = count + 1;
					obj.name = fieldArr[i];

					switch (fieldArr[i]) {
						case "1":
							obj.displayName = "OnShore";
							break;
						case "0":
							obj.displayName = "OffShore";
							break;
						default:
							break;
					}
					obj.fieldName = fieldName;
					obj.titleName = titleName;
					arr[arr.length] = obj;
					count++;
				}
			}
		}
		return arr;
	}

	//Form the Applied filter values 
	$rootScope.surveyappliedFilterData = function () {
		for (var i = 0; ($rootScope.surveyaplFilterData !== null && i < $rootScope.surveyaplFilterData.length); i++) {
			if ($rootScope.surveyaplFilterData[i] !== undefined) {
				var tempSelectedValArr = $rootScope.surveyaplFilterData[i].split("||");
				var tempSelectedValArr1 = [];

				for (var val = 0; val < tempSelectedValArr.length; val++) {
					if (tempSelectedValArr[val] !== "" && tempSelectedValArr[val] !== null) {
						var filval = tempSelectedValArr[val].includes('~~') ? tempSelectedValArr[val].replace('~~', ',') : tempSelectedValArr[val];
						tempSelectedValArr1.push(filval);
					}
				}
				var obj = new Object();
				obj.value = tempSelectedValArr1;
				obj.fgname = "sfcommon";
				obj.type = "comnfilter";
				if ($rootScope.surveyaplFilterTitle[i] !== undefined) {
					obj.title = $rootScope.surveyaplFilterTitle[i];
				}
				else {
					obj.title = "Polygon Name";
				}
				$rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;
			}
		}

		setTimeout(function () {
			angular.element('.Seismicfltrgrp').find('.dropdown-menu').find('li').find('a').find('i').removeClass('icon-ok').addClass('icon-empty');
			angular.element('.surveyappliedgrp').find('.applied-filter-group').each(function () {

				var datalocation = angular.element(this).find('.detail-view-label').text();
				if (angular.element(this).find('.detail-view-label').text() == datalocation) {

					angular.element(this).find('.detail-view-list').find('.applied-form-control').each(function () {
						var datalocationinfo = angular.element(this).find('span:first').text();

						angular.element('.Seismicfltrgrp').find('[data-location]').each(function () {

							if (angular.element(this).attr('data-location') == datalocation) {

								angular.element(angular.element(this)).find('.dropdown-menu li').each(function () {

									if (angular.element(this).find('a').text().trim() == datalocationinfo) {

										angular.element(this).find('a').find('i').removeClass('icon-empty').addClass('icon-ok');
									}
								});
							}
						});
					});
				}
			}
			);
		}, 3000)
	}

	//Below method will checks duplicate values for the selected filter values
	var checkDuplicateValue = function (selectedValue, checkedValue) {
		if (checkedValue) {
			for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
				var arr = $rootScope.surveyselectedValArr[i].value;
				var title = $rootScope.surveyselectedValArr[i].title;
				for (var j = 0; j < arr.length; j++) {
					if (arr[j] == selectedValue.name && title == selectedValue.fieldName) {
						return true;
					}

					if (arr[j] == selectedValue.displayName && title == "Offshore / Onshore") {
						return true;
					}

				}
			}
		}


		return false;
	}

	//Below function will call when a value is selected in meta data filters.
	$scope.serviceCall = function (selectedField, checkedValue) {
		var flag = checkDuplicateValue(selectedField.model, checkedValue);
		//If any duplicate value is selected, shows the below popup.
		if (flag) {
			if (selectedField.model.fieldName == "Onshore")
				$.alertable.alert("Filter value '" + selectedField.model.displayName + "' is already exist in applied filter");
			else
				$.alertable.alert("Filter value '" + selectedField.model.name + "' is already exist in applied filter");
			return;
		}
		var filterStr = "";
		//Below method will collects the selected meta data values
		if (checkedValue) {
			$rootScope.surveycollectFilterData(selectedField.model.fieldName, selectedField.model.name, selectedField.model.titleName, checkedValue);

		}
		else {
			//Below method will removed the unselected meta data values
			$rootScope.surveyremoveData(selectedField.model.fieldName, selectedField.model.name);
		}
		angular.element('.dropdown, .dropdown-menu').unbind('mouseleave');
		//Cascading filter values
		//Loads the metadata values based on filter values
		$scope.cascadeSurveyFilterData(selectedField.model.fieldName, $rootScope.surveyselectedFieldsDetails, false);
	}

	//Loads the Meta data values based the parent value selected
	$rootScope.cascadeSurveyFilterData = function (fieldName, selectedFields, isfromApplFilter) {
		var surveySelectedFieldDetails = selectedFields;

		if (isfromApplFilter && surveySelectedFieldDetails.length == 0) {
			var filterVal = "";
			$scope.getCountryData(filterVal, "Region");
			$scope.getOffshoreOnshoreData(filterVal, "Region");
			$scope.getSurveyTypeData(filterVal, "Region");
			$scope.getActualSurveyStatusData(filterVal, "Region");
			$scope.getSurveyStatusData(filterVal, "Region");
			$scope.getSurveyNameData(filterVal, "Region");
			$scope.getProjectTypeData(filterVal, "Region");
			$scope.getProjectGroupNameData(filterVal, "Region");
			$scope.getProjectSubTypeData(filterVal, "Region");
			$scope.getProjectNameData(filterVal, "Region");
			$scope.getProductTypeData(filterVal, "Region");
			$scope.getProductDescriptionData(filterVal, "Region");
			$scope.getWebCaregoryData(filterVal, "Region");
			$scope.getProductGroupData(filterVal, "Region");
			$scope.getProductNameData(filterVal, "Region");
		}

		//State Cascading - Load Region,Country,SurveyType and ActualSurveyStatus
		if (fieldName == "Region") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "Region") {
					$scope.getCountryData(filterVal, "Region");
					$scope.getOffshoreOnshoreData(filterVal, "Region");
					$scope.getSurveyTypeData(filterVal, "Region");
					$scope.getActualSurveyStatusData(filterVal, "Region");
					$scope.getSurveyStatusData(filterVal, "Region");
					$scope.getSurveyNameData(filterVal, "Region");
					$scope.getProjectTypeData(filterVal, "Region");
					$scope.getProjectGroupNameData(filterVal, "Region");
					$scope.getProjectSubTypeData(filterVal, "Region");
					$scope.getProjectNameData(filterVal, "Region");
					$scope.getProductTypeData(filterVal, "Region");
					$scope.getProductDescriptionData(filterVal, "Region");
					$scope.getWebCaregoryData(filterVal, "Region");
					$scope.getProductGroupData(filterVal, "Region");
					$scope.getProductNameData(filterVal, "Region");
				}
			}
		}



		if (fieldName == "Country") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "Country") {
					$scope.getOffshoreOnshoreData(filterVal, "Country");
					$scope.getSurveyTypeData(filterVal, "Country");
					$scope.getActualSurveyStatusData(filterVal, "Country");
					$scope.getSurveyStatusData(filterVal, "Country");
					$scope.getSurveyNameData(filterVal, "Country");
					$scope.getProjectTypeData(filterVal, "Country");
					$scope.getProjectGroupNameData(filterVal, "Country");
					$scope.getProjectSubTypeData(filterVal, "Country");
					$scope.getProjectNameData(filterVal, "Country");
					$scope.getProductTypeData(filterVal, "Country");
					$scope.getProductDescriptionData(filterVal, "Country");
					$scope.getWebCaregoryData(filterVal, "Country");
					$scope.getProductGroupData(filterVal, "Country");
					$scope.getProductNameData(filterVal, "Country");
				}
			}
		}



		if (fieldName == "SurveyType") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "SurveyType") {
					$scope.getActualSurveyStatusData(filterVal, "SurveyType");
					$scope.getSurveyStatusData(filterVal, "SurveyType");
					$scope.getSurveyNameData(filterVal, "SurveyType");

					$scope.getProjectTypeData(filterVal, "SurveyType");
					$scope.getProjectGroupNameData(filterVal, "SurveyType");
					$scope.getProjectSubTypeData(filterVal, "SurveyType");
					$scope.getProjectNameData(filterVal, "SurveyType");

					$scope.getProductTypeData(filterVal, "SurveyType");
					$scope.getProductDescriptionData(filterVal, "SurveyType");
					$scope.getWebCaregoryData(filterVal, "SurveyType");
					$scope.getProductGroupData(filterVal, "SurveyType");
					$scope.getProductNameData(filterVal, "SurveyType");
				}
			}
		}
		if (fieldName == "ActualSurveyStatus") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ActualSurveyStatus") {
					$scope.getSurveyStatusData(filterVal, "ActualSurveyStatus");
					$scope.getSurveyNameData(filterVal, "ActualSurveyStatus");

					$scope.getProjectTypeData(filterVal, "ActualSurveyStatus");
					$scope.getProjectGroupNameData(filterVal, "ActualSurveyStatus");
					$scope.getProjectSubTypeData(filterVal, "ActualSurveyStatus");
					$scope.getProjectNameData(filterVal, "ActualSurveyStatus");

					$scope.getProductTypeData(filterVal, "ActualSurveyStatus");
					$scope.getProductDescriptionData(filterVal, "ActualSurveyStatus");
					$scope.getWebCaregoryData(filterVal, "ActualSurveyStatus");
					$scope.getProductGroupData(filterVal, "ActualSurveyStatus");
					$scope.getProductNameData(filterVal, "ActualSurveyStatus");
				}
			}
		}

		if (fieldName == "SurveyStatus") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "SurveyStatus") {
					$scope.getSurveyNameData(filterVal, "SurveyStatus");

					$scope.getProjectTypeData(filterVal, "SurveyStatus");
					$scope.getProjectGroupNameData(filterVal, "SurveyStatus");
					$scope.getProjectSubTypeData(filterVal, "SurveyStatus");
					$scope.getProjectNameData(filterVal, "SurveyStatus");

					$scope.getProductTypeData(filterVal, "SurveyStatus");
					$scope.getProductDescriptionData(filterVal, "SurveyStatus");
					$scope.getWebCaregoryData(filterVal, "SurveyStatus");
					$scope.getProductGroupData(filterVal, "SurveyStatus");
					$scope.getProductNameData(filterVal, "SurveyStatus");
				}
			}
		}

		if (fieldName == "SurveyName") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "SurveyName") {
					$scope.getProjectTypeData(filterVal, "SurveyName");
					$scope.getProjectGroupNameData(filterVal, "SurveyName");
					$scope.getProjectSubTypeData(filterVal, "SurveyName");
					$scope.getProjectNameData(filterVal, "SurveyName");

					$scope.getProductTypeData(filterVal, "SurveyName");
					$scope.getProductDescriptionData(filterVal, "SurveyName");
					$scope.getWebCaregoryData(filterVal, "SurveyName");
					$scope.getProductGroupData(filterVal, "SurveyName");
					$scope.getProductNameData(filterVal, "SurveyName");
				}
			}
		}

		if (fieldName == "ProjectType") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProjectType") {
					$scope.getProjectGroupNameData(filterVal, "ProjectType");
					$scope.getProjectSubTypeData(filterVal, "ProjectType");
					$scope.getProjectNameData(filterVal, "ProjectType");

					$scope.getProductTypeData(filterVal, "ProjectType");
					$scope.getProductDescriptionData(filterVal, "ProjectType");
					$scope.getWebCaregoryData(filterVal, "ProjectType");
					$scope.getProductGroupData(filterVal, "ProjectType");
					$scope.getProductNameData(filterVal, "ProjectType");
				}
			}
		}

		if (fieldName == "ProjectGroupName") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProjectGroupName") {
					$scope.getProjectSubTypeData(filterVal, "ProjectGroupName");
					$scope.getProjectNameData(filterVal, "ProjectGroupName");

					$scope.getProductTypeData(filterVal, "ProjectGroupName");
					$scope.getProductDescriptionData(filterVal, "ProjectGroupName");
					$scope.getWebCaregoryData(filterVal, "ProjectGroupName");
					$scope.getProductGroupData(filterVal, "ProjectGroupName");
					$scope.getProductNameData(filterVal, "ProjectGroupName");
				}
			}
		}

		if (fieldName == "ProjectSubType") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProjectSubType") {
					$scope.getProjectNameData(filterVal, "ProjectSubType");

					$scope.getProductTypeData(filterVal, "ProjectSubType");
					$scope.getProductDescriptionData(filterVal, "ProjectSubType");
					$scope.getWebCaregoryData(filterVal, "ProjectSubType");
					$scope.getProductGroupData(filterVal, "ProjectSubType");
					$scope.getProductNameData(filterVal, "ProjectSubType");
				}
			}
		}

		if (fieldName == "ProjectName") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProjectName") {
					$scope.getProductTypeData(filterVal, "ProjectName");
					$scope.getProductDescriptionData(filterVal, "ProjectName");
					$scope.getWebCaregoryData(filterVal, "ProjectName");
					$scope.getProductGroupData(filterVal, "ProjectName");
					$scope.getProductNameData(filterVal, "ProjectName");
				}
			}
		}

		if (fieldName == "ProductType") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProductType") {
					$scope.getProductDescriptionData(filterVal, "ProductType");
					$scope.getWebCaregoryData(filterVal, "ProductType");
					$scope.getProductGroupData(filterVal, "ProductType");
					$scope.getProductNameData(filterVal, "ProductType");
				}
			}
		}
		if (fieldName == "ProductDesc") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProductDesc") {
					$scope.getWebCaregoryData(filterVal, "ProductDesc");
					$scope.getProductGroupData(filterVal, "ProductDesc");
					$scope.getProductNameData(filterVal, "ProductDesc");
				}
			}
		}

		if (fieldName == "ProductWebCategory") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProductWebCategory") {
					$scope.getProductGroupData(filterVal, "ProductWebCategory");
					$scope.getProductNameData(filterVal, "ProductWebCategory");
				}
			}
		}

		if (fieldName == "ProductWebCategory") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProductWebCategory") {
					$scope.getProductGroupData(filterVal, "ProductWebCategory");
					$scope.getProductNameData(filterVal, "ProductWebCategory");
				}
			}
		}

		if (fieldName == "ProductGroup") {
			for (var i = 0; i < surveySelectedFieldDetails.length; i++) {
				if (!isfromApplFilter) {
					var fName = surveySelectedFieldDetails[i].fieldName;
					var filterVal = surveySelectedFieldDetails[i].fieldValue;
				}
				else {
					var fName = fieldName;
					var filterVal = selectedFields;
				}

				if (fName == "ProductGroup") {
					$scope.getProductNameData(filterVal, "ProductGroup");
				}
			}
		}
	}

	//Below function will get the Country details based on selected filterName
	$scope.getCountryData = function (filterValueList, filterName) {
		if (filterValueList == "") {			
			//Get Metadata post request object
			var request = Common.getSeismicPostRequest(source="Country",filterStr="","")				
			$http(request).
				then(function (response) {
					$scope.surveycountry = $scope.surveyfillData(response.data.resultList, "Country", "Country");

				}).catch(function (response) {					
				});
		}
		else {			
			//Get Metadata post request object
			var request = Common.getSeismicPostRequest(source="Country",filterStr=filterName + ":",filterValueList);
			$http(request).			
				then(function (response) {
					$scope.surveycountry = $scope.surveyfillData(response.data.resultList, "Country", "Country");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Onshore/Offshore details based on selected filterName
	$scope.getOffshoreOnshoreData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="Onshore",filterStr="","")				
			$http(request).			
				then(function (response) {
					$scope.surveyonshoreoffshore = $scope.OnshoreOffshore(response.data.resultList, "Onshore", "Onshore");
				}).catch(function (response) {					
				});
		}
		else {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="Onshore",filterStr=filterName + ":",filterValueList);
			$http(request).
				then(function (response) {
					$scope.surveyonshoreoffshore = $scope.OnshoreOffshore(response.data.resultList, "Onshore", "Onshore");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Survey Name details based on selected filterName
	$scope.getSurveyNameData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="SurveyName",filterStr="","")				
			$http(request).				
				then(function (response) {
					$scope.surveysname = $scope.surveyfillData(response.data.resultList, "SurveyName", "SurveyName");
				}).catch(function (response) {					
				});
		}
		else {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="SurveyName",filterStr=filterName + ":",filterValueList);
			$http(request).			
				then(function (response) {
					$scope.surveysname = $scope.surveyfillData(response.data.resultList, "SurveyName", "SurveyName");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Survey Type details based on selected filterName
	$scope.getSurveyTypeData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="SurveyType",filterStr="","")				
			$http(request).			
				then(function (response) {
					$scope.surveystype = $scope.surveyfillData(response.data.resultList, "SurveyType", "SurveyType");
				}).catch(function (response) {					
				});
		}
		else {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="SurveyType",filterStr=filterName + ":",filterValueList);
			$http(request).				
				then(function (response) {
					$scope.surveystype = $scope.surveyfillData(response.data.resultList, "SurveyType", "SurveyType");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Actual Survey Status details based on selected filterName
	$scope.getActualSurveyStatusData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="ActualSurveyStatus",filterStr="","")				
			$http(request).			
				then(function (response) {
					$scope.surveyactualsstatus = $scope.surveyfillData(response.data.resultList, "ActualSurveyStatus", "ActualSurveyStatus");
				}).catch(function (response) {					
				});
		}
		else {		
			//Get Metadata post request object	
			var request = Common.getSeismicPostRequest(source="ActualSurveyStatus",filterStr=filterName + ":",filterValueList);
			$http(request).			
				then(function (response) {
					$scope.surveyactualsstatus = $scope.surveyfillData(response.data.resultList, "ActualSurveyStatus", "ActualSurveyStatus");
				}).catch(function (response) {					
				});
		}

	}
	//Below function will get the Survey Status details based on selected filterName
	$scope.getSurveyStatusData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="SurveyStatus",filterStr="","")				
			$http(request).						
				then(function (response) {
					$scope.surveysstatus = $scope.surveyfillData(response.data.resultList, "SurveyStatus", "SurveyStatus");
				}).catch(function (response) {					
				});
		}
		else {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="SurveyStatus",filterStr=filterName + ":",filterValueList);
			$http(request).				
				then(function (response) {
					$scope.surveysstatus = $scope.surveyfillData(response.data.resultList, "SurveyStatus", "SurveyStatus");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Project Name details based on selected filterName
	$scope.getProjectNameData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="ProjectName",filterStr="","")				
			$http(request).				
				then(function (response) {
					$scope.surveyprojectname = $scope.surveyfillData(response.data.resultList, "ProjectName", "ProjectName");
				}).catch(function (response) {					
				});
		}
		else {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProjectName",filterStr=filterName + ":",filterValueList);
			$http(request).				
				then(function (response) {
					$scope.surveyprojectname = $scope.surveyfillData(response.data.resultList, "ProjectName", "ProjectName");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Project Type details based on selected filterName
	$scope.getProjectTypeData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="ProjectType",filterStr="","")				
			$http(request).				
				then(function (response) {
					$scope.surveyprojecttype = $scope.surveyfillData(response.data.resultList, "ProjectType", "ProjectType");
				}).catch(function (response) {					
				});
		}
		else {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="ProjectType",filterStr=filterName + ":",filterValueList);
			$http(request).				
				then(function (response) {
					$scope.surveyprojecttype = $scope.surveyfillData(response.data.resultList, "ProjectType", "ProjectType");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Project GroupName details based on selected filterName
	$scope.getProjectGroupNameData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="ProjectGroupName",filterStr="","")				
			$http(request).			
				then(function (response) {
					$scope.surveyprojectgroupname = $scope.surveyfillData(response.data.resultList, "ProjectGroupName", "ProjectGroupName");
				}).catch(function (response) {					
				});
		}
		else {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProjectGroupName",filterStr=filterName + ":",filterValueList);
			$http(request).			
				then(function (response) {
					$scope.surveyprojectgroupname = $scope.surveyfillData(response.data.resultList, "ProjectGroupName", "ProjectGroupName");
				}).catch(function (response) {
					
				});
		}
	}
	//Below function will get the Project SubType details based on selected filterName
	$scope.getProjectSubTypeData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="ProjectSubType",filterStr="","")				
			$http(request).			
				then(function (response) {
					$scope.surveyprojectsubtype = $scope.surveyfillData(response.data.resultList, "ProjectSubType", "ProjectSubType");
				}).catch(function (response) {					
				});
		}
		else {		
			//Get Metadata post request object	
			var request = Common.getSeismicPostRequest(source="ProjectSubType",filterStr=filterName + ":",filterValueList);
			$http(request).			
				then(function (response) {
					$scope.surveyprojectsubtype = $scope.surveyfillData(response.data.resultList, "ProjectSubType", "ProjectSubType");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Product Name details based on selected filterName
	$scope.getProductNameData = function (filterValueList, filterName) {
		if (filterValueList == "") {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProductName",filterStr="","")				
			$http(request).				
				then(function (response) {
					$scope.surveyproductname = $scope.surveyfillData(response.data.resultList, "ProductName", "ProductName");
				}).catch(function (response) {					
				});
		}
		else {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProductName",filterStr=filterName + ":",filterValueList);
			$http(request).				
				then(function (response) {
					$scope.surveyproductname = $scope.surveyfillData(response.data.resultList, "ProductName", "ProductName");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Product Type details based on selected filterName
	$scope.getProductTypeData = function (filterValueList, filterName) {
		if (filterValueList == "") {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProductType",filterStr="","")				
			$http(request).			
				then(function (response) {
					$scope.surveyproducttype = $scope.surveyfillData(response.data.resultList, "ProductType", "ProductType");
				}).catch(function (response) {					
				});
		}
		else {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProductType",filterStr=filterName + ":",filterValueList);
			$http(request).			
				then(function (response) {
					$scope.surveyproducttype = $scope.surveyfillData(response.data.resultList, "ProductType", "ProductType");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the Product Desc details based on selected filterName
	$scope.getProductDescriptionData = function (filterValueList, filterName) {
		if (filterValueList == "") {
			//Get Metadata post request object			
			var request = Common.getSeismicPostRequest(source="ProductDesc",filterStr="","")				
			$http(request).				
				then(function (response) {
					$scope.surveyproductdescription = $scope.surveyfillData(response.data.resultList, "ProductDesc", "ProductDesc");
				}).catch(function (response) {					
				});
		}
		else {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProductDesc",filterStr=filterName + ":",filterValueList);
			$http(request).				
				then(function (response) {
					$scope.surveyproductdescription = $scope.surveyfillData(response.data.resultList, "ProductDesc", "ProductDesc");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the WebCategory details based on selected filterName
	$scope.getWebCaregoryData = function (filterValueList, filterName) {
		if (filterValueList == "") {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProductWebCategory",filterStr="","")				
			$http(request).			
				then(function (response) {
					$scope.surveywebcaregory = $scope.surveyfillData(response.data.resultList, "ProductWebCategory", "ProductWebCategory");
				}).catch(function (response) {					
				});
		}
		else {		
			//Get Metadata post request object	
			var request = Common.getSeismicPostRequest(source="ProductWebCategory",filterStr=filterName + ":",filterValueList);
			$http(request).				
				then(function (response) {
					$scope.surveywebcaregory = $scope.surveyfillData(response.data.resultList, "ProductWebCategory", "ProductWebCategory");
				}).catch(function (response) {					
				});
		}
	}
	//Below function will get the ProductGroup details based on selected filterName
	$scope.getProductGroupData = function (filterValueList, filterName) {
		if (filterValueList == "") {	
			//Get Metadata post request object		
			var request = Common.getSeismicPostRequest(source="ProductGroup",filterStr="","")				
			$http(request).				
				then(function (response) {
					$scope.surveyproductgroup = $scope.surveyfillData(response.data.resultList, "ProductGroup", "ProductGroup");
				}).catch(function (response) {					
				});
		}
		else {		
			//Get Metadata post request object	
			var request = Common.getSeismicPostRequest(source="ProductGroup",filterStr=filterName + ":",filterValueList);
			$http(request).			
				then(function (response) {
					$scope.surveyproductgroup = $scope.surveyfillData(response.data.resultList, "ProductGroup", "ProductGroup");
				}).catch(function (response) {					
				});
		}
	}

	//Home Well Cascading - Onselect of well name load the Well Medadata values.
	$rootScope.surveyHometoDetailCascade = function (filterVal) {
		$scope.getProjectTypeData(filterVal, "SurveyName");
		$scope.getProjectGroupNameData(filterVal, "SurveyName");
		$scope.getProjectSubTypeData(filterVal, "SurveyName");
		$scope.getProjectNameData(filterVal, "SurveyName");

		$scope.getProductTypeData(filterVal, "SurveyName");
		$scope.getProductDescriptionData(filterVal, "SurveyName");
		$scope.getWebCaregoryData(filterVal, "SurveyName");
		$scope.getProductGroupData(filterVal, "SurveyName");
		$scope.getProductNameData(filterVal, "SurveyName");
	}

	// This function removes fields from array of selected fields.
	$rootScope.surveyremoveData = function (fieldName, fieldValue) {
		if ($rootScope.surveyselectedFieldsDetails.length > 0) {
			var flag = true;
			for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
				if ($rootScope.surveyselectedFieldsDetails[i].fieldName == fieldName) {
					var value = $rootScope.surveyselectedFieldsDetails[i].fieldValue;

					var arr = value.split(",");
					var strValue = "";
					var k = 0;

					for (var n = 0; n < arr.length; n++) {

						if (!(arr[n] == fieldValue)) {
							if (k > 0) {
								strValue = strValue + "," + arr[n];
							}
							else {
								strValue = arr[n];
							}
							k++;
						}
					}
					$rootScope.surveyselectedFieldsDetails[i].fieldValue = strValue;
					$rootScope.surveyselectedFieldsDetails[i].displayName = strValue;
				}
			}
		}
	}

	//Collects the selected Metadata Filter values
	$rootScope.surveycollectFilterData = function (fieldName, fieldValue, titleName) {
		var fval = fieldValue;		
			fieldValue = fieldValue.includes(',') ? fieldValue.replace(',', '~~') : fieldValue;

		if ($rootScope.surveyselectedFieldsDetails.length > 0) {
			var flag = true;


			for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
				if ($rootScope.surveyselectedFieldsDetails[i].fieldName == fieldName) {
					if ($rootScope.surveyselectedFieldsDetails[i].fieldValue != "") {

						if ($rootScope.surveyselectedFieldsDetails[i].fieldValue == "1" && fieldValue == "0") {
							$rootScope.surveyselectedFieldsDetails[i].fieldValue = $rootScope.surveyselectedFieldsDetails[i].fieldValue + "," + fieldValue;
							$rootScope.surveyselectedFieldsDetails[i].displayName = "OnShore" + "," + "OffShore";
						}
						else if ($rootScope.surveyselectedFieldsDetails[i].fieldValue == "0" && fieldValue == "1") {
							$rootScope.surveyselectedFieldsDetails[i].fieldValue = $rootScope.surveyselectedFieldsDetails[i].fieldValue + "," + fieldValue;
							$rootScope.surveyselectedFieldsDetails[i].displayName = "OnShore" + "," + "OffShore";
						}
						else {
							$rootScope.surveyselectedFieldsDetails[i].fieldValue = $rootScope.surveyselectedFieldsDetails[i].fieldValue + "," + fieldValue;
							$rootScope.surveyselectedFieldsDetails[i].displayName = $rootScope.surveyselectedFieldsDetails[i].displayName + "||" + fval; //fieldValue;
						}
					}
					else {
						$rootScope.surveyselectedFieldsDetails[i].fieldValue = fieldValue;
						$rootScope.surveyselectedFieldsDetails[i].displayName = fval; //fieldValue;
					}

					flag = false;
					break;
				}
			}
			if (flag) {
				var obj = new Object();
				if (fieldName == "Onshore") {
					if (fieldValue == "1")
						obj.displayName = "OnShore"
					else
						obj.displayName = "OffShore"

					obj.fieldName = fieldName;
					obj.fieldValue = fieldValue;

					obj.titleName = "Offshore / Onshore";
				}
				else {
					obj.fieldName = fieldName;
					obj.fieldValue = fieldValue;
					obj.titleName = titleName;
					obj.displayName = fval; //fieldValue;
				}
				$rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
			}
		}

		else {
			var obj = new Object();
			if (fieldValue == "1") {
				obj.displayName = "OnShore"
				obj.titleName = "Offshore / Onshore";
			}
			else if (fieldValue == "0") {
				obj.displayName = "OffShore"
				obj.titleName = "Offshore / Onshore";
			}
			else {
				obj.displayName = fval; //fieldValue;
				obj.titleName = titleName;
			}
			obj.fieldName = fieldName;
			obj.fieldValue = fieldValue;

			$rootScope.surveyselectedFieldsDetails[$rootScope.surveyselectedFieldsDetails.length] = obj;
		}
	}

	//Below function will collects the values of Text field and Date fields
	$rootScope.getSurveyDateVaues = function () {

		angular.element('.Seismicfltrgrp').find('.customeData').each(function () {
			var control = angular.element(this);

			for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
				var checkField = $rootScope.surveyselectedFieldsDetails[i];
				if (checkField.fieldValue !== "") {
					if(control[0].placeholder.includes('Date') && control.val()!==""){						
						var tempDateValueCheck = control.val().split('-');
						var dateValueCheck = tempDateValueCheck[0].split('/').join('-').trim() + " to " + tempDateValueCheck[1].split('/').join('-').trim();						
						if(dateValueCheck == checkField.fieldValue && checkField.fieldName == control[0].placeholder){
							$.alertable.alert("The filter '" + control[0].placeholder + " : " + control.val().trim() + "' is already applied.");
							return false;
						}
					}
					else if (checkField.fieldValue == control.val().trim() && checkField.fieldName == control[0].placeholder) {
						$.alertable.alert("The filter '" + control[0].placeholder + " : " + control.val().trim() + "' is already applied.");
						return false;
					}
				}
			}

			if (control.val().trim() !== "" && control.val().trim() !== null) {
				var obj = new Object();
				if (control[0].placeholder == "SurveyAcquisitionStartDate" || control[0].placeholder == "SurveyAcquisitionEndDate") {
					var tempDate = control.val().split('-');
					obj.fieldValue = tempDate[0].split('/').join('-').trim()+ " to " + tempDate[1].split('/').join('-').trim();
					obj.fieldName = control[0].placeholder;
					obj.titleName = control[0].placeholder;
					obj.displayName = obj.fieldValue;
				}

				$rootScope.surveyselectedFieldsDetails.push(obj);
			}

		});
	}

	//Below function will collects the Seismic Querybuilder data
	$rootScope.getQbSurveyData = function () {

		angular.element('.SurveyQBFieldSearch').each(function () {

			let qbSelectedSurveyValue = this.value;
			let titleName = this.name;
			let fieldName = this.id;
			//Checks the applied QB values and show duplicate popup message
			for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
				var checkField = $rootScope.surveyselectedFieldsDetails[i];
				if (checkField.fieldValue !== "") {
					if (checkField.fieldValue == qbSelectedSurveyValue.trim() && checkField.fieldName == titleName) {
						$.alertable.alert("The filter '" + fieldName + " : " + qbSelectedSurveyValue + "' is already applied.");
						return false;
					}
				}
			}

			if (qbSelectedSurveyValue !== "" && qbSelectedSurveyValue !== null && qbSelectedSurveyValue !== undefined) {
				var obj = new Object();

				obj.fieldName = fieldName;
				obj.fieldValue = qbSelectedSurveyValue;
				obj.titleName = titleName;
				obj.displayName = qbSelectedSurveyValue;

				$rootScope.surveycollectFilterData(obj.fieldName, obj.fieldValue, obj.titleName);
			}

		});


	}

	//Below function will form the Filter String to fetch the data.
	$rootScope.surveyformFilter = function () {
		if ($rootScope.filterNameGroup == "Seismic") {

			var SeismicfilterStr = "";
			$rootScope.surveyaplFilterData = [];
			$rootScope.surveyaplFilterTitle = [];

			for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
				if (i == 0) {
					if ($rootScope.surveyselectedFieldsDetails[i].fieldValue !== "" && $rootScope.surveyselectedFieldsDetails[i].fieldName !== "CustomerName"
						&& $rootScope.surveyselectedFieldsDetails[i].fieldName !== "WelltoSurveySwitch") {
						if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyAcquisitionStartDate" || $rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyAcquisitionEndDate"){
							var tempDate = $rootScope.surveyselectedFieldsDetails[i].fieldValue.split(' to ');
							var startTempDate = tempDate[0].trim();
							var endTempDate = tempDate[1].trim();
							SeismicfilterStr = $rootScope.surveyselectedFieldsDetails[i].fieldName + ":btw:" + startTempDate  + " 00:00:00.0<<" +  endTempDate  + " 00:00:00.0";
						}
						else
							SeismicfilterStr = $rootScope.surveyselectedFieldsDetails[i].fieldName + ":" + $rootScope.surveyselectedFieldsDetails[i].fieldValue;
					}
				}
				else {
					if ($rootScope.surveyselectedFieldsDetails[i] !== "" && $rootScope.surveyselectedFieldsDetails[i].fieldValue !== "" && $rootScope.surveyselectedFieldsDetails[i].fieldName !== "CustomerName"
						&& $rootScope.surveyselectedFieldsDetails[i].fieldName !== "WelltoSurveySwitch") {
						if (SeismicfilterStr == "") {
							if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyAcquisitionStartDate" || $rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyAcquisitionEndDate"){
								var tempDate = $rootScope.surveyselectedFieldsDetails[i].fieldValue.split(' to ');
								var startTempDate = tempDate[0].trim();
								var endTempDate = tempDate[1].trim();
								SeismicfilterStr = $rootScope.surveyselectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate  + " 00:00:00.0";
							}
							else
								SeismicfilterStr = $rootScope.surveyselectedFieldsDetails[i].fieldName + ":" + $rootScope.surveyselectedFieldsDetails[i].fieldValue;
						}
						else {
							if ($rootScope.surveyselectedFieldsDetails[i].fieldName !== "WelltoSurveySwitch") {
								if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyAcquisitionStartDate" || $rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyAcquisitionEndDate"){
									var tempDate = $rootScope.surveyselectedFieldsDetails[i].fieldValue.split(' to ');
									var startTempDate = tempDate[0].trim();
									var endTempDate = tempDate[1].trim();
									SeismicfilterStr = SeismicfilterStr + " AND " + $rootScope.surveyselectedFieldsDetails[i].fieldName + ":btw:" + startTempDate + " 00:00:00.0<<" + endTempDate + " 00:00:00.0";
								}
								else
									SeismicfilterStr = SeismicfilterStr + " AND " + $rootScope.surveyselectedFieldsDetails[i].fieldName + ":" + $rootScope.surveyselectedFieldsDetails[i].fieldValue;
							}
						}
					}
				}
				if ($rootScope.surveyselectedFieldsDetails[i].fieldValue !== "") {
					if ($rootScope.surveyselectedFieldsDetails[i].fieldName !== "CustomerName")
						$rootScope.surveyaplFilterData[$rootScope.surveyaplFilterData.length] = $rootScope.surveyselectedFieldsDetails[i].displayName;
					else
						$rootScope.surveyaplFilterData[$rootScope.surveyaplFilterData.length] = $rootScope.surveyselectedFieldsDetails[i].fieldValue;

					$rootScope.surveyaplFilterTitle[$rootScope.surveyaplFilterTitle.length] = $rootScope.surveyselectedFieldsDetails[i].titleName;
				}
			}
			$rootScope.Seismicfilterstring = SeismicfilterStr;

			if ($rootScope.Seismicfilterstring != "") {
				SurveyService.allSurveyFilter = SeismicfilterStr;

			}
			else {
				SurveyService.allSurveyFilter = $rootScope.Seismicfilterstring;

			}
		}
		else if ($rootScope.filterNameGroup == "Well") {
		}
	}

	//Below function will collects the Seismic QB values
	$rootScope.surveyformQueryBuilder = function () {

		var queryBuilderStr = "";
		$rootScope.seismicQBFilterArr = [];
		angular.element('.Seismicfltrdetgrp .QueryBuilder-container .QueryBuilder-condition').each(function () {

			var LHSVal = angular.element(this).find('select:nth-child(3) option:selected').val();
			var MHSVal = angular.element(this).find('select:nth-child(4) option:selected').val();

			if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typestring')) {
				var RHSVal = angular.element(this).find('.RHSSelect').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typedate')) {
				if(MHSVal == "btw"){
					var RHSVal = angular.element(this).find('.RHSDateRange').val();
					var tempDate = RHSVal.split('-');
					RHSVal = tempDate[0].split('/').join('-').trim()+ " to " + tempDate[1].split('/').join('-').trim();
								}
				else{
					var RHSVal = angular.element(this).find('.RHSFielddate').val();
				}				
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typesearch')) {
				var RHSVal = angular.element(this).find('.RHSFieldsearch').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typetxt')) {
				var RHSVal = angular.element(this).find('.RHSFieldname').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeflag')) {
				var RHSVal = angular.element(this).find('.RHSFlg').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeRange')) {
				if(MHSVal == "btw"){
					var RHSVal = angular.element(this).find('.RHSNumRange').val();
				}
				else{
					var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
				} 
			}
			else {
				var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
			}
			var allVall = LHSVal + ":" + MHSVal + ":" + RHSVal;

			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				$scope.surveytmArr.push(allVall)
			}
		});

		if ($scope.surveytmArr.length > 0) {
			queryBuilderStr = Common.getquerybuilderfilter($scope.surveytmArr); //Form querybuilder filter string
			$rootScope.seismicQBFilterArr = $scope.surveytmArr;
		}

		SurveyService.surveyQueryBuilder = queryBuilderStr;

		if ($scope.surveytmArr != null && $scope.surveytmArr.length > 0) {
			var obj = new Object();
			obj.value = $scope.surveytmArr;
			obj.title = "Query Builder Filter";
			obj.fgname = "surveyqb";
			obj.type = "qbfltr";
			$rootScope.surveyselectedValArr[$rootScope.surveyselectedValArr.length] = obj;
		}

	}

	//Below function will checks the duplicates in Querybuilder.
	$rootScope.checkSeismicQBDuplicateValue = function (seismicQBFilterArr) {
		var qbfieldArr = [];
		angular.element('.Seismicfltrdetgrp .QueryBuilder-container .QueryBuilder-condition').each(function () {

			var LHSVal = angular.element(this).find('select:nth-child(3) option:selected').val();
			var MHSVal = angular.element(this).find('select:nth-child(4) option:selected').val();

			if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typestring')) {
				var RHSVal = angular.element(this).find('.RHSSelect').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typedate')) {
				if(MHSVal == "btw"){
					var RHSVal = angular.element(this).find('.RHSDateRange').val();
					var tempDate = RHSVal.split('-');
					RHSVal = tempDate[0].split('/').join('-').trim()+ " to " + tempDate[1].split('/').join('-').trim();
				}
				else{
					var RHSVal = angular.element(this).find('.RHSFielddate').val();
				}
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typesearch')) {
				var RHSVal = angular.element(this).find('.RHSFieldsearch').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typetxt')) {
				var RHSVal = angular.element(this).find('.RHSFieldname').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeRange')) {
				var RHSVal = angular.element(this).find('.RHSNumRange').val();
			}
			else if (angular.element(this).find('select:nth-child(3) option:selected').hasClass('typeflag')) {
				var RHSVal = angular.element(this).find('.RHSFlg').val();
			}
			else {
				var RHSVal = angular.element(this).find('.RHSFieldtxt').val();
			}
			var allVall = LHSVal + ":" + MHSVal + ":" + RHSVal;

			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				qbfieldArr.push(allVall);

				if (qbfieldArr.length > 1) {
					for (var i = 0; i < qbfieldArr.length - 1; i++) {
						for (j = i + 1; j <= qbfieldArr.length; j++) {
							if (qbfieldArr[i] == qbfieldArr[j]) {
								$rootScope.isDuplicate = true;
								$.alertable.alert("Query builder Filter '" + qbfieldArr[i] + "' is selected morethan ones.");
								return false;
							}
						}
					}
				}
			}
			if (RHSVal !== undefined && RHSVal !== "" && RHSVal !== null && RHSVal !== "Select") {
				for (var f = 0; (seismicQBFilterArr !== undefined && f < seismicQBFilterArr.length); f++) {
					if (seismicQBFilterArr[f] == allVall) {
						$rootScope.isDuplicate = true;
						$.alertable.alert("Query builder Filter '" + allVall + "' is already exist in applied filter. Modify or remove the filter condition.");
						break;
					}
				}
			}
		});
	}

	$(function () {

		$('input[name="datefilter"]').daterangepicker({
			autoUpdateInput: false,
			showDropdowns:true,
			locale: {
				cancelLabel: 'Clear',
				 format: 'MM-DD-YYYY'
			}
		});

		$('input[name="datefilter"]').on('apply.daterangepicker', function (ev, picker) {
			$(this).val(picker.startDate.format('YYYY/MM/DD') + ' - ' + picker.endDate.format('YYYY/MM/DD'));			
		});

		$('input[name="datefilter"]').on('cancel.daterangepicker', function (ev, picker) {
			$(this).val('');
		});

	});
});