/*
File Name:- seismicSegyTabCtrl.js
Summary:- Fetch the SEGY details based on the filter string.
*/

angular.module('TGSApp').controller('seismicSegyTabCtrl', function ($scope, $location, $rootScope, $filter, $http, SurveyService, Common) {
    $scope.filteredsegyList = []
    $rootScope.filterNameGroup = "Seismic";
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    $rootScope.curTab = "SEGY";

    // This function fetches the SEGY data based on the current filter.
    $rootScope.seismicSegYtab = function () {
        if (!$rootScope.seismicSwitchFlag) {
            $scope.segData = [];
            $rootScope.curTab = "SEGY";
            $scope.sercnt += 1;
            if ($scope.sercnt <= 1) {
                angular.element(document).find('.loader').removeClass('hide');
                angular.element(document).find('.afterLoad').addClass('hide');
                angular.element(document).find('.nav.nav-tabs').find('.isTabDisable').removeClass('hide');
                // Apply loader on Map Container                
                angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
                angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

                var geoSpatialFilter = "";
                var LatLongGeoShapeFilter = "";

                // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
                if (window.drawPolygon) {
                    geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);
                    LatLongGeoShapeFilter = Common.getLatLongGeoShapeFilter();
                }

                // This below function will gets the Selected segy fields and frame the Filter string.
                var selectedFields = Common.getSegySelectedFields();

                // This below function will gets the UUid and frame the Filter string.
                var uuid = Common.getUuid();

                // This below function will gets the customer Id and frame the Filter string.
                var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();

                if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
                    surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
                }
                $scope.segData = [];
                
                setTimeout(function () {
                    $rootScope.applyProjectFilterByTab(SurveyService.allSurveyFilter, geoSpatialFilter,
                        SurveyService.surveyQueryBuilder, uuid, surveyEntitlementUrl, "", "");
                }, 1000); 

                //Get total record count
                setTimeout(function () {
                    var totalRecordsReq = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, LatLongGeoShapeFilter,
                        SurveyService.surveyQueryBuilder, selectedFields, uuid, surveyEntitlementUrl, "Seismic", "SEGY"
                        , "0", "", "", "", "",true)
                        
                    $http(totalRecordsReq)
                        .then(function (response) {
                            //$scope.segyCount = response.data.content[0].totalRecords;
                            $scope.segDatacount = response.data.content[0].totalRecords;
                            if ($scope.segDatacount < 10000) {
                                $scope.segYitemscount = $scope.segDatacount;
                            }
                            else {
                                $scope.segYitemscount = 10000;
                            }
                            angular.element(document).find('.loader').addClass('hide');
                            angular.element(document).find('.afterLoad').removeClass('hide');
                        });
                }, 2000);                

                // Calling http service request to get SEGY data                

                setTimeout(function () {
                    //Form the request object
                var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, LatLongGeoShapeFilter,
                    SurveyService.surveyQueryBuilder, selectedFields, uuid, surveyEntitlementUrl, "Seismic", "SEGY"
                    , "0", "", "", "", "",false)

                    $http(request).then(successCallback, errorCallback);
                }, 3000);                

                $scope.currentPage = 0;
                $scope.sercnt = 0;
            }
        }
    }

    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            for (var i = 0; i < response.data.content.length; i++) {
                $scope.segData.push({ data: response.data.content[i].compositeList});
            }
        }
        else {
            $scope.segData = [];
            $scope.segYitemscount = 0; //Assigning total elements count
            $scope.segDatacount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        // This below function will retain the selected settings from setting modal tab.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        // This below function will remove the loader from Map and Segy container.
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }

    var errorCallback = function (reason) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(reason);
    }


    //  This function will fetch the SEGY data on click of pager.
    $scope.Segypager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";
        var LatLongGeoShapeFilter = "";

        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon) {
            geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);
            LatLongGeoShapeFilter = Common.getLatLongGeoShapeFilter();
        }

        // This function will gets the Selected segy fields and frame the Filter string.
        var selectedFields = Common.getSegySelectedFields();

        // This function will gets the UUid and frame the Filter string.
        var uuid = Common.getUuid();

        // This function will gets the customer Id and frame the Filter string. 
        var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();

        if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
            surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
        }

        $scope.clickedpage = page - 1;
        $scope.segData = [];

        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');


        //Form the request object
        var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, LatLongGeoShapeFilter,
            SurveyService.surveyQueryBuilder, selectedFields, uuid, surveyEntitlementUrl, "Seismic",
            "SEGY", $scope.clickedpage, "", "", "", "", false)

        // Calling http service request to get SEGY data 
        $http(request).then(successCallback, errorCallback);

    }
    // This function will call only if user comes from home page
    if ($rootScope.callsegyfromhome) {
        $rootScope.appgname = "Seismic";
        // This function will call the Seismic SEGY function.
        $scope.seismicSegYtab();
    }
});


