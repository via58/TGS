/*
File Name:- seismicSpecSheetTabCtrl.js
Summary:- Fetch the SpecSheet details based on the filter string.
*/

angular.module('TGSApp').controller('seismicSpecSheetTabCtrl', function ($scope, $rootScope, $http, SurveyService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;
    $scope.searchspecsheettext = "";
    var searchspecsheetUrl = "";

    // This function will make search text empty in specsheet tab.
    $rootScope.emptySearchField = function () {
        $scope.searchspecsheettext = "";
    }
    // This function fetches the SpecSheet data based on the current filter.
    $rootScope.seismicSpecSheettab = function () {
        $rootScope.curTab = "Spec Sheets";
        $scope.sercnt += 1;
        $scope.Specsheetitems = [];
        if ($scope.sercnt == 1) {
            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";

            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);

            // This function will gets the Selected Specsheet fields and frame the Filter string.
            var selectedSpecFields = Common.getSpecSheetSelectedFields();
            if ($scope.searchspecsheettext !== "") {
                if (selectedSpecFields !== "") {
                    selectedSpecFields = selectedSpecFields + "," + "PageNumber";

                    // This function will gets the specsheet filter text and frame the Filter string.
                    searchspecsheetUrl = Common.getSpecpdfFilterUrl($scope.searchspecsheettext);
                } else {
                    selectedSpecFields = "PageNumber";
                    searchspecsheetUrl = Common.getSpecpdfFilterUrl($scope.searchspecsheettext);
                }
            } else {
                searchspecsheetUrl = Common.getSpecpdfFilterUrl("");
            }
            // This function will gets the UUid and frame the Filter string.
            var uuid = Common.getUuid();

            // This function will gets the customer Id and frame the Filter string.
            var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();
            if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
                surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
            }

            $scope.Specsheetitems = [];

            // This function will load project shapes in Map with respect to current filter string.
            $rootScope.applyProjectFilterByTab(SurveyService.allSurveyFilter, geoSpatialFilter, SurveyService.surveyQueryBuilder,
                uuid, surveyEntitlementUrl, "", searchspecsheetUrl);

            //Form the request object
            var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
                SurveyService.surveyQueryBuilder, selectedSpecFields, uuid, surveyEntitlementUrl, "Seismic", "SpecSheet"
                , "0", "20", "", "", searchspecsheetUrl)
            // Calling http service request to get Specsheet data 
            $http(request).then(successCallback, errorCallback);
            $scope.sercnt = 0;
            $scope.currentPage = 0;
        }

    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.Specsheetcount = response.data.totalElements;
            for (var i = 0; i < response.data.content.length; i++) {
                $scope.Specsheetitems.push({ fileName: response.data.content[i].parentValue, data: response.data.content[i].list });
            }

            if (response.data.totalElements < 10000) {
                $scope.SpecsheetPagesCount = response.data.totalElements;   //Assigning total elements count
            }
            else {
                $scope.SpecsheetPagesCount = 10000;
            }
        }
        else {
            $scope.Specsheetitems = [];
            $scope.SpecsheetPagesCount = 0;
            $scope.Specsheetcount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }
        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
            if ($scope.searchspecsheettext !== "") {
                angular.element(document.body).find('.fldgrp-set').addClass('filtergrpclick');
            }
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    // This function will catch the error .
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }

    //  This function will fetch the Specsheet data on click of pager.
    $rootScope.Specsheetpager = function (custommsg, page, pageSize, total) {

        var geoSpatialFilter = "";
        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getGeoSpatialFilter(SurveyService.allSurveyFilter);
        // This function will gets the Selected segy fields and frame the Filter string.
        var selectedSpecFields = Common.getSpecSheetSelectedFields();
        if ($scope.searchspecsheettext !== "") {
            if (selectedSpecFields !== "") {
                selectedSpecFields = selectedSpecFields + "," + "PageNumber";
                searchspecsheetUrl = Common.getSpecpdfFilterUrl($scope.searchspecsheettext);
            } else {
                selectedSpecFields = "PageNumber";
                searchspecsheetUrl = Common.getSpecpdfFilterUrl($scope.searchspecsheettext);
            }
        } else {
            searchspecsheetUrl = Common.getSpecpdfFilterUrl("");
        }

        // This function will gets the UUid and frame the Filter string.
        var uuid = Common.getUuid();

        // This function will gets the customer Id and frame the Filter string.
        var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();
        if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
            surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
        }
        $scope.Specsheetitems = [];

        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
        $scope.clickedpage = page - 1;        

        //Form the request object
        var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
            SurveyService.surveyQueryBuilder, selectedSpecFields, uuid, surveyEntitlementUrl, "Seismic", "SpecSheet"
            , $scope.clickedpage, "20", "", "", searchspecsheetUrl)

        // Calling http service request to get Specsheet data 
        $http(request).then(successCallback, errorCallback);

    }

    //This function calls seismicSpecSheettab method when user hit "Enter" key after entering text search 
    document.getElementById("specSearchTextBox").addEventListener("keyup", function (event) {
        if ($scope.searchspecsheettext !== "") {
            if (event.keyCode === 13) {
                $rootScope.seismicSpecSheettab();
            }
        }
    });

    $scope.freeTextSpechSheet = function () {
        if ($scope.searchspecsheettext !== "") {
            $rootScope.seismicSpecSheettab();

        }
    }
    //This function displays the Snippet text when user clicks inside specsheet file.
    $scope.showSnippetOnDivClick = function (number, specfilename, source) {

        if ($scope.searchspecsheettext !== "") {
            if (source == "div") {                
                var seismicSpecSheettaburl = "getSnippetInfo";
                var snippetInfo = {
                    module: "Seismic",
                    tabName: "SpecSheet",
                    pdfFileName: specfilename,
                    pdfPageNumber: number,
                    pdfFilterStr: $scope.searchspecsheettext,
                    requestTimestamp : Common.getCurrentDateTime(),
                    token: $rootScope.sessionToken,
                    access_token: $rootScope.accessToken
                }
                snippetInfo.token == "" ? delete snippetInfo.token : snippetInfo.token;
                snippetInfo.access_token == "" ? delete snippetInfo.access_token : snippetInfo.access_token;

                var snippetInfoList = $.param(snippetInfo);  // For Serialization and  encodeURIComponent
                var request = {
                    method: 'POST',
                    url: Common.urlValue + seismicSpecSheettaburl,
                    data: snippetInfoList,
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
                }

                // Calling http service request to get SpecSheet snippet text data
                $http(request).                    
                    then(function (response) {
                        if (response.data.content.length > 0) {
                            if (response.data.content[0].list.OcrText.length > 1) {
                                temp = response.data.content[0].list.OcrText;
                                temp.forEach(element => {
                                    responseText += "<li>" + element + "</li>";
                                });
                            }
                            else {
                                responseText = "<li>" + response.data.content[0].list.OcrText[0] + "</li>";
                            }
                        }
                        else {
                            responseText = "Not found";
                        }
                        //Displays the snippet text inside the specsheet file
                        angular.element(document.body).find('[label-snippet="' + specfilename + '"]').html(responseText);
                        angular.element(document.body).find('[data-column-val="' + specfilename + '"]').removeClass('hide');
                        setTimeout(function () {
                            //Highlights the search text in the text snippet list
                            angular.element('[label-snippet]').find('em').css('background', 'yellow');
                        })
                    });
            }

        }
    }
    //This function  displays the Snippet text when user clicks page number inside specsheet file.
    $scope.showSnippetOnPageClick = function (number, specfilename, source, $event) {
        if (source == "page") {
            var seismicSpecSheettaburl = "getSnippetInfo";            
            var responseText = "";

            var snippetInfo = {
                module: "Seismic",
                tabName: "SpecSheet",
                pdfFileName: specfilename,
                pdfPageNumber: number,
                pdfFilterStr: $scope.searchspecsheettext,
                requestTimestamp : Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }
            snippetInfo.token == "" ? delete snippetInfo.token : snippetInfo.token;
            snippetInfo.access_token == "" ? delete snippetInfo.access_token : snippetInfo.access_token;

            var snippetInfoList = $.param(snippetInfo);  // For Serialization and  encodeURIComponent
            var request = {
                method: 'POST',
                url: Common.urlValue + seismicSpecSheettaburl,
                data: snippetInfoList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }
            $http(request).
                // $http.get(SurveyService.urlValue + seismicSpecSheettaburl + pdfFileName + pdfPageNumber + pdfFilterUrl).
                then(function (response) {
                    if (response.data.content.length > 0) {
                        if (response.data.content[0].list.OcrText.length > 1) {
                            temp = response.data.content[0].list.OcrText;
                            temp.forEach(element => {
                                responseText += "<li>" + element + "</li>";
                            });
                        }
                        else {
                            responseText = "<li>" + response.data.content[0].list.OcrText[0] + "</li>";
                        }
                    }
                    else {
                        responseText = "Not found";
                    }
                    angular.element(document.body).find('[label-snippet="' + specfilename + '"]').html(responseText);
                    angular.element(document.body).find('[data-column-val="' + specfilename + '"]').removeClass('hide');
                    setTimeout(function () {
                        angular.element('[label-snippet]').find('em').css('background', 'yellow');
                    })

                });
        }
        $event.stopPropagation();
    }
}); 