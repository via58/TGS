angular.module('TGSApp').controller("SEGYCutSummaryModalController", function ($scope,$uibModal, $uibModalInstance, args) {

    var response = args.responseData;
    console.log(response);
    $scope.fileCount = response[0].length;    
    $scope.productsList = response[1];

    $scope.confirm = function () {
        $uibModalInstance.close('close');
        $scope.modalInstance = $uibModal.open({
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            templateUrl: 'partials/seismic/SEGYCutSuccessModal.html',
            controller: 'SEGYCutSuccessModalController',           
            size: 'lg',
        });
    }

    $scope.closeModel = function (e) {
        $uibModalInstance.close('close');
    }    
});