angular.module('TGSApp').controller("SEGYCutModalController", function ($scope,$uibModal, $uibModalInstance, args, SEGYCUTService) {

    //$scope.SEGYCutData = SEGYCUTService.SEGYCutData;
    //$scope.projectNames = SEGYCUTService.projectNames;

    //$scope.datalist = args.responseData;
    console.log(args.responseData);
    
    $scope.SEGYFileList = args.responseData[0];
    $scope.SEGYProductList = args.responseData[1];
    var response = [];
    response.push($scope.SEGYFileList);
    response.push($scope.SEGYProductList);

    $scope.checkAllselect = function (e) {
        console.log(e)
        if (e.target.checked == true) {
            // alert(1);
            angular.element('.selectchildchk').attr('checked', 'checked');
        }
        else {
            // alert(2);
            angular.element('.selectchildchk').attr('checked', false);
        }
    }

    $scope.export = function () {
        $uibModalInstance.close('close');
        $scope.modalInstance = $uibModal.open({
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            templateUrl: 'partials/seismic/SEGYCutSummaryModal.html',
            controller: 'SEGYCutSummaryModalController',            
            size: 'lg',
            resolve: {
                "args": function () {
                    return {
                        responseData: response
                    }
                }

            }
        });
    }

    $scope.closeModel = function (e) {
        $uibModalInstance.close('close');
    }    
});