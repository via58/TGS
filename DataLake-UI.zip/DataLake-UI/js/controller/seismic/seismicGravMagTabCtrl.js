/*
File Name:- seismicGravMagTabCtrl.js
Summary:- Fetch the GravMag details based on the filter string.
*/

angular.module('TGSApp').controller('seismicGravMagTabCtrl', function ($scope, $location, $rootScope, $filter, $http, SurveyService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;

    // This function fetches the GravMag data based on the current filter.
    $rootScope.seismicGravMagtab = function () {
        $scope.GravMagitems = [];
        $rootScope.curTab = "GravMag";
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
            var geoSpatialFilter = "";

            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

            // This function will gets the Selected GravMag fields and frame the Filter string.
            var selectedFieldsurl = Common.getGravMagSelectedFields();

            // This function will gets the UUid and frame the Filter string.
            var uuid = Common.getUuid();

            // This function will gets the customer Id and frame the Filter string.
            var surveyEntitlementUrl = Common.getSurveyGravMagEntitlementUrl();

            if (surveyEntitlementUrl == "" && $rootScope.gravMagEntitlementUrl) {
                if ($rootScope.GravMagSurveyType == "3D") {
                    surveyEntitlementUrl = Common.getAdminGravMagEntUrl();
                }
                else {
                    surveyEntitlementUrl = $rootScope.gravMagEntitlementUrl;
                }
            }
            //set default SurveyType to 2D for admin role
            if (surveyEntitlementUrl !== "" && ($rootScope.GravMagSurveyType == undefined || $rootScope.GravMagSurveyType == "")) {
                $rootScope.GravMagSurveyType = "2D";
            }

            //  Set GravMag survey type based on condition   
            if (surveyEntitlementUrl !== "" && $rootScope.filterSurveyType == "3D") {
                angular.element('.GravmagEntitle').find('.btn-group').find('label').removeClass('active');
                angular.element('.GravmagEntitle').find('.btn-group').find('label:last').addClass('active');
                $rootScope.GravMagSurveyType = "3D";
            }
            if (surveyEntitlementUrl !== "" && $rootScope.filterSurveyType == "2D") {
                angular.element('.GravmagEntitle').find('.btn-group').find('label').removeClass('active');
                angular.element('.GravmagEntitle').find('.btn-group').find('label:first').addClass('active');
                $rootScope.GravMagSurveyType = "2D";
            }
            // This function will load project shapes in Map with respect to current filter string.
            $rootScope.applyProjectFilterByTab(SurveyService.allSurveyFilter, geoSpatialFilter,
                SurveyService.surveyQueryBuilder, uuid, surveyEntitlementUrl, $rootScope.GravMagSurveyType, "");

            //Form the request object
            var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
                SurveyService.surveyQueryBuilder, selectedFieldsurl, uuid, surveyEntitlementUrl, "Seismic",
                "GravMag", "0", "", "", $rootScope.GravMagSurveyType, "")

            // Calling http service request to get GravMag data 
            $http(request).then(successCallback, errorCallback);
            $scope.sercnt = 0;
            $scope.currentPage = 0;
        }

    }
    // Calling http service request to get GravMag data 
    var successCallback = function (response) {        
        if (response.data != "" && response.data.content.length > 0) {            
            if(response.data.number == 0){
                $scope.GravMagCount = response.data.content[0].totalRecords;
                }
            for (var i = 0; i < response.data.content.length; i++) {
                $scope.GravMagitems.push({ data: response.data.content[i].compositeList });
            }
            if (response.data.totalElements < 10000) {
                $scope.GravMagPagesCount = $scope.GravMagCount;        //Assigning total elements count    
            }
            else {
                $scope.GravMagPagesCount = 10000;
            }            
        }
        else {
            $scope.GravMagitems = [];
            $scope.GravMagPagesCount = 0;
            $scope.GravMagCount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        //Below function will fetch the additional selected fields if any.
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();       
    }
    // This function will catch the error .
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }
    //  This function will fetch the GravMag data on click of pager.
    $rootScope.GravMagpager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";

        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

        // This function will gets the Selected GravMag fields and frame the Filter string.
        var selectedFieldsurl = Common.getGravMagSelectedFields();

        // This function will gets the UUid and frame the Filter string.
        var uuid = Common.getUuid();

        // This function will gets the customer Id and frame the Filter string.
        var surveyEntitlementUrl = Common.getSurveyGravMagEntitlementUrl();

        if (surveyEntitlementUrl == "" && $rootScope.gravMagEntitlementUrl) {
            if ($rootScope.GravMagSurveyType == "3D") {
                surveyEntitlementUrl = Common.getAdminGravMagEntUrl();
            }
            else {
                surveyEntitlementUrl = $rootScope.gravMagEntitlementUrl;
            }
        }

        $scope.GravMagitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
        $scope.clickedpage = page - 1;

        //Form the request object
        var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
            SurveyService.surveyQueryBuilder, selectedFieldsurl, uuid, surveyEntitlementUrl, "Seismic",
            "GravMag", $scope.clickedpage, "", "", $rootScope.GravMagSurveyType, "")

        // Calling http service request to get GravMag data 
        $http(request).then(successCallback, errorCallback);
    }
    // This function will filter the data based on GravMag survey type 
    angular.element(document).on('click', '.GravmagEntitle .btn-group label', function () {
        $rootScope.GravMagSurveyType = angular.element(this).text();
        var surveyTypeExist = false;
        if ($rootScope.GravMagSurveyType == "3D") {

            if ($rootScope.surveyselectedValArr.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                    var QBObj = $rootScope.surveyselectedValArr[i].value;
                    for (var j = 0; j < QBObj.length; j++) {
                        if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                            || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                            surveyTypeExist = true;
                            $rootScope.GravMagSurveyType = QBObj[j].substring(QBObj[j].length - 2);
                            $.alertable.alert("SurveyType = 2D is already applied. Remove SurveyType = 2D filter to view the 3D data.");
                            return false;
                        }
                    }
                }
            }

            if ($rootScope.surveyselectedFieldsDetails.length > 0 && !surveyTypeExist) {
                for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                    if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType"
                        && $rootScope.surveyselectedFieldsDetails[i].fieldValue == "2D") {
                        surveyTypeExist = true;
                        $rootScope.GravMagSurveyType = "2D";
                        $.alertable.alert("SurveyType = 2D is already applied. Remove SurveyType = 2D filter to view the 3D data.");
                        return false;
                    }
                }
            }
            else {
                //$rootScope.seismicGravMagtab();
            }
            if (!surveyTypeExist)
                $rootScope.seismicGravMagtab();
        }

        else if ($rootScope.GravMagSurveyType == "2D") {
            if ($rootScope.surveyselectedValArr.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                    var QBObj = $rootScope.surveyselectedValArr[i].value;
                    for (var j = 0; j < QBObj.length; j++) {
                        if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                            || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                            surveyTypeExist = true;
                            $rootScope.GravMagSurveyType = QBObj[j].substring(QBObj[j].length - 2);
                            $.alertable.alert("SurveyType = 3D is already applied. Remove SurveyType = 3D filter to view the 2D data.");
                            return false;
                        }
                    }
                }
            }

            if ($rootScope.surveyselectedFieldsDetails.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                    if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType"
                        && $rootScope.surveyselectedFieldsDetails[i].fieldValue == "3D") {
                        surveyTypeExist = true;
                        $rootScope.GravMagSurveyType = "3D";
                        $.alertable.alert("SurveyType = 3D is already applied. Remove SurveyType = 3D filter to view the 2D data.");
                        return false;
                    }
                }
            }
            else {
                $rootScope.seismicGravMagtab();
            }
            if (!surveyTypeExist)
                $rootScope.seismicGravMagtab();
        }
    });
});
