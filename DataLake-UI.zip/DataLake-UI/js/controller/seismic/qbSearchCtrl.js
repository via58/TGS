/*
File Name:- qbSearchCtrl.js
Summary:- Fetch the distinct Field values for selected field name in Query Builder.
*/

angular.module('TGSApp').controller('qbSearchCtrl', function ($scope, $location, $rootScope, WellService, SurveyService, $http, $sce, limitToFilter, Common) {
    $scope.selected = undefined; 

    $scope.getSeismicQBValues = function (title) {      
      if (title.length >= 2) {
        $scope.result1 = [];
        
        var mdlname = $rootScope.filterNameGroup;
        if(mdlname == "Seismic"){
          var lhsName =  $rootScope.qblhsval;
        }
        else{
          var lhsName =  $rootScope.qblhsval;
        }

      var serviceUrl = "getSearchFieldName"

      var paramInfo = {
        source: lhsName,
        module: mdlname,
        searchStr: title,
        requestTimestamp : Common.getCurrentDateTime(),
        token: $rootScope.sessionToken,
        access_token: $rootScope.accessToken
      }

      paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

      var paramInfoList = $.param(paramInfo);

      var request = {
        method: 'POST',
        url: SurveyService.urlValue + serviceUrl,
        data: paramInfoList,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded'}
      }        
        return $http(request)
          .then(function (response) {            
            var lhsName =  $rootScope.qblhsval;
            var datastr = response.data[lhsName];            
            if (response.data !== undefined) {
              angular.forEach(datastr, function (value) {
                $scope.result1.push({ "displayText": value });                
              });
            }                        
            return limitToFilter($scope.result1, 500);
          });
      }
    };
  //Below function will fetch the distinct values for the given search text
  $scope.qbSeismicFiltername = function (title, fieldname) {

 $scope.selectedsurveyprojectname = [];
  $scope.selectedsurveyproductname = [];
    if (title.length > 1) {    
      var mdlname = $rootScope.filterNameGroup;

      var serviceUrl = "getSearchFieldName"

      var paramInfo = {
        source: fieldname,
        module: mdlname,
        searchStr: title,
        requestTimestamp : Common.getCurrentDateTime(),
        token: $rootScope.sessionToken,
        access_token: $rootScope.accessToken
      }

      paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
      paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

      var paramInfoList = $.param(paramInfo);

      var request = {
        method: 'POST',
        url: SurveyService.urlValue + serviceUrl,
        data: paramInfoList,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      }         
      return $http(request)
        .then(function (response) {          
          var datastr = response.data[fieldname];          
          switch (fieldname) {
            case "ProductName":
              if (response.data !== undefined) {
                angular.forEach(datastr, function (value) {
                  $scope.selectedsurveyproductname.push({ "displayText": value });
                });                
                return limitToFilter($scope.selectedsurveyproductname,25);
              }
              break;
            case "ProjectName":
              if (response.data !== undefined) {
                angular.forEach(datastr, function (value) {
                  $scope.selectedsurveyprojectname.push({ "displayText": value });
                });                
                return limitToFilter($scope.selectedsurveyprojectname, 25);
              }
              break;
          }
        });
    }
  }
  
});
