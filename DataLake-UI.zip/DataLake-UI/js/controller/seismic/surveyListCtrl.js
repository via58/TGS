/*
File Name:- surveyListCtrl.js
Summary:- Fetch the Survey List details based on the filter string.
*/

angular.module('TGSApp').controller('surveyListCtrl', function ($scope, $http, $rootScope, $uibModal, SurveyService, Common, Constants) {
    window.mapSurveyname = [];
    window.mapallSurveyname = [];
    $scope.filteredSurveyNameList = [], $scope.currentPage = 2, $scope.numPerPage = 12;
    $scope.surveyNameListCount = "";
    $scope.count = 0;

    //Survey Summary panel fields    
    $rootScope.surveyMapPanelshow = false;
    $rootScope.surveyPaneldiv = "surveySummaryPanel";
    $scope.surveyGlifIconLeft = "glyphicon glyphicon-chevron-left";
    $scope.surveyGlifIconRight = "glyphicon glyphicon-chevron-right";
    $rootScope.surveyPanelicon = "glyphicon glyphicon-chevron-left";
    $scope.surveyPanelOpen = false;
    $scope.surveyInfoIcon = "glyphicon glyphicon-chevron-down";
    $scope.surveyInfoOpen = false;

    // Fetch the Survey List details based on the filter string.
    $rootScope.loadSurveyDetails = function () {
        window.mapallSurveyname = [];
        window.mapSurveyname = [];
        $scope.count += 1;
        if ($scope.count == 1) {
            var geoSpatialFilter = "";
            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
            if (window.drawPolygon)
                geoSpatialFilter = Common.getSurveyGeoShape(SurveyService.allSurveyFilter);
            // This below function will gets the customer Id and frame the Filter string.
            var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();
            if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
                surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
            }

            $scope.surveyNameList = [];

            var filterStringInfo = "";
            if (SurveyService.allSurveyFilter !== "" && geoSpatialFilter == "")
                filterStringInfo = SurveyService.allSurveyFilter
            else if (SurveyService.allSurveyFilter == "" && geoSpatialFilter !== "") {
                filterStringInfo = geoSpatialFilter;
            }
            else if (geoSpatialFilter !== "" && SurveyService.allSurveyFilter !== "")
                filterStringInfo = SurveyService.allSurveyFilter + geoSpatialFilter;

            var paramInfo = {
                source: "SurveyName",
                size: 1000,
                filterStr: filterStringInfo,     //Having metadata filter and geoSpatial Filter
                customerId: surveyEntitlementUrl,
                requestTimestamp: Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }
            
            paramInfo.customerId == "" ? delete paramInfo.customerId : paramInfo.customerId = surveyEntitlementUrl;
            paramInfo.filterStr == "" ? delete paramInfo.filterStr : paramInfo.filterStr = filterStringInfo;
            paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
            paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;


            var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent

            var request = {
                method: 'POST',
                url: SurveyService.urlValue + SurveyService.allSurveyInfoService,
                data: paramInfoList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }

            }
            //var currentTime = Common.getCurrentTime();        
            // Calling http service request to get Survey data 
            $http(request)
                .then(function (response) {
                    //creating log request
                    // var logReq = Common.createUILog("surveyListCtrl","loadSurveyDetails","getSurveyNameFilter",$rootScope.userRole
                    //              ,"Success",SurveyService.allSurveyFilter,"",geoSpatialFilter,surveyEntitlementUrl,Common.getCurrentDateTime(),
                    //              Common.getTimeDifferenceInSeconds(currentTime,Common.getCurrentTime()),"");

                    // console.log(logReq);
                    //$http(logReq); //Logging the success request
                    
                    $scope.surveyData = response.data
                    $scope.surveyDatacount = $scope.surveyData.length;
                    for (i = 0; i < $scope.surveyData.length; i++) {
                        $scope.surveyNameList.push({ text: $scope.surveyData[i].surveyName, sid: $scope.surveyData[i].surveyID });
                        window.mapallSurveyname.push($scope.surveyData[i].surveyID);
                    }
                    $scope.surveyNameListCount = $scope.surveyNameList.length;
                    $scope.currentPage = 0;
                    var toggleTxt = angular.element(document).find('.tools-section').find('.btn-group').find('label.active').text()

                    $rootScope.$broadcast("event:applySeismicFilters", { SurveyNames: window.mapallSurveyname, selectedTab: toggleTxt });
                    $scope.count = 0;
                    $scope.$watch('currentPage + numPerPage', function () {
                        var begin = (($scope.currentPage - 1) * $scope.numPerPage), end = begin + $scope.numPerPage;
                        $scope.filteredSurveyNameList = $scope.surveyNameList.slice(begin, end);
                        window.mapSurveyname = $scope.filteredSurveyNameList;
                    });

                }).catch(function (error) {
                    $scope.count = 0;
                    //var logReq = Common.createUILog("surveyListCtrl","loadSurveyDetails","getSurveyNameFilter",$rootScope.userRole,"Failed",
                    //               SurveyService.allSurveyFilter,"",geoSpatialFilter,surveyEntitlementUrl,Common.getCurrentDateTime(),
                    //               Common.getTimeDifferenceInSeconds(currentTime,Common.getCurrentTime()),error.data);                

                    //$http(logReq); //Logging the success request

                });
        }
    };
    setTimeout(function () {
        $rootScope.loadSurveyDetails();
    }, 700)
    // If polygon drawn, Filter the Survey List details based on the polygon shape.
    $rootScope.$on("event:surveyPolygonDraw", function (event, data) {

        $rootScope.surveyaplFilterData = [];
        $rootScope.surveyaplFilterTitle = [];
        $rootScope.loadSurveyDetails();
    });

    setTimeout(function () {
        angular.element(document).find('.survey-list-details').find('.pagination li:nth-child(4) a').click();
        angular.element(document).find('.survey-list-details').find('.pagination li:nth-child(3) a').click();
    }, 500)
    
    //Survey Summary Paneel changes - Start

    // Function for mousehover on survey tile
    $scope.highlightSurveyArea = function (surveyId) {
        // $rootScope.highlightSurvey();     
        $rootScope.highlightSurvey(surveyId);        
    }

    // Function for mouse leave on survey tile
    $scope.resetSurveyArea = function () {
        $rootScope.resetHighlightedSurvey();
    }


    // This function opens the Survey Summary Side panel
    $scope.showSurveySummaryPanel = function (obj, survey) {
        //angular.element(document).find('.surveyDetailDiv').hide();
        if (angular.element(obj.currentTarget).hasClass('survey-tile-active')) {
            angular.element(obj.currentTarget).removeClass('survey-tile-active');
            angular.element('.surveySummaryPanel').hide(); //Hides Survey Summary panel
            if ($rootScope.IPselectedValArr.length == 0 && $rootScope.selectedValArr.length == 0 && $rootScope.surveyselectedValArr.length == 0 && !window.drawPolygon) {
                $rootScope.$broadcast("event:zoomToSurvey", {});
            }
            return false;
        }
        else {
            angular.element('.survey-tile').removeClass('survey-tile-active');
            angular.element(obj.currentTarget).addClass('survey-tile-active');
        }
        angular.element(document).find('.surveySummaryPanel').show();
        angular.element(document).find('.surveyListDetailDiv').hide();
        angular.element(document).find('.single-survey-info').show();

        $rootScope.loadingData = false;
        $rootScope.datalist = "";

        window.surveytiletxt = "";
        var surveyTitle = survey.text;
        var surveyid = survey.sid;
        window.surveytiletxt = surveyid;
        $scope.surveyName = survey.text;
        var surveyIDArray = [];
        surveyIDArray[0] = surveyid;
        $rootScope.$broadcast("event:zoomToSurvey", { surveyID: surveyIDArray });

        //Get Survey Summary Request
        var request = Common.getSurveySummaryRequest(surveyTitle);

        $http(request)
            .then(function (response) {
                $rootScope.loadingData = true;
                $scope.result = [];
                $rootScope.namelist = survey.text;
                $rootScope.datalist = response.data;
                $rootScope.surveyMapPanelshow = true;
                $rootScope.surveyPaneldiv = "surveySummaryPanel";
                $rootScope.surveyPanelicon = $scope.surveyGlifIconLeft;
                angular.element('.surveySidepanelbtn').css('display', 'block')
                angular.element(document.body).find('.mapoverlay').remove();
                $scope.surveyPanelOpen = true;
            }).catch(function (response) {
                Common.redirectToCore(response);
            });
    }

    // This will toggle the Survey Summary panel.
    $scope.showSurveyPanel = function () {
        //$scope.showDetailicon = !$scope.showDetailicon;
        if ($rootScope.surveyPanelicon == $scope.surveyGlifIconLeft) {
            $rootScope.surveyPanelicon = $scope.surveyGlifIconRight;
        }
        else {
            $rootScope.surveyPanelicon = $scope.surveyGlifIconLeft;
        }

        $rootScope.surveyMapPanelshow = !$rootScope.surveyMapPanelshow;
        $rootScope.surveyPaneldiv = $rootScope.surveyMapPanelshow ? "surveySummaryPanel" : "surveySummaryPanel surveySummaryhidePanel";
        $scope.surveyPanelOpen = $scope.surveyPanelOpen == false ? true : false;
    }

    // This will add Survey Name filter to applied filters.
    $scope.addToFilter = function (item) {
        Common.addFilterValue("SurveyName", item.SurveyName, "SurveyName");
    }

    // This will get Survey Summary details when user clicks Survey Name in panel.
    $scope.getSurveyDetails = function (e, item) {
        var surName = item.SurveyName;
        var surID = item.surveyId;
        $rootScope.highlightSurvey(surID);
        var target = "";
        //If the Survey detail is already avaialble don't call the service again
        if (surName !== $scope.surName) {
            angular.element(document).find('.surveyDetailDiv').hide();
            $rootScope.loadingData = false;
            $scope.surName = surName;
            var request = Common.getSurveySummaryRequest(surName);

            $http(request)
                .then(function (response) {                    
                    $rootScope.loadingData = true;                    
                    $rootScope.datalist = response.data;
                    $rootScope.surveyMapPanelshow = true;
                    $rootScope.surveyPaneldiv = "surveySummaryPanel";
                    $rootScope.surveyPanelicon = $scope.surveyGlifIconLeft;
                    angular.element(document).find('.surveySummaryPanel').show();
                    angular.element('.surveySidepanelbtn').css('display', 'block')
                    angular.element(document.body).find('.mapoverlay').remove();                             
                }).catch(function (response) {
                    Common.redirectToCore(response);
                });
        }
        target = angular.element(e.currentTarget).find('.surveyDetailDiv');

        if (angular.element(e.currentTarget).find('.surveyDetailDiv:visible').length == 0) {
            angular.element(e.currentTarget).prevAll('li').find('.surveyDetailDiv').hide();
            angular.element(e.currentTarget).nextAll('li').find('.surveyDetailDiv').hide();
            angular.element(e.currentTarget).prevAll('li').find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).prevAll('li').find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-down');
            angular.element(e.currentTarget).nextAll('li').find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).nextAll('li').find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-down');
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-up');
            angular.element(e.currentTarget).prevAll('li').find('a').removeClass('survey-list-item-active');
            angular.element(e.currentTarget).nextAll('li').find('a').removeClass('survey-list-item-active');
            angular.element(e.currentTarget).find('a').addClass('survey-list-item-active');
            target.show();
        }
        else if (angular.element(e.currentTarget).find('.surveyDetailDiv:visible').length >= 1) {
            angular.element(e.currentTarget).prevAll('li').find('.surveyDetailDiv').hide();
            angular.element(e.currentTarget).nextAll('li').find('.surveyDetailDiv').hide();
            target.hide();
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-down');
            angular.element(e.currentTarget).find('a').removeClass('survey-list-item-active');
        }
    }

    // This will show Survey Summary side panel when user clicks Survey area in Map.
    $scope.$on("event:surveyShapeClick", function (event, data) {
        if (data.count == 1) {
            if (!$rootScope.surveyMapPanelshow) {
                $rootScope.surveyPaneldiv = "surveySummaryPanel";
                $rootScope.surveyMapPanelshow = !$rootScope.surveyMapPanelshow
            }
            angular.element('.survey-tile').removeClass('survey-tile-active');
            angular.element(document).find('.surveySummaryPanel').show();
            angular.element(document).find('.surveyListDetailDiv').show();
            angular.element(document).find('.single-survey-info').hide();
            angular.element('.surveySidepanelbtn').css('display', 'block')
            $scope.result = [];
            $rootScope.loadingData = true;
            $rootScope.datalist = "";
            $rootScope.surveyPanelicon = $scope.surveyGlifIconLeft;                                             
            $scope.result = data.res;
            data.count++;
        }
        angular.element(document.body).find('.mapoverlay').remove();
    });

});

