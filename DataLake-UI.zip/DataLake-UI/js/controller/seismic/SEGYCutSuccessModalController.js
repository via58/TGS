angular.module('TGSApp').controller("SEGYCutSuccessModalController", function ($scope, $uibModalInstance) {

    $scope.userMailid = "johndoe@company.com";
    $scope.closeModel = function (e) {
        $uibModalInstance.close('close');
    }
});