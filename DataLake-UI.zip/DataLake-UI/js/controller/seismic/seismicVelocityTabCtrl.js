/*
File Name:- seismicVelocityTabCtrl.js
Summary:- Fetch the Velocity details based on the filter string.
*/

angular.module('TGSApp').controller('seismicVelocityTabCtrl', function ($scope, $location, $rootScope, $filter, $http, SurveyService, Common) {
    $scope.filteredVelocityList = []
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;

    // This function fetches the Velocity data based on the current filter.
    $rootScope.seismicVelocitytab = function () {
        $rootScope.curTab = "Velocity";
        $scope.sercnt += 1;
        $scope.VelocityData = [];
        if ($scope.sercnt == 1) {
            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";

            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.   
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

            // This below function will gets the Selected Velocity fields and frame the Filter string. 
            var selectedFieldsurl = Common.getVelocitySelectedFields();

            // This below function will gets the UUid and frame the Filter string.
            var uuid = Common.getUuid();

            // This below function will gets the customer Id and frame the Filter string.
            var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();
            if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
                surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
            }
            $scope.VelocityData = [];

            // This below function will load project shapes in Map with respect to current filter string. 
            $rootScope.applyProjectFilterByTab(SurveyService.allSurveyFilter, geoSpatialFilter,
                SurveyService.surveyQueryBuilder, uuid, surveyEntitlementUrl, "", "");

            //Form the request object
            var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
                SurveyService.surveyQueryBuilder, selectedFieldsurl, uuid, surveyEntitlementUrl, "Seismic", "Velocity", "0", "", "", "", "")

            // Calling http service request to get Velocity data
            $http(request).then(successCallback, errorCallback);
            $scope.currentPage = 0;
            $scope.sercnt = 0;
        }
    }
    var successCallback = function (response) {
        if (response.data != "" && response.data.content.length > 0) {
            $scope.Velocitycount = response.data.totalElements;
            for (var i = 0; i < response.data.content.length; i++) {
                $scope.VelocityData.push({ fileName: response.data.content[i].parentValue, data: response.data.content[i].list });
            }
            if (response.data.totalElements < 10000) {
                $scope.Velocityitemscount = response.data.totalElements;   //Assigning total elements count
            }
            else {
                $scope.Velocityitemscount = 10000;
            }
        }
        else {
            $scope.VelocityData = [];
            $scope.Velocityitemscount = 0;
            $scope.Velocitycount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }

        // This below function will retain the selected settings from setting modal tab.  
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }
    //  This function will fetch the Velocity data on click of pager.
    $scope.Velocitypager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";

        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.   
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

        // This function will gets the Selected Velocity fields and frame the Filter string. 
        var selectedFieldsurl = Common.getVelocitySelectedFields();

        // This function will gets the UUid and frame the Filter string.
        var uuid = Common.getUuid();

        // This function will gets the customer Id and frame the Filter string.
        var surveyEntitlementUrl = Common.getSurveyEntitlementUrl();
        if (surveyEntitlementUrl == "" && $rootScope.surveyEntitlementUrl) {
            surveyEntitlementUrl = $rootScope.surveyEntitlementUrl;
        }

        $scope.clickedpage = page - 1;
        $scope.VelocityData = [];        

        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');


        //Form the request object
        var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
            SurveyService.surveyQueryBuilder, selectedFieldsurl, uuid, surveyEntitlementUrl, "Seismic", "Velocity",
            $scope.clickedpage, "", "", "", "")

        // Calling http service request to get Velocity data
        $http(request).then(successCallback, errorCallback);
    }
});