/*
File Name:- surveyListCtrl.js
Summary:- Fetch the Survey Summary details based on the selected survey.
*/

angular.module('TGSApp').controller('surveySummaryCtrl', function ($scope, $uibModalInstance, args, $rootScope) {
    
    angular.element(document).on('click', '.survey-tile.survey-tile-active', function () {
        return false;
    })
        $scope.namelist = args.responseTitle;
        $scope.datalist = args.responseData;
        
        //This function execute when user dismiss the modal 
        $scope.cancelModal = function () {
            $uibModalInstance.close('close');            
        }        
});
