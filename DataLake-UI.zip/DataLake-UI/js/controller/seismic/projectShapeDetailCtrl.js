/*
File Name:- projectShapeDetailCtrl.js
Summary:- Populate and displays Project Details based on the selected Project shape.
*/

angular.module('TGSApp').controller('projectShapeDetailCtrl', function ($scope, $rootScope, $http, Common, $timeout) {
    $scope.icon = true;
    $scope.mappanelshow = true;
    $scope.paneldiv = "mapSidepanel";
    $scope.panelicon = "glyphicon glyphicon-chevron-right";
    $scope.panelOpen = false;
    $scope.projectinfoicon = "glyphicon glyphicon-chevron-down";
    $scope.projectinfoopen = false;

    //This function displays and hide map sidepanel on click of glyphicon icon 
    $scope.showPanel = function () {
        $scope.icon = !$scope.icon;
        $scope.panelicon = $scope.icon ? "glyphicon glyphicon-chevron-right" : "glyphicon glyphicon-chevron-left";
        $scope.mappanelshow = !$scope.mappanelshow;
        $scope.paneldiv = $scope.mappanelshow ? "mapSidepanel" : "mapSidepanel maphidepanel";
        $scope.panelOpen = $scope.panelOpen == false ? true : false;
    }
    // This function displays Map sidepanel when user click the projectshape in Map .
    $scope.$on("event:projectShapeClick", function (event, data) {
        if (data.count == 1) {
            $scope.panelicon = "glyphicon glyphicon-chevron-left";
            angular.element(document).find('.mapSidepanel').show();
            $scope.result = [];
            $scope.result = data.result;
            if (!$scope.panelOpen) {
                angular.element('.mapSidepanelbtn').click();
                $scope.panelOpen = true;
            }
            data.count++;
            angular.element('.btnproj').click();
        }
    });
    // This function displays the Project Details on clicking of Project name in map sidepanel.
    $scope.getProjectDetails = function (e, item) {
        var projectID = item.ProjectID;        
        var target = "";
        //If the project detail is already avaialble don't call the service again
        if (projectID !== $scope.projectID) {
            //save the projectID in scope to compare on next click
            $scope.projectID = projectID;
            $scope.ProjectType = item.ProjectType;
            var tabName = $rootScope.curTab;
            if (tabName == 'Spec Sheets')
                tabName = "SpecSheet";
            var moduleName = "Seismic";

            $scope.projDtl = "";

            var projDetailsParams = {
                tabName: tabName,
                module: moduleName,
                mapProjectID: projectID,
                requestTimestamp : Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }
            projDetailsParams.token == "" ? delete projDetailsParams.token : projDetailsParams.token;
            projDetailsParams.access_token == "" ? delete projDetailsParams.access_token : projDetailsParams.access_token;

            var projDetailsParamsList = $.param(projDetailsParams);  // For Serialization and  encodeURIComponent
            var projDetailsrequest = {
                method: 'POST',
                url: Common.urlValue + Common.getMapDetailInfo,
                data: projDetailsParamsList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }

            $http(projDetailsrequest).then(successCallBack, errorCallBack);

            var customerID = Common.getSurveyEntUserForMap();
            if (customerID == "" && $rootScope.projShapeEntitlementUrl) {
                customerID = $rootScope.projShapeEntitlementUrl;
            }
            var entAreaDetailsUrl = "getCustomerAreaOwned";
            $scope.isLoadingCompleted = false;

            var entitlementParams = {
                projectId: projectID,
                customerId: customerID,
                requestTimestamp : Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }
            entitlementParams.customerId == "" ? delete entitlementParams.customerId : entitlementParams.customerId;
            entitlementParams.projectId == "" ? delete entitlementParams.projectId : entitlementParams.projectId;
            entitlementParams.token == "" ? delete entitlementParams.token : entitlementParams.token;
            entitlementParams.access_token == "" ? delete entitlementParams.access_token : entitlementParams.access_token;

            var entitlementParamsList = $.param(entitlementParams);  // For Serialization and  encodeURIComponent
            var entitlementRequest = {
                method: 'POST',
                url: Common.urlValue + entAreaDetailsUrl,
                data: entitlementParamsList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }

            $http(entitlementRequest).then(function (response) {
                $scope.entDtl = response.data[0];               
                //$scope.progressWidth = $scope.entDtl.percentageCovered;
                $timeout(function () {                    
                    angular.element('.ent-progres-fill').css('width', $scope.entDtl.percentageCovered + '%');
                    angular.element('.btnproj').click();
                }, 2500);
            }, errorCallBack);
            $rootScope.highlightSingleProject(projectID);
        }
        else {
            //Fill progress bar with entitle area, If same project is selected
            $rootScope.highlightSingleProject(projectID);
            //angular.element('.projDetailDiv').find('.ent-progres-fill').css('width', $scope.progressWidth + '%');
            angular.element('.ent-progres-fill').css('width', $scope.entDtl.percentageCovered + '%');
        }

        target = angular.element(e.currentTarget).find('.projDetailDiv');

        if (angular.element(e.currentTarget).find('.projDetailDiv:visible').length == 0) {
            angular.element(e.currentTarget).prevAll('li').find('.projDetailDiv').hide();
            angular.element(e.currentTarget).nextAll('li').find('.projDetailDiv').hide();
            angular.element(e.currentTarget).prevAll('li').find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).prevAll('li').find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-down');
            angular.element(e.currentTarget).nextAll('li').find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).nextAll('li').find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-down');
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-up');
            target.show();


        }
        else if (angular.element(e.currentTarget).find('.projDetailDiv:visible').length == 1) {
            angular.element(e.currentTarget).prevAll('li').find('.projDetailDiv').hide();
            angular.element(e.currentTarget).nextAll('li').find('.projDetailDiv').hide();
            target.hide();
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', '');
            angular.element(e.currentTarget).find('a:last').find('span').attr('class', 'glyphicon glyphicon-chevron-down');
        }        
    };

    //This function will execute on success of above get method .
    var successCallBack = function (response) {
        $scope.isLoadingCompleted = true;
        $scope.projDtl = response.data.content[0];
    };
    //This function will Handle errors .
    var errorCallBack = function (reason) {
        Common.redirectToCore(reason);
    }
    //This function displays Entitlement over slected project shape
    $scope.showEntitlement = function (e, item) {

        if (angular.element(e.currentTarget)[0].value == "Show Entitlement") {
            //angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            angular.element(e.currentTarget)[0].value = "Hide Entitlement";
            
            var customerID = Common.getSurveyEntUserForMap();
            if (customerID == "" && $rootScope.projShapeEntitlementUrl) {
                customerID = $rootScope.projShapeEntitlementUrl;
            }

            $rootScope.highlightEntArea(item.ProjectID, customerID, item.ProjectType);
            $rootScope.highlightNonEntArea(item.ProjectID);

        }
        else if (angular.element(e.currentTarget)[0].value == "Hide Entitlement") {
            angular.element(e.currentTarget)[0].value = "Show Entitlement";
            $rootScope.hideEntArea();
            $rootScope.hideNonEntArea();
        }
        //angular.element(document.body).find('.mapoverlay').remove();
        e.preventDefault();
        e.stopPropagation();
    }
    //This function will add this project Name as filter.
    $scope.addToFilter = function (item) {        
        //Moved to common file 
        Common.addFilterValue("ProjectName", item.ProjectName, "ProjectName");
    }   
    
});

