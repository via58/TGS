/*
File Name:- seismicHorizonTabCtrl.js
Summary:- Fetch the Horizon details based on the filter string.
*/

angular.module('TGSApp').controller('seismicHorizonTabCtrl', function ($scope, $location, $rootScope, $filter, $http, SurveyService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;

    // This function fetches the Horizon data based on the current filter.
    $rootScope.seismicHorizontab = function () {
        $scope.Horizonitems = [];
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
            var geoSpatialFilter = "";

            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.   
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

            // This below function will gets the Selected Horizon fields and frame the Filter string. 
            var selectedFields = Common.getHorizonSelectedFields();

            // This below function will gets the UUid and frame the Filter string.
            var uuid = Common.getUuid();

            // This below function will gets the customer Id and frame the Filter string.
            var surveyEntitlementUrl = Common.getSurveyHorizonEntitlementUrl();            
            if(surveyEntitlementUrl == "" && $rootScope.horizonEntitlementUrl){
                if($rootScope.horizonsurveyType == "3D")
                {
                    surveyEntitlementUrl = Common.getAdminHorizonEntUrl();
                }
                else{
                surveyEntitlementUrl = $rootScope.horizonEntitlementUrl;
                }
            }

            //set default SurveyType to 2D for admin role
            if (surveyEntitlementUrl !== "" && ($rootScope.horizonsurveyType == undefined || $rootScope.horizonsurveyType == "")) {
                $rootScope.horizonsurveyType = "2D";
            }
            //  Set horizon survey type based on condition
            if (surveyEntitlementUrl !== "" && $rootScope.filterSurveyType == "3D") {
                angular.element('.horizonEntitle').find('.btn-group').find('label').removeClass('active');
                angular.element('.horizonEntitle').find('.btn-group').find('label:last').addClass('active');
                $rootScope.horizonsurveyType = "3D";
            }
            if (surveyEntitlementUrl !== "" && $rootScope.filterSurveyType == "2D") {
                angular.element('.horizonEntitle').find('.btn-group').find('label').removeClass('active');
                angular.element('.horizonEntitle').find('.btn-group').find('label:first').addClass('active');
                $rootScope.horizonsurveyType = "2D";
            }

            // This below function will load project shapes in Map with respect to current filter string.
            $rootScope.applyProjectFilterByTab(SurveyService.allSurveyFilter, geoSpatialFilter, SurveyService.surveyQueryBuilder,
                uuid, surveyEntitlementUrl, $rootScope.horizonsurveyType, "");

                //Form the request object
            var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
                SurveyService.surveyQueryBuilder, selectedFields, uuid, surveyEntitlementUrl, "Seismic",
                "Horizon", "0", "", "", $rootScope.horizonsurveyType, "")

            // Calling http service request to get Horizon data 
            $http(request).then(successCallback, errorCallback); 
            $scope.sercnt = 0;
            $scope.currentPage = 0;             
        }
    }
    var successCallback = function (response) {        
        if (response.data != "" && response.data.content.length > 0) {
            if(response.data.number == 0){
            $scope.Horizoncount = response.data.content[0].totalRecords;
            }
            for (var i = 0; i < response.data.content.length; i++) {
                $scope.Horizonitems.push({ data: response.data.content[i].compositeList });
            }
            if ($scope.Horizoncount < 10000) {
                $scope.HorizonPagesCount = $scope.Horizoncount ; //Assigning total elements count
            }
            else {
                $scope.HorizonPagesCount = 10000;
            }
        }
        else {
            $scope.Horizonitems = [];
            $scope.HorizonPagesCount = 0;
            $scope.Horizoncount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }
        

        // This below function will retain the selected settings from setting modal tab.  
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }
    //  This function will fetch the Horizon data on click of pager.
    $rootScope.Horizonpager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";

        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

        // This below function will gets the Selected Horizon fields and frame the Filter string. 
        var selectedFields = Common.getHorizonSelectedFields();

        // This below function will gets the UUid and frame the Filter string.
        var uuid = Common.getUuid();

        // This below function will gets the customer Id and frame the Filter string.
        var surveyEntitlementUrl = Common.getSurveyHorizonEntitlementUrl();        
            if(surveyEntitlementUrl == "" && $rootScope.horizonEntitlementUrl){
                if($rootScope.horizonsurveyType == "3D")
                {
                    surveyEntitlementUrl = Common.getAdminHorizonEntUrl();
                }
                else{
                surveyEntitlementUrl = $rootScope.horizonEntitlementUrl;
                }
            }

        $scope.Horizonitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

        $scope.clickedpage = page - 1;
        

        //Form the request object
        var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
            SurveyService.surveyQueryBuilder, selectedFields, uuid, surveyEntitlementUrl, "Seismic", "Horizon"
            , $scope.clickedpage, "", "", $rootScope.horizonsurveyType, "")

        // Calling http service request to get Horizon data 
        $http(request).then(successCallback,errorCallback);            
    }

    // This function will filter the data based on Horizon survey type 
    angular.element(document).on('click', '.horizonEntitle .btn-group label', function () {
        $rootScope.horizonsurveyType = angular.element(this).text();
        var surveyTypeExist = false;
        if ($rootScope.horizonsurveyType == "3D") {

            if ($rootScope.surveyselectedValArr.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                    var QBObj = $rootScope.surveyselectedValArr[i].value;
                    for (var j = 0; j < QBObj.length; j++) {
                        if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                            || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                            surveyTypeExist = true;
                            $rootScope.horizonsurveyType = QBObj[j].substring(QBObj[j].length - 2);
                            $.alertable.alert("SurveyType = 2D is already applied. Remove SurveyType = 2D filter to view the 3D data.");
                            return false;
                        }
                    }
                }
            }

            if ($rootScope.surveyselectedFieldsDetails.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                    if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType"
                        && $rootScope.surveyselectedFieldsDetails[i].fieldValue == "2D") {
                        surveyTypeExist = true;
                        $rootScope.horizonsurveyType = "2D";
                        $.alertable.alert("SurveyType = 2D is already applied. Remove SurveyType = 2D filter to view the 3D data.");
                        return false;
                    }
                }
            }
            else {
                //$rootScope.seismicHorizontab();
            }
            if (!surveyTypeExist)
                $rootScope.seismicHorizontab();
        }
        else if ($rootScope.horizonsurveyType == "2D") {

            if ($rootScope.surveyselectedValArr.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                    var QBObj = $rootScope.surveyselectedValArr[i].value;
                    for (var j = 0; j < QBObj.length; j++) {
                        if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                            || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                            surveyTypeExist = true;
                            $rootScope.horizonsurveyType = QBObj[j].substring(QBObj[j].length - 2);
                            $.alertable.alert("SurveyType = 3D is already applied. Remove SurveyType = 3D filter to view the 2D data.");
                            return false;
                        }
                    }
                }
            }

            if ($rootScope.surveyselectedFieldsDetails.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                    if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType"
                        && $rootScope.surveyselectedFieldsDetails[i].fieldValue == "3D") {
                        surveyTypeExist = true;
                        $rootScope.horizonsurveyType = "3D";
                        $.alertable.alert("SurveyType = 3D is already applied. Remove SurveyType = 3D filter to view the 2D data.");
                        return false;
                    }
                }
            }
            else {
                //$rootScope.seismicHorizontab();
            }
            if (!surveyTypeExist)
                $rootScope.seismicHorizontab();
        }
    });
});