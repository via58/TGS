/*
File Name:- seismicAeroMagTabCtrl.js
Summary:- Fetch the AeroMag details based on the filter string.
*/

angular.module('TGSApp').controller('seismicAeroMagTabCtrl', function ($scope, $location, $rootScope, $filter, $http, SurveyService, Common) {
    $scope.currentPage = 0;
    $scope.pageSize = 20;
    $scope.sercnt = 0;

    // This function fetches the Aeromag data based on the current filter.
    $rootScope.seismicAeroMagtab = function () {
        $scope.AeroMagitems = [];
        $rootScope.curTab = "AeroMag";
        $scope.sercnt += 1;
        if ($scope.sercnt == 1) {
            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');

            var geoSpatialFilter = "";

            // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.   
            if (window.drawPolygon)
                geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

            // This function will gets the Selected AeroMag fields and frame the Filter string.
            var selectedFieldsurl = Common.getAeroMagSelectedFields();

            // This function will gets the UUid and frame the Filter string.
            var uuid = Common.getUuid();

            // This function will gets the customer Id and frame the Filter string.
            var surveyEntitlementUrl = Common.getSurveyAeroMagEntitlementUrl();
            if (surveyEntitlementUrl == "" && $rootScope.aeroMagEntitlementUrl) {
                if ($rootScope.AeroMagSurveyType == "3D") {
                    surveyEntitlementUrl = Common.getAdminAeroMagEntUrl();
                }
                else {
                    surveyEntitlementUrl = $rootScope.aeroMagEntitlementUrl;
                }
            }
            //set default SurveyType to 2D for admin role
            if (surveyEntitlementUrl !== "" && ($rootScope.AeroMagSurveyType == undefined || $rootScope.AeroMagSurveyType == "")) {
                $rootScope.AeroMagSurveyType = "2D";
            }

            //  Set AeroMag survey type based on condition
            if (surveyEntitlementUrl !== "" && $rootScope.filterSurveyType == "3D") {
                angular.element('.AeromagEntitle').find('.btn-group').find('label').removeClass('active');
                angular.element('.AeromagEntitle').find('.btn-group').find('label:last').addClass('active');
                $rootScope.AeroMagSurveyType = "3D";
            }
            if (surveyEntitlementUrl !== "" && $rootScope.filterSurveyType == "2D") {
                angular.element('.AeromagEntitle').find('.btn-group').find('label').removeClass('active');
                angular.element('.AeromagEntitle').find('.btn-group').find('label:first').addClass('active');
                $rootScope.AeroMagSurveyType = "2D";
            }
            // This function will load project shapes in Map with respect to current filter string.    
            $rootScope.applyProjectFilterByTab(SurveyService.allSurveyFilter, geoSpatialFilter,
                SurveyService.surveyQueryBuilder, uuid, surveyEntitlementUrl, $rootScope.AeroMagSurveyType, "");

            //Form the request object
            var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
                SurveyService.surveyQueryBuilder, selectedFieldsurl, uuid, surveyEntitlementUrl, "Seismic",
                "AeroMag", "0", "", "", $rootScope.AeroMagSurveyType, "")

            // Calling http service request to get Velocity data
            $http(request).then(successCallback, errorCallback);
            $scope.sercnt = 0;
            $scope.currentPage = 0;
        }
    }
    var successCallback = function (response) {        
        if (response.data != "" && response.data.content.length > 0) {
            //$scope.AeroMagCount = response.data.totalElements;            
            if(response.data.number==0){
                $scope.AeroMagCount = response.data.content[0].totalRecords;
                }

            for (var i = 0; i < response.data.content.length; i++) {
                $scope.AeroMagitems.push({  data: response.data.content[i].compositeList });
            }

            if (response.data.totalElements < 10000) {
                $scope.AeroMagPagesCount = $scope.AeroMagCount;  //Assigning total elements count
            }
            else {
                $scope.AeroMagPagesCount = 10000;
            }
        }
        else {
            $scope.AeroMagitems = [];            
            $scope.AeroMagPagesCount = 0;
            $scope.AeroMagCount = 0;
            angular.element(document).find('.norecords').text('No records found.');
        }
        

        // Below function will fetch the additional selected fields if any.  
        setTimeout(function () {
            $rootScope.retainFields();
        }, 1500);
        angular.element(document.body).find('.pagerspinner').remove();
        Common.enableTabs();
    }
    var errorCallback = function (response) {
        $scope.sercnt = 0;
        angular.element(document.body).find('.pagerspinner').remove();        
        angular.element(document).find('.norecords').text('No records found.');
        Common.redirectToCore(response);
    }
    //  This function will fetch the Aeromag data on click of pager.
    $rootScope.AeroMagpager = function (custommsg, page, pageSize, total) {
        var geoSpatialFilter = "";

        // If polygon is drawn,get the project Geoshape,LatLong coordinates and frame the Filter string.   
        if (window.drawPolygon)
            geoSpatialFilter = Common.getWellgeoSpatialFilter(SurveyService.allSurveyFilter);

        // This function will gets the Selected AeroMag fields and frame the Filter string.
        var selectedFieldsurl = Common.getAeroMagSelectedFields();

        // This function will gets the UUid and frame the Filter string.
        var uuid = Common.getUuid();

        // This function will gets the customer Id and frame the Filter string.
        var surveyEntitlementUrl = Common.getSurveyAeroMagEntitlementUrl();

        if (surveyEntitlementUrl == "" && $rootScope.aeroMagEntitlementUrl) {
            if ($rootScope.AeroMagSurveyType == "3D") {
                surveyEntitlementUrl = Common.getAdminAeroMagEntUrl();
            }
            else {
                surveyEntitlementUrl = $rootScope.aeroMagEntitlementUrl;
            }
        }

        $scope.AeroMagitems = [];
        angular.element(document).find('.norecords').text('Loading...').append('<div class="pagerspinner"></div>');
        $scope.clickedpage = page - 1;



        //Form the request object
        var request = Common.getPostReqParams(SurveyService.allSurveyFilter, geoSpatialFilter, "",
            SurveyService.surveyQueryBuilder, selectedFieldsurl, uuid, surveyEntitlementUrl, "Seismic",
            "AeroMag", $scope.clickedpage, "", "", $rootScope.AeroMagSurveyType, "")

        // Calling http service request to get AeroMag data  
        $http(request).then(successCallback, errorCallback);
    }

    // This function will filter the data based on AeroMag survey type 
    angular.element(document).on('click', '.AeromagEntitle .btn-group label', function () {
        $rootScope.AeroMagSurveyType = angular.element(this).text();
        var surveyTypeExist = false;
        if ($rootScope.AeroMagSurveyType == "3D") {

            if ($rootScope.surveyselectedValArr.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                    var QBObj = $rootScope.surveyselectedValArr[i].value;
                    for (var j = 0; j < QBObj.length; j++) {
                        if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                            || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                            surveyTypeExist = true;
                            $rootScope.AeroMagSurveyType = QBObj[j].substring(QBObj[j].length - 2);
                            $.alertable.alert("SurveyType = 2D is already applied. Remove SurveyType = 2D filter to view the 3D data.");
                            return false;
                        }
                    }
                }
            }

            if ($rootScope.surveyselectedFieldsDetails.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                    if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType"
                        && $rootScope.surveyselectedFieldsDetails[i].fieldValue == "2D") {
                        surveyTypeExist = true;
                        $rootScope.AeroMagSurveyType = "2D";
                        $.alertable.alert("SurveyType = 2D is already applied. Remove SurveyType = 2D filter to view the 3D data.");
                        return false;
                    }
                }
            }
            else {
                //$rootScope.seismicAeroMagtab();
            }
            if (!surveyTypeExist)
                $rootScope.seismicAeroMagtab();
        }

        else if ($rootScope.AeroMagSurveyType == "2D") {

            if ($rootScope.surveyselectedValArr.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedValArr.length; i++) {
                    var QBObj = $rootScope.surveyselectedValArr[i].value;
                    for (var j = 0; j < QBObj.length; j++) {
                        if (QBObj[j] == "SurveyType:eqto:2D" || QBObj[j] == "SurveyType:eqto:3D"
                            || QBObj[j] == "SurveyType:neqto:2D" || QBObj[j] == "SurveyType:neqto:3D") {
                            surveyTypeExist = true;
                            $rootScope.AeroMagSurveyType = QBObj[j].substring(QBObj[j].length - 2);
                            $.alertable.alert("SurveyType = 3D is already applied. Remove SurveyType = 3D filter to view the 2D data.");
                            return false;
                        }
                    }
                }
            }

            if ($rootScope.surveyselectedFieldsDetails.length > 0) {
                for (var i = 0; i < $rootScope.surveyselectedFieldsDetails.length; i++) {
                    if ($rootScope.surveyselectedFieldsDetails[i].fieldName == "SurveyType"
                        && $rootScope.surveyselectedFieldsDetails[i].fieldValue == "3D") {
                        surveyTypeExist = true;
                        $rootScope.AeroMagSurveyType = "3D";
                        $.alertable.alert("SurveyType = 3D is already applied. Remove SurveyType = 3D filter to view the 2D data.");
                        return false;
                    }
                }
            }
            else {
                $rootScope.seismicAeroMagtab();
            }
            if (!surveyTypeExist)
                $rootScope.seismicAeroMagtab();
        }
    });
});