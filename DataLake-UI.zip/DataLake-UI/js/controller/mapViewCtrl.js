/*
File Name:- mapViewCtrl.js
Summary:- This contains all map related functions.
*/

(function (app) {
    "use strict";

    app.component("mapViewComponent", {
        templateUrl: "partials/mapContent.html",
        bindings: {
            componentData: "<"
        },
        controller: mapViewController
    });
    function mapViewController($q, $scope, $rootScope, WellService, SurveyService, $http, Common, Constants) {
        var gridExtent;
        var initialExtent;
        var allWellUIFilter = "";
        var allSurveyUIFilter = "";
        var projectLayer;
        var singleProjectLayer;
        var entAreaLayer;
        var nonEntAreaLayer;
        var selectedPrjSymbol;
        var singleProjectSymbol;
        var idDetail = false;
        var isSingleSurveyClicked = false;
        var isOn = false;
        var isCallFromBBService = true;
        var isDrawing = false;
        var projectFilter = "";
        var polygonFilterGeometry;
        var lastExtent;
        var $ctrl = this;
        $ctrl.map = null;
        // $rootScope.isSeismic = false;
        $ctrl.drawTool = null;
        $ctrl.mapExtent = null;
        $ctrl.totalRequests = 0;
        $ctrl.dWellFilter = "";
        $ctrl.totalCallbacks = [];
        $ctrl.polygonSymbol = WellService.getSimpleFillSymbolJson([138, 43, 226, 32], [0, 255, 0, 255], 1);
        $ctrl.selectedProjectSymbol = WellService.getSimpleFillSymbolJson([0, 0, 0, 0.3], [0, 255, 0, 255], 3);
        $ctrl.resolutions = [156543.03392800014, 78271.51696399994, 39135.75848200009, 19567.87924099992, 9783.93962049996, 4891.96981024998, 2445.98490512499, 1222.992452562495, 611.4962262813797, 305.74811314055756, 152.87405657041106, 76.43702828507324, 38.21851414253662, 19.10925707126831, 9.554628535634155, 4.77731426794937, 2.388657133974685, 1.1943285668550503, 0.5971642835598172, 0.29858214164761665, 0.14929107082380833, 0.07464553541190416, 0.03732276770595208, 0.01866138385297604];
        $ctrl.mapOptions = { basemap: "gray", center: [-32, 50], zoom: 2, minZoom: 2, showLabels: true };
        $ctrl.layerAdded = false;
        $ctrl.$onInit = function () {
            require([
                "esri/urlUtils",
                "esri/map",
                "esri/graphic",
                "esri/layers/DynamicLayerInfo",
                "esri/layers/FeatureLayer",
                "esri/layers/LayerDataSource",
                "esri/layers/LayerMapSource",
                "esri/layers/LayerDrawingOptions",
                "esri/layers/QueryDataSource",
                "esri/renderers/SimpleRenderer",
                "esri/symbols/SimpleFillSymbol",
                "esri/symbols/PictureMarkerSymbol",
                "esri/tasks/IdentifyTask",
                "esri/tasks/IdentifyParameters",
                "esri/symbols/TextSymbol",
                "esri/request",
                "esri/geometry/geometryEngine",
                "esri/SpatialReference",
                "dojo/sniff",
                "esri/layers/ArcGISDynamicMapServiceLayer",
                "esri/layers/ImageParameters",
                "esri/layers/ArcGISTiledMapServiceLayer",
                "esri/layers/GraphicsLayer",
                "esri/dijit/HomeButton",
                "esri/toolbars/draw",
                "esri/geometry/screenUtils",
                "esri/geometry/webMercatorUtils",
                "esri/graphicsUtils",
                "esri/geometry/Extent",
                "esri/geometry/Polygon",
                "esri/geometry/Circle",
                "esri/geometry/Point",
                "esri/renderers/UniqueValueRenderer",
                "esri/Color",
                "esri/config",
                "dojo/dom",
                "dojo/dom-attr",
                "dojo/dom-construct",
                "dojo/domReady!"
            ], function (urlUtils, Map, Graphic,
                DynamicLayerInfo, FeatureLayer, LayerDataSource, LayerMapSource, LayerDrawingOptions, QueryDataSource, SimpleRenderer,
                SimpleFillSymbol, PictureMarkerSymbol, IdentifyTask, IdentifyParameters, TextSymbol, EsriRequest, GeometryEngine, SpatialReference, sniff, MapImageLayer, ImageParameters, TileLayer,
                GraphicsLayer, HomeButton, Draw, ScreenUtils, webMercatorUtils, graphicsUtils, Extent, Polygon, Circle, Point,
                UniqueValueRenderer, Color, config, dom, domAttr, domconstruct) {
                    $ctrl.DynamicLayerInfo = DynamicLayerInfo;
                    $ctrl.FeatureLayer = FeatureLayer;
                    $ctrl.LayerDataSource = LayerDataSource;
                    $ctrl.LayerDrawingOptions = LayerDrawingOptions;
                    $ctrl.LayerMapSource = LayerMapSource;
                    $ctrl.QueryDataSource = QueryDataSource;
                    $ctrl.SimpleRenderer = SimpleRenderer;
                    $ctrl.TileLayer = TileLayer;
                    $ctrl.MapImageLayer = MapImageLayer;
                    $ctrl.ImageParameters = ImageParameters;
                    $ctrl.GraphicsLayer = GraphicsLayer;
                    $ctrl.Draw = Draw;
                    $ctrl.Graphic = Graphic;
                    $ctrl.EsriRequest = EsriRequest;
                    $ctrl.SpatialReference = SpatialReference;
                    $ctrl.sniff = sniff;
                    $ctrl.GeometryEngine = GeometryEngine;
                    $ctrl.SimpleFillSymbol = SimpleFillSymbol;
                    $ctrl.PictureMarkerSymbol = PictureMarkerSymbol;
                    $ctrl.IdentifyTask = IdentifyTask;
                    $ctrl.IdentifyParameters = IdentifyParameters;
                    $ctrl.TextSymbol = TextSymbol;
                    $ctrl.ScreenUtils = ScreenUtils;
                    $ctrl.Extent = Extent;
                    $ctrl.Polygon = Polygon;
                    $ctrl.Circle = Circle;
                    $ctrl.Point = Point;
                    $ctrl.dom = dom;
                    $ctrl.domAttr = domAttr;
                    $ctrl.domconstruct = domconstruct;
                    $ctrl.webMercatorUtils = webMercatorUtils;
                    $ctrl.graphicsUtils = graphicsUtils;
                    $ctrl.UniqueValueRenderer = UniqueValueRenderer;
                    $ctrl.Color = Color;
                    $ctrl.config = config;

                    // Definition for seleted project shape symbol
                    selectedPrjSymbol = new esri.symbol.SimpleLineSymbol(
                        esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                        new dojo.Color([249, 160, 27, 1]),
                        1
                    );

                    // Definition for all single project shape symbol, on click of side panel item
                    singleProjectSymbol = new $ctrl.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
                        new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                            new $ctrl.Color([0, 54, 96]), 3), new $ctrl.Color([23, 171, 171, 0.69])
                    );

                    //esriConfig.request.maxUrlLength = 256;
                    for (var x = 0; x < WellService.mapServicesProxyDetails.length; x++) {
                        var proxyUrl = WellService.mapServicesProxyDetails[x].proxyUrl;
                        var urls = WellService.mapServicesProxyDetails[x].urls;
                        for (var y = 0; y < urls.length; y++) {
                            urlUtils.addProxyRule({
                                urlPrefix: urls[y],
                                proxyUrl: proxyUrl
                            });
                        }
                    }

                    // Map control initialization
                    $ctrl.map = new Map("viewDiv", $ctrl.mapOptions);
                   
                    // $(document).ready(function(){
                    //     $('[data-toggle="popover"]').popover();   
                    // });
                    // DEV project shape url
                    esri.config.defaults.io.corsEnabledServers.push("r360gisdev01.tgsr360.com");

                    // PROD project shape url
                    //esri.config.defaults.io.corsEnabledServers.push("gisprod01.tgsr360.com");

                    // Default extent button initialization
                    var home = new HomeButton({
                        map: $ctrl.map
                    }, "HomeButton");
                    home.startup();

                    addLayersToMap();

                    // Map key down event, used to close pop up by escape button
                    $ctrl.map.on('key-down', function (key) { if (key.keyCode == 27) { $ctrl.map.infoWindow.hide(); } });

                    // Map pan end event, used to cluster splitting
                    $ctrl.map.on('extent-change', function (evt) {
                        //var geographicExtent = $ctrl.webMercatorUtils.webMercatorToGeographic($ctrl.Polygon.fromExtent(evt.extent)).getExtent();

                        if (evt.extent.ymin < -20000000 || evt.extent.ymin > 20000000) {
                            $ctrl.map.setExtent(lastExtent);
                            return;
                        }
                        if (evt.extent.ymax < -20000000 || evt.extent.ymax > 20000000) {
                            $ctrl.map.setExtent(lastExtent);
                            return;
                        }

                        lastExtent = $ctrl.map.extent;

                        if (idDetail == false)
                            return;
                        if (evt.delta == null)
                            return;
                        // if (evt.delta) {
                        //     if (evt.delta.x == 0 && evt.delta.y == 0)
                        //         return;
                        // }

                        if ($rootScope.filterNameGroup == "Seismic")
                            return;

                        if ($ctrl.map.getLevel() == 2 && ($ctrl.dWellFilter.metaDataFilter == "" && $ctrl.dWellFilter.geoSpaFilter == "" && $ctrl.dWellFilter.qbStr == ""
                            && $ctrl.dWellFilter.uuid == "" && $ctrl.dWellFilter.customFilter == "" && $ctrl.dWellFilter.pdfFilterStr == "")) {

                            return;
                        }
                        if (idDetail && isDrawing == false) {
                            if ($ctrl.map.getLevel() > 8)
                                GetWells($ctrl.dWellFilter)
                            else
                                GenerateGrids($ctrl.dWellFilter);
                        }
                        isCallFromBBService = false;
                        // dojo.byId('viewDiv_container').style.clip = "auto";
                    });

                    // Map event to show pop up on map click for well clusters
                    $ctrl.map.on("mouse-up", getGraphics);

                    // Map click event to highlight project shapes on map
                    $ctrl.map.on("click", function (evt) {
                        if (isDrawing == true)
                            return;
                        if (idDetail == false) {
                            var toggleTxt = angular.element(document).find('.tools-section').find('.btn-group').find('label.active').text();
                            if (toggleTxt == 'SURVEY')
                                selectSurveysOnMap(evt);
                            return;
                        }
                        if ($rootScope.filterNameGroup != "Seismic")
                            return;
                        var toggleTxt = angular.element(document).find('.tools-section').find('.btn-group').find('label.active').text();
                        if (toggleTxt == 'WELL')
                            return;

                        applyProjectFilters(evt);

                    });

                    $ctrl.map.on('update-start', function () {
                        angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
                    }
                    );

                    $ctrl.map.on('update-end', function () {
                        angular.element(document.body).find('.mapoverlay').remove();
                    }
                    );

                    // Map load event
                    $ctrl.map.on('load', function () {
                        $ctrl.map.infoWindow.resize(250, 100);
                        dojo.byId('HomeButton').style.display = "block";
                        $ctrl.drawTool = new Draw($ctrl.map, { showTooltips: false });
                        var fillSymbol = new $ctrl.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
                            new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                                new $ctrl.Color([0, 255, 0]), 2), new $ctrl.Color([23, 171, 171, 0.125])
                        );
                        $ctrl.drawTool.setFillSymbol(fillSymbol);
                        $ctrl.drawTool.on("draw-complete", $ctrl.polygonDrawComplete);
                        if (initialExtent == undefined)
                            initialExtent = $ctrl.map.extent;
                    });
                });
        }

        // Function to add all layers to map at load time
        function addLayersToMap() {
            var mapLayers = [];
            for (var mapServiceId in WellService.mapServiceDetails) {
                var info = WellService.mapServiceDetails[mapServiceId];
                var layer = createLayer(info, mapServiceId);
                if (info.index >= 0 && layer) {
                    info.layer = layer;
                    mapLayers[info.index] = layer;
                }
            }

            for (var mapServiceId in WellService.filterMapServiceDetails) {
                var mapServiceList = WellService.filterMapServiceDetails[mapServiceId];
                for (var y = 0; y < mapServiceList.length; y++) {
                    var info = mapServiceList[y]
                    var layer = createLayer(info, mapServiceId + "_" + y);
                    if (info.index >= 0 && layer) {
                        info.layer = layer;
                        mapLayers[info.index] = layer;
                    }
                }
            }

            for (var x = mapLayers.length - 1; x >= 0; x--) {
                if (!mapLayers[x])
                    mapLayers.splice(x, 1);
            }
            $ctrl.map.addLayers(mapLayers);

            addProjectLayer();
        }

        // Function to create layer from ids
        function createLayer(info, mapServiceId) {
            var layer;
            if (info.type == "TileLayer") {
                layer = new $ctrl.TileLayer(info.url, {
                    id: mapServiceId,
                    opacity: info.opacity ? info.opacity : 1.0
                });
                layer.setVisibility(info.visible);
            }
            else if (info.type == "MapImageLayer") {
                layer = new $ctrl.MapImageLayer(info.url, {
                    id: mapServiceId
                });
                layer = addDynamicLayers(info, layer);
                layer.setVisibility(info.visible);
            }
            else if (info.type == "GraphicsLayer") {
                // Not Implemented.
            }
            return layer;
        }

        // Function to add dynamic layers to map
        function addDynamicLayers(info, layer) {
            var dynamicLayerInfos = [];
            var layerDrawingOptions = [];
            var source;
            if (info.sublayers && info.sublayers.length > 0) {
                if (info.sublayers[0].source) {
                    for (var x = 0; x < info.sublayers.length; x++) {
                        var subLayer = info.sublayers[x];
                        if (subLayer.source.type == "dataLayer") {
                            var queryDataSource = new $ctrl.QueryDataSource();
                            queryDataSource.workspaceId = subLayer.source.dataSource.workspaceId;
                            queryDataSource.query = subLayer.source.dataSource.query;

                            queryDataSource.oidFields = [subLayer.source.dataSource.oidFields];
                            queryDataSource.geometryType = subLayer.source.dataSource.geometryType;
                            queryDataSource.spatialReference = new $ctrl.SpatialReference({
                                wkid: subLayer.source.dataSource.spatialReference.wkid
                            });

                            source = new $ctrl.LayerDataSource();
                            source.dataSource = queryDataSource;
                        }
                        else {
                            source = new $ctrl.LayerMapSource(subLayer.source);
                        }

                        var dynamicLayerInfo = new $ctrl.DynamicLayerInfo();
                        dynamicLayerInfo.source = source;
                        dynamicLayerInfo.id = subLayer.id;
                        dynamicLayerInfos[subLayer.id] = dynamicLayerInfo;

                        var layerDrawingOption = new $ctrl.LayerDrawingOptions();
                        layerDrawingOptions[subLayer.id] = layerDrawingOption;
                        layerDrawingOption.renderer = new $ctrl.SimpleRenderer(subLayer.renderer);

                    }
                    layer.setDynamicLayerInfos(dynamicLayerInfos);
                    layer.setLayerDrawingOptions(layerDrawingOptions);
                }
                else {
                    var layerDefinitions = [];
                    for (var x = 0; x < info.sublayers.length; x++) {
                        layerDefinitions[info.sublayers[x].id] = info.sublayers[x].definitionExpression;
                        if (info.sublayers[x].renderer) {
                            var layerDrawingOption = new $ctrl.LayerDrawingOptions();
                            layerDrawingOptions[info.sublayers[x].id] = layerDrawingOption;
                            layerDrawingOption.renderer = new $ctrl.SimpleRenderer(info.sublayers[x].renderer);
                        }
                    }
                    if (layerDrawingOptions.length > 0) {
                        layer.setLayerDrawingOptions(layerDrawingOptions);
                    }
                    layer.setLayerDefinitions(layerDefinitions);
                    layer.setVisibleLayers(info.visibleSubLayers);
                }
            }
            return layer;
        }

        // Apply well filters
        function applyWellFilters(data) {
            var wellFilterString = "";
            var fieldList = [];
            turnOffWellFiltersLayer();
            for (var x = 0; x < data.filterInfo.length; x++) {
                var fieldName = data.filterInfo[x].fieldName;
                var fieldValue = data.filterInfo[x].fieldValue;
                var filterString = "";

                if (fieldList.indexOf(fieldName) < 0)
                    fieldList.push(fieldName);

                if (WellService.WellMetadataFields[fieldName] == "Number") {
                    filterString = fieldName + " IN (" + fieldValue + ")";
                }
                else if (WellService.WellMetadataFields[fieldName] == "String") {
                    filterString = fieldName + " IN ('" + fieldValue.split(",").join("','") + "')";
                }

                if (x == 0) {
                    wellFilterString = filterString;
                }
                else {
                    wellFilterString += " ~~~ " + filterString;
                }
            }
            var wellMetadataLayerId = WellService.wellMetadataLayerId;
            var geometryFilter = "";

            // Check whether polygon filter is applied or not
            if (window.drawPolygon && window.polygon.wkt != "") {
                if (wellFilterString != "")
                    geometryFilter = " AND SHAPE.STIntersects(geometry::STGeomFromText('" + window.polygon.wkt + "', 4326))=1";
                else
                    geometryFilter = " SHAPE.STIntersects(geometry::STGeomFromText('" + window.polygon.wkt + "', 4326))=1";
            }
            $scope.$applyAsync(function () {
                hideWellCachelayer();
            });
            if (wellFilterString != "" || geometryFilter != "") {
                require([
                    "esri/tasks/QueryTask",
                    "esri/tasks/query",
                    "esri/SpatialReference",
                    "dojo/promise/all"
                ], function (QueryTask, Query, SpatialReference, PromiseAll) {
                    var queryTasks = [];
                    for (var y = 0; y < WellService.filterMapServiceDetails[wellMetadataLayerId].length; y++) {
                        var layer = WellService.filterMapServiceDetails[wellMetadataLayerId][y].layer;
                        var queryTask = new QueryTask(layer.url + "/0");
                        var query = new Query();
                        query.where = wellFilterString == "" ? "1=1" : wellFilterString;
                        if (geometryFilter != "")
                            query.geometry = window.polygon.geometry;
                        query.returnGeometry = false;
                        query.num = 5;
                        query.outFields = ["WellID"];
                        query.outSpatialReference = new SpatialReference({ wkid: 102100 });
                        var currentTime = Common.getCurrentTime();
                        queryTasks.push(queryTask.execute(query));
                    }
                    PromiseAll(queryTasks).then(
                        function (response) {
                            //creating log request
                            var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.APPLY_WELL_FILTERS, WellService.filterMapServiceDetails[wellMetadataLayerId][0].url, Constants.APPLICATION_NAME, $rootScope.userName
                                , Constants.SUCCESS, null, wellFilterString, geometryFilter, null, Common.getCurrentDateTime(),
                                Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), null);


                            $http(logReq); //Logging the success request

                            // On successful execution of service zoom the data using below function
                            zoomToFilteredWells(fieldList, wellFilterString, function () {
                                for (var z = 0; z < response.length; z++) {
                                    var result = response[z];
                                    var layer = WellService.filterMapServiceDetails[wellMetadataLayerId][z].layer;
                                    if (result.features.length > 0) {
                                        for (var j = 0; j < layer.dynamicLayerInfos.length; j++) {
                                            var baseQuery = WellService.filterMapServiceDetails[wellMetadataLayerId][z].sublayers[j].source.dataSource.query;
                                            layer.dynamicLayerInfos[j].source.dataSource.query = baseQuery + ' WHERE ' + wellFilterString + geometryFilter;
                                        }
                                        layer.setVisibility(true);
                                    }
                                    else {
                                        layer.setVisibility(false);
                                    }
                                }
                            });
                        }
                    );
                });
            }
        };

        // This is function is used to zoom to the filtered wells
        function zoomToFilteredWells(fieldList, queryString, callback) {
            require([
                "esri/tasks/QueryTask",
                "esri/tasks/query",
                "esri/SpatialReference",
                "esri/tasks/StatisticDefinition",
                "esri/geometry/Extent",
                "esri/geometry/webMercatorUtils"
            ], function (
                QueryTask, Query, SpatialReference, StatisticDefinition, Extent, webMercatorUtils
            ) {
                    var queryTask = new QueryTask(WellService.wellExtentService);

                    var staticDefMinLat = new StatisticDefinition();
                    staticDefMinLat.statisticType = "min";
                    staticDefMinLat.onStatisticField = "SurfaceLatitudeWGS84";
                    staticDefMinLat.outStatisticFieldName = "MinY";

                    var staticDefMaxLat = new StatisticDefinition();
                    staticDefMaxLat.statisticType = "max";
                    staticDefMaxLat.onStatisticField = "SurfaceLatitudeWGS84";
                    staticDefMaxLat.outStatisticFieldName = "MaxY";

                    var staticDefMinLong = new StatisticDefinition();
                    staticDefMinLong.statisticType = "min";
                    staticDefMinLong.onStatisticField = "SurfaceLongitudeWGS84";
                    staticDefMinLong.outStatisticFieldName = "MinX";

                    var staticDefMaxLong = new StatisticDefinition();
                    staticDefMaxLong.statisticType = "max";
                    staticDefMaxLong.onStatisticField = "SurfaceLongitudeWGS84";
                    staticDefMaxLong.outStatisticFieldName = "MaxX";

                    var query = new Query();
                    query.where = queryString;
                    if (window.drawPolygon)
                        query.geometry = window.polygon.geometry;
                    query.returnGeometry = false;
                    query.outFields = ["*"]

                    query.groupByFieldsForStatistics = fieldList;
                    query.outStatistics = [staticDefMinLat, staticDefMaxLat, staticDefMinLong, staticDefMaxLong];

                    // In about steps query has been cofigured now execute it
                    queryTask.execute(query).then(function (result) {
                        if (result.features && result.features.length > 0) {
                            var attributes = result.features[0].attributes;
                            if (attributes.MinX == null || attributes.MaxX == null || attributes.MinY == null || attributes.MaxY == null)
                                return;
                            var extent = new Extent({
                                xmin: attributes.MinX,
                                xmax: attributes.MaxX,
                                ymin: attributes.MinY,
                                ymax: attributes.MaxY,
                                spatialReference: new SpatialReference({ wkid: 4326 })
                            });
                            extent = webMercatorUtils.geographicToWebMercator(extent);
                            $ctrl.totalRequests = $ctrl.totalRequests > 0 ? $ctrl.totalRequests - 1 : 0;
                            //if($ctrl.totalCallbacks.length == 0)
                            $ctrl.totalCallbacks.push(callback);
                            if ($ctrl.mapExtent == null) {
                                $ctrl.mapExtent = extent;
                            }
                            else {
                                $ctrl.mapExtent = $ctrl.mapExtent.union(extent);
                            }
                            zoomToExtent();
                        }
                    }, function (error) {
                    });
                });
        };

        // Resets well filters
        function resetWellFilters() {
            turnOffWellFiltersLayer();
            showWellCachelayer();
            setDefaultMapExtent();
        };

        // Function to turn of well layers before applying filters
        function turnOffWellFiltersLayer() {
            var wellMetadataLayerId = WellService.wellMetadataLayerId;
            for (var y = 0; y < WellService.filterMapServiceDetails[wellMetadataLayerId].length; y++) {
                var layer = WellService.filterMapServiceDetails[wellMetadataLayerId][y].layer;
                if (layer) {
                    layer.setVisibility(false);
                }
            }
        };

        // Create where clause for survey filter
        function getSurveyString(surveyIdList) {
            var surveyString = "";
            for (var i = 0; i < surveyIdList.length; i++) {
                if (i == 0)
                    surveyString = "'" + surveyIdList[i] + "'";
                else
                    surveyString = surveyString + "," + "'" + surveyIdList[i] + "'";
            }
            return surveyString;
        }

        // Apply  seismic filters on map.
        function applySeismicFilters(data) {
            var surveyList = getSurveyString(data.SurveyNames);
            hideSeismicCachelayer();
            var surveyString = "SurveyID IN (" + surveyList + ")";
            turnOffSeismicFilterLayer();
            var seismicMetadataLayerId = WellService.seismicSelectionLayerId;
            var seismicSublayers = WellService.filterMapServiceDetails[seismicMetadataLayerId][0].sublayers;
            var layer = WellService.filterMapServiceDetails[seismicMetadataLayerId][0].layer;

            // Added by Kishor to show labels for surveys
            var labelClass = new esri.layers.LabelClass({
                labelExpression: '[' + "SURVEYNAME" + ']',
                labelPlacement: 'esriServerPolygonPlacementAlwaysHorizontal',
                verticalAlignment: "bottom",
                horizontalAlignment: "left",
                angle: 0,
                symbol: WellService.getTextSymbolJson([255, 255, 255, 217], 1, [128, 128, 128, 255], 9),
                minScale: 53957190.948944
            });

            layer.layerDrawingOptions[2].labelingInfo = [labelClass];
            layer.layerDrawingOptions[3].labelingInfo = [labelClass];
            layer.layerDrawingOptions[4].labelingInfo = [labelClass];
            layer.layerDrawingOptions[5].labelingInfo = [labelClass];

            layer.layerDrawingOptions[2].showLabels = true;
            layer.layerDrawingOptions[3].showLabels = true;
            layer.layerDrawingOptions[4].showLabels = true;
            layer.layerDrawingOptions[5].showLabels = true;


            if (layer) {
                if (surveyList != "") {
                    var layerDefinitions = [];
                    for (var j = 0; j < layer.visibleLayers.length; j++) {
                        var defQuery = seismicSublayers[j].definitionExpression + " AND " + surveyString;
                        layerDefinitions[seismicSublayers[j].id] = defQuery;
                    }
                    layer.setLayerDefinitions(layerDefinitions);
                    $scope.$applyAsync(function () {
                        layer.setVisibility(true);
                    });
                    zoomToSurvey(surveyString);//change
                }
                else { //change
                    $ctrl.totalRequests = $ctrl.totalRequests > 0 ? $ctrl.totalRequests - 1 : 0; //change
                } //change
            }
        };

        // Function to turn off Seismic layers
        function turnOffSeismicFilterLayer() {
            var seismicMetadataLayerId = WellService.seismicSelectionLayerId;
            var seismicSublayers = WellService.filterMapServiceDetails[seismicMetadataLayerId][0].sublayers;
            var layer = WellService.filterMapServiceDetails[seismicMetadataLayerId][0].layer;
            if (layer) {
                var layerDefinitions = [];
                for (var j = 0; j < layer.visibleLayers.length; j++) {
                    var defQuery = seismicSublayers[j].definitionExpression + " AND " + WellService.definitionExpression;
                    layerDefinitions[layer.visibleLayers[j]] = defQuery;
                }
                // try {
                //     layer.setVisibility(false);
                // }
                // catch (err) {
                //     console.log(err);
                // }
                // finally {
                //     console.log('finally');
                // }
                layer.setLayerDefinitions(layerDefinitions);
                // if (layer.visible == true)
                layer.setVisibility(false);
            }
        };

        // Resets seismic filters
        function resetSeismicFilters() {
            turnOffSeismicFilterLayer();
            showSeismicCachelayer();
        };

        // Zooms to single survey selected.
        function zoomToSurvey(surveyString, callback) {
            $ctrl.mapExtent = null;
            var seismicSelectionLayer = WellService.filterMapServiceDetails[WellService.seismicSelectionLayerId][0];
            if (seismicSelectionLayer.layer) {
                //var surveyString = "SurveyID IN ('" + surveyID + "')"
                require([
                    "esri/tasks/QueryTask",
                    "esri/tasks/query",
                    "esri/SpatialReference",
                    "dojo/promise/all"
                ], function (QueryTask, Query, SpatialReference, PromiseAll) {
                    var queryTasks = [];
                    var mapLayerIds = []; //change
                    for (var x = 0; x < seismicSelectionLayer.sublayers.length; x++) {
                        if (mapLayerIds.indexOf(seismicSelectionLayer.sublayers[x].source.mapLayerId) < 0)
                            mapLayerIds.push(seismicSelectionLayer.sublayers[x].source.mapLayerId);
                    }
                    for (var y = 0; y < mapLayerIds.length; y++) {
                        var queryTask = new QueryTask(seismicSelectionLayer.layer.url + "/" + mapLayerIds[y]);
                        var query = new Query();
                        query.where = surveyString;
                        query.returnGeometry = false;
                        query.outSpatialReference = new SpatialReference({ wkid: 102100 });
                        var currentTime = Common.getCurrentTime();
                        queryTasks.push(queryTask.executeForExtent(query));
                    }
                    PromiseAll(queryTasks).then(
                        function (response) {
                            //creating log request
                            var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.ZOOM_TO_SURVEY, seismicSelectionLayer.layer.url, Constants.APPLICATION_NAME, $rootScope.userName
                                , Constants.SUCCESS, surveyString, null, null, null, Common.getCurrentDateTime(),
                                Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), null);


                            $http(logReq); //Logging the success request

                            var extent;
                            for (var y = 0; y < response.length; y++) {
                                if (response[y].extent && !isNaN(response[y].extent.xmin)) {
                                    extent = new $ctrl.Extent({
                                        xmin: response[y].extent.xmin,
                                        xmax: response[y].extent.xmax,
                                        ymin: response[y].extent.ymin,
                                        ymax: response[y].extent.ymax,
                                        spatialReference: new SpatialReference({ wkid: 102100 })
                                    });
                                    //break;
                                    if ($ctrl.mapExtent == null) {
                                        $ctrl.mapExtent = extent;
                                    }
                                    else {
                                        $ctrl.mapExtent = $ctrl.mapExtent.union(extent);
                                    }
                                }
                            }
                            $ctrl.totalRequests = $ctrl.totalRequests > 0 ? $ctrl.totalRequests - 1 : 0;
                            // if ($ctrl.mapExtent == null) {
                            //     $ctrl.mapExtent = extent;
                            // }
                            // else {
                            //     $ctrl.mapExtent = $ctrl.mapExtent.union(extent);
                            // }
                            if (callback) {
                                $ctrl.totalCallbacks.push(callback);
                                zoomToExtent();
                            }
                            else
                                zoomToExtent();
                        },
                        function (error) {

                            var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.ZOOM_TO_SURVEY, seismicSelectionLayer.layer.url, Constants.APPLICATION_NAME, $rootScope.userName, Constants.FAILED,
                                surveyString, null, null, null, Common.getCurrentDateTime(),
                                Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), error.message);

                            $http(logReq); //Logging the success request
                        }
                    );
                });
            }
        };

        // This functions is used to zoom to both selected surveys and wells in home page
        function zoomToExtent() {
            if ($ctrl.totalRequests == 0 && $ctrl.mapExtent) {
                $scope.$applyAsync(function () {
                    var extent = $ctrl.mapExtent;

                    var toggleTxt = angular.element(document).find('.tools-section').find('.btn-group').find('label.active').text();
                    if (toggleTxt == 'WELL')
                        $ctrl.mapExtent = null;

                    var resolution = Math.max(extent.getWidth() / $ctrl.map.width, extent.getHeight() / $ctrl.map.height);
                    var zoom = 2;
                    for (var i = 0; i < $ctrl.resolutions.length - 1; i++) {
                        if (resolution < $ctrl.resolutions[i] && resolution > $ctrl.resolutions[i + 1]) {
                            zoom = i > 0 ? i - 1 : 0;
                            break;
                        }
                        else if (resolution == $ctrl.resolutions[i]) {
                            zoom = i > 1 ? i - 2 : 0;
                            break;
                        }
                    }
                    if (zoom < 2)
                        zoom = 2;
                    if (zoom) {
                        if ((extent.xmin == extent.xmax)
                            && (extent.ymin == extent.ymax)) {
                            zoom = 8;
                        }

                        if (window.drawPolygon && window.polygon.wkt != "" && isSingleSurveyClicked == false) {

                            // $ctrl.map.centerAndZoom(polygonFilterGeometry.getExtent().getCenter(), zoom).then(function () {
                            $ctrl.map.centerAndZoom(polygonFilterGeometry.getExtent().getCenter(), zoom + 2).then(function () {
                                for (var j = 0; j < $ctrl.totalCallbacks.length; j++) {
                                    $ctrl.totalCallbacks[j]();
                                }
                                $ctrl.totalCallbacks = [];
                            });
                            //$ctrl.map.setExtent(extent);                            
                        }
                        else {
                            $ctrl.map.centerAndZoom(extent.getCenter(), zoom).then(function () {
                                for (var j = 0; j < $ctrl.totalCallbacks.length; j++) {
                                    $ctrl.totalCallbacks[j]();
                                }
                                $ctrl.totalCallbacks = [];
                            });
                            isSingleSurveyClicked = false;
                        }
                    }
                });
            }
        };

        // This function is used to set the map to default extent when user resets all filters
        function setDefaultMapExtent() {
            if (initialExtent != undefined) {
                if ($ctrl != undefined || $ctrl.map != null || $ctrl.map != undefined)
                    $ctrl.map.setExtent(initialExtent);
            }
            // if($ctrl.view) {
            //     $scope.$applyAsync(function(){
            //         $ctrl.view.goTo($ctrl.mapOptions);
            //     });
            // }
        };

        // Function to assign polygon coords for BBFilter
        $rootScope.setBBCoords = function (BBCoords) {

            var coords = BBCoords.split(",");

            var extent = new $ctrl.Extent(coords[1].trim(), coords[0].trim(),
                coords[3].trim(), coords[2].trim(),
                new $ctrl.SpatialReference({ wkid: 4326 }));

            if (extent.xmin < -180)
                extent.xmin = 360 + extent.xmin;
            else if (extent.xmin > 180)
                extent.xmin = -360 + extent.xmin;

            if (extent.xmax > 180)
                extent.xmax = -360 + extent.xmax;
            else if (extent.xmax < -180)
                extent.xmax = 360 + extent.xmax;

            if (extent.ymin < -90)
                extent.ymin = -90;
            else if (extent.ymin > 90)
                extent.ymin = 90;

            if (extent.ymax > 90)
                extent.ymax = 90;
            else if (extent.ymax < -90)
                extent.ymax = -90;



            var extent1 = $ctrl.webMercatorUtils.geographicToWebMercator(extent);
            // $ctrl.map.setExtent(extent1.offset(-10, 0), true);

            var polygonGeometry = $ctrl.Polygon.fromExtent(extent1);
            polygonFilterGeometry = polygonGeometry;

            var graphic = new $ctrl.Graphic(polygonGeometry, new $ctrl.SimpleFillSymbol($ctrl.polygonSymbol));
            graphic.setAttributes({ "Id": "SearchPolygon" });

            $ctrl.map.graphics.clear();
            $ctrl.map.graphics.add(graphic);

            var geoJson = Terraformer.ArcGIS.parse(polygonGeometry);
            var wkt = geometryToWKT(polygonGeometry);
            var geodata = JSON.stringify(geoJson.toJSON().coordinates);
            window.drawPolygon = true;
            window.geocoorinates = geodata;
            window.polygon = { wkt: wkt, geometry: polygonGeometry, geoJson: geodata };
        }

        // Listens to when well filters are applied.
        $scope.$on("event:applyWellFilters", function (event, data) {
            ClearGraphicsExceptPolygonFltr();
            if (data.filterInfo.length == 1 && data.filterInfo[0].fieldName == "CustomerName")
                return;
            if ($rootScope.selectedValArr.length == 0 && !window.drawPolygon) {
                resetWellFilters();
                if ($rootScope.surveyselectedValArr.length == 0) {
                    resetSeismicFilters();
                    setDefaultMapExtent();
                }
                else {
                    if (data.selectedTab == "SURVEY")
                        hideWellCachelayer();
                }
            }
            else {
                applyWellFilters(data);
                if ($rootScope.surveyselectedValArr.length == 0) {
                    hideSeismicCachelayer();
                }
            }
        });

        // Listens to when seismic filters are applied
        $scope.$on("event:applySeismicFilters", function (event, data) {
            ClearGraphicsExceptPolygonFltr();
            turnOffSeismicHighlightLayer();
            if ($rootScope.surveyselectedValArr.length == 0 && !window.drawPolygon) {
                resetSeismicFilters();
                if ($rootScope.selectedValArr.length == 0) {
                    resetWellFilters();
                    setDefaultMapExtent();
                }
                else {
                    if (data.selectedTab == "WELL")
                        hideSeismicCachelayer();
                }
            }
            else {
                if (window.drawPolygon && window.polygon.wkt != "")
                    getSurveysInPolygon(data);
                else
                    applySeismicFilters(data);
                if ($rootScope.selectedValArr.length == 0) {
                    hideWellCachelayer();
                }
            }
        });

        // Works when all filters are reset
        $scope.$on("event:resetAllFilters", function (event, data) {
            resetWellFilters();
            resetSeismicFilters();
            if ($ctrl.map)
                $ctrl.map.graphics.clear();
            window.drawPolygon = false;
            window.geocoorinates = "";
            window.polygon = { wkt: "", geoJson: "" };
        });

        // Listens to Single Survey click
        $scope.$on("event:zoomToSurvey", function (event, data) {
            ClearGraphicsExceptPolygonFltr();
            isSingleSurveyClicked = true;
            if (data.surveyID && data.surveyID != "") {
                var surveyList = getSurveyString(data.surveyID);
                var surveyString = "SurveyID IN (" + surveyList + ")"
                zoomToSurvey(surveyString, function () {
                    var highlightLayerId = WellService.seismicHighlightLayerId;
                    var layer = WellService.filterMapServiceDetails[highlightLayerId][0].layer;

                    // Added by Kishor to show labels for surveys
                    var labelClass = new esri.layers.LabelClass({
                        labelExpression: '[' + "SURVEYNAME" + ']',
                        labelPlacement: 'esriServerPolygonPlacementAlwaysHorizontal',
                        verticalAlignment: "bottom",
                        horizontalAlignment: "left",
                        angle: 0,
                        symbol: WellService.getTextSymbolJson([255, 255, 255, 217], 1, [128, 128, 128, 255], 9),
                        minScale: 53957190.948944
                    });

                    layer.layerDrawingOptions[0].labelingInfo = [labelClass];
                    layer.layerDrawingOptions[1].labelingInfo = [labelClass];
                    layer.layerDrawingOptions[0].showLabels = true;
                    layer.layerDrawingOptions[1].showLabels = true;

                    if (layer) {
                        var layerDefinitions = [];
                        for (var j = 0; j < layer.visibleLayers.length; j++) {
                            layerDefinitions[layer.visibleLayers[j]] = surveyString;
                        }
                        layer.setLayerDefinitions(layerDefinitions);
                        $scope.$applyAsync(function () {
                            layer.setVisibility(true);
                        });
                    }
                });
            }
            else {
                setDefaultMapExtent();
                turnOffSeismicHighlightLayer();
            }
        });

        //Get single Survey by name in Map - Added By Balaji    
        $scope.$on("event:zoomToSurveyByName", function (event, data) {
            if (data.surveyName && data.surveyName != "") {
                var surveyString = "surveyName IN ('" + data.surveyName + "')"
                zoomToSurvey(surveyString, function () {
                    var highlightLayerId = WellService.seismicHighlightLayerId;
                    var layer = WellService.filterMapServiceDetails[highlightLayerId][0].layer;
                    if (layer) {
                        var layerDefinitions = [];
                        for (var j = 0; j < layer.visibleLayers.length; j++) {
                            layerDefinitions[layer.visibleLayers[j]] = surveyString;
                        }
                        layer.setLayerDefinitions(layerDefinitions);
                        $scope.$applyAsync(function () {
                            layer.visible = true;
                        });
                    }
                });
            }
            else {
                setDefaultMapExtent();
                turnOffSeismicHighlightLayer();
            }
        });

        // Turn off highlighted survyes
        function turnOffSeismicHighlightLayer() {
            var highlightLayerId = WellService.seismicHighlightLayerId;
            var layer = WellService.filterMapServiceDetails[highlightLayerId][0].layer;
            if (layer) {
                var layerDefinitions = [];
                for (var j = 0; j < layer.visibleLayers.length; j++) {
                    layerDefinitions[layer.visibleLayers[j]] = "SurveyID IN ('000000')";
                }
                layer.setLayerDefinitions(layerDefinitions);
                $scope.$applyAsync(function () {
                    layer.setVisibility(false);
                });
            }
        };

        // Listens to when user uploads a shape file
        $scope.$on("event:uploadShapeFile", function (event, data) {
            importShape(data.event);
        });

        // Listens to when user removed polygon filter
        $scope.$on("event:removePolygon", function (event, data) {
            $ctrl.removePolygonFromMap();
        });

        // Hides Well layer on map.
        function hideWellCachelayer() {
            if ($ctrl.map) {
                var wellCacheLayer = $ctrl.map.getLayer(WellService.wellCacheLayerId);
                if (wellCacheLayer) {
                    wellCacheLayer.setVisibility(false);
                }
            }
        };

        // Hides Seismic layer on map
        function hideSeismicCachelayer() {
            if ($ctrl.map) {
                var seismicCacheLayer = $ctrl.map.getLayer(WellService.seismicCacheLayerId);
                if (seismicCacheLayer == undefined) {
                    RemoveProjectLayers();
                    addLayersToMap();
                }

                seismicCacheLayer = $ctrl.map.getLayer(WellService.seismicCacheLayerId);
                if (seismicCacheLayer) {
                    seismicCacheLayer.setVisibility(false);
                }
            }
        };

        // Shows Well Layer on map
        function showWellCachelayer() {
            if ($ctrl.map) {
                var wellCacheLayer = $ctrl.map.getLayer(WellService.wellCacheLayerId);
                if (wellCacheLayer) {
                    wellCacheLayer.setVisibility(true);
                }
            }
        };

        // Shows seismic layer on map
        function showSeismicCachelayer() {
            if ($ctrl.map) {
                var seismicCacheLayer = $ctrl.map.getLayer(WellService.seismicCacheLayerId);
                if (seismicCacheLayer) {
                    seismicCacheLayer.setVisibility(true);
                }
            }
        };

        // Imports shapes on map.
        function importShape(event) {
            var fileName = event.target.value.toLowerCase();
            if ($ctrl.sniff("ie")) { //filename is full path in IE so extract the file name
                var arr = fileName.split("\\");
                fileName = arr[arr.length - 1];
            }
            if (fileName.indexOf(".zip") !== -1) {//is file a zip - if not notify user
                if (event.target.files[0].size <= 10000) {
                    generateFeatures(event.target.files[0], fileName);
                    document.getElementById('file-input').value = "";
                    if (angular.element('.mapappliedgrp').hasClass('hide'))
                        $('.mapappliedgrp').removeClass('hide');
                } else {
                    $.alertable.alert("Size of selected file is larger than allowed size of 10 MB.")
                    return false;
                }
            }
            else {
                $.alertable.alert("Choose zip file only.")
                return false;
            }
        };

        // Gets features from shape file uploaded.
        function generateFeatures(zipFile, fileName) {
            var name = fileName.split(".");
            //Chrome and IE add c:\fakepath to the value - we need to remove it
            name = name[0].replace("c:\\fakepath\\", "");
            var fileReader = new FileReader();
            fileReader.onload = function (fileLoadedEvent) {
                var dataURI = fileLoadedEvent.target.result;
                dataURI = dataURI.replace("data:application/x-zip-compressed;base64,", "");

                var params = {
                    'name': name,
                    // 'targetSR': $ctrl.view.spatialReference,
                    'targetSR': $ctrl.map.spatialReference,
                    'maxRecordCount': 1000,
                    'enforceInputFileSizeLimit': true,
                    'enforceOutputJsonSizeLimit': true
                };
                params.generalize = false;
                // params.maxAllowableOffset = $ctrl.view.resolution;
                params.maxAllowableOffset = $ctrl.map.getResolution();
                params.reducePrecision = false;
                params.numberOfDigitsAfterDecimal = 4;
                var form = new FormData();
                form.append("publishParameters", JSON.stringify(params));
                form.append("filetype", "shapefile");
                form.append("f", "json");
                let zipName = name = ".zip";
                form.append("file", dataURIToBlob(dataURI), zipName);
                var featRequest = $ctrl.EsriRequest({
                    url: 'https://www.arcgis.com/sharing/rest/content/features/generate',
                    form: form,
                    usePost: true
                });
                featRequest.then(
                    function (response) {
                        showShapesOnMap(response);
                    }, function (error) {

                    });
            };
            fileReader.readAsDataURL(zipFile);
        };

        // Shows uploaded shapes on map.
        function showShapesOnMap(response) {
            if (response.featureCollection.layers[0].featureSet.features.length > 0) {

                if (response.featureCollection.layers[0].layerDefinition.geometryType === "esriGeometryPolygon") {
                    var featureCollectionObj = response.featureCollection.layers[0];
                    var geometries = [];
                    if (featureCollectionObj.featureSet.features.length <= 100) {
                        var geom = featureCollectionObj.featureSet.features[0].geometry;
                        var polygonGeometry;
                        if (featureCollectionObj.featureSet.features.length > 1) {
                            $.alertable.alert("Multi polygon not supported. Please upload single polygon.");
                            return false;
                        }
                        else {
                            if (geom.rings.length > 1) {
                                $.alertable.alert("Multi polygon not supported. Please upload single polygon.");
                                return false;
                            }

                            $ctrl.map.graphics.clear();

                            var polygonShape = {
                                type: "polygon", // autocasts as Polygon
                                rings: geom.rings,
                                spatialReference: geom.spatialReference
                            };
                            var graphic = new $ctrl.Graphic({
                                geometry: polygonShape,
                                symbol: $ctrl.polygonSymbol,
                                attributes: { "Id": "SearchPolygon" }
                            });

                            geometries.push(graphic.geometry);
                            $ctrl.map.graphics.add(graphic);
                            polygonGeometry = graphic.geometry;
                        }

                        var geoJson = Terraformer.ArcGIS.parse(polygonGeometry);
                        var geodata = JSON.stringify(geoJson.toJSON().coordinates);
                        var wkt = geometryToWKT(polygonGeometry);
                        window.drawPolygon = true;
                        window.geocoorinates = geodata;
                        window.polygon = { wkt: wkt, geometry: polygonGeometry, geoJson: geodata };
                        if (angular.element('.mapappliedgrp').hasClass('hide'))
                            $('.mapappliedgrp').removeClass('hide');
                        $ctrl.totalRequests = 2;
                        $rootScope.$broadcast("event:surveyPolygonDraw", {});
                        $rootScope.$broadcast("event:wellPolygonDraw", {});
                    }
                } else {
                    $.alertable.alert("Only polygon shapes are allowed.");
                    return false;
                }
            }
        };

        // Initiates polygon drawing on map        
        $ctrl.initPolygonDraw = function () {
            ClearPolyGonFilterGraphics();
            if (idDetail == false)
                ClearGraphicsExceptPolygonFltr();
            isDrawing = true;
            $ctrl.drawTool.activate($ctrl.Draw.POLYGON);
            document.getElementById("viewDiv_container").style.cursor = "crosshair";
        }

        // This functions gets executed on completion of polygon drawing
        $ctrl.polygonDrawComplete = function (evt) {
            document.getElementById("viewDiv_container").style.cursor = "default";
            $ctrl.drawTool.deactivate();
            setActive(false, "polygonButton");
            polygonFilterGeometry = evt.geometry;
            var polygonGeometry = createPolygonGraphic(evt);
            if (polygonGeometry.isSelfIntersecting()) {
                $.alertable.alert("Multi polygon not supported. Please draw single polygon.");
                $ctrl.map.graphics.clear();
                return false;
            }
            // Below code works when user is in detail page
            if (idDetail == true) {
                angular.element('.mapSidepanel').hide();
                var geoJson = Terraformer.ArcGIS.parse(polygonGeometry);
                var wkt = geometryToWKT(polygonGeometry);
                var geodata = JSON.stringify(geoJson.toJSON().coordinates);
                window.drawPolygon = true;
                window.geocoorinates = geodata;
                window.polygon = { wkt: wkt, geometry: polygonGeometry, geoJson: geodata };


                polygonFilterGeometry = evt.geometry;
                $ctrl.map.setExtent(evt.geometry.getExtent());
                isDrawing = false;

                if ($rootScope.curTab !== undefined && $rootScope.curTab !== "") {
                    //alert($rootScope.curTab);
                    if ($rootScope.curTab == "SEGY") {

                        $rootScope.seismicSegYtab();
                    }
                    if ($rootScope.curTab == "Horizon") {

                        $rootScope.seismicHorizontab();
                    }
                    else if ($rootScope.curTab === "Velocity") {
                        $rootScope.seismicVelocitytab();

                    }
                    else if ($rootScope.curTab === "GravMag") {
                        $rootScope.seismicGravMagtab();
                    }
                    else if ($rootScope.curTab === "AeroMag") {
                        $rootScope.seismicAeroMagtab();
                    }
                    else if ($rootScope.curTab == "Spec Sheets") {

                        $rootScope.seismicSpecSheettab();
                    }
                    else if ($rootScope.curTab == "LAS") {

                        $rootScope.wellLastab();
                    }
                    else if ($rootScope.curTab == "Production") {

                        $rootScope.welproductiontab();
                    }
                    else if ($rootScope.curTab == "Raster") {

                        $rootScope.wellRastertab();
                    }
                    else if ($rootScope.curTab == "VWH") {
                        $rootScope.wellVWHtab();
                    }
                    else if ($rootScope.curTab === "WellFile") {
                        $rootScope.wellWFtab();

                    }
                    else if ($rootScope.curTab === "InterpretiveDocLibrary") {
                        $rootScope.interdoclibtab();

                    }
                    else if ($rootScope.curTab === "interpretivePWA") {
                        $rootScope.interpretivePWATab();

                    }
                    else if ($rootScope.curTab === "InterpretiveLas") {
                        $rootScope.interpretiveLasTab();

                    }
                    else if ($rootScope.curTab === "interpretiveDSDP") {
                        $rootScope.interpretiveDSDPTab();

                    }


                    else if ($rootScope.curTab === "BioStratTops") {
                        $rootScope.interbiostrattop();

                    }
                    else if ($rootScope.curTab === "ChronoStratTops") {
                        $rootScope.interchronostrattop();

                    }
                    else if ($rootScope.curTab === "CoreTops") {
                        $rootScope.interCoreTops();

                    }
                    else if ($rootScope.curTab === "EnvFaciesTops") {
                        $rootScope.interEnvFaciesTops();
                    }
                    else if ($rootScope.curTab === "LithoStratTops") {
                        $rootScope.interLithoStratTops();

                    }
                    else if ($rootScope.curTab === "LithologyTops") {
                        $rootScope.interLithologyTops();

                    }
                    else if ($rootScope.curTab === "MaturityTypeTops") {
                        $rootScope.interMaturitytypetop();

                    }
                    else if ($rootScope.curTab === "RockEvaluationTops") {
                        $rootScope.interrockevaluationtop();

                    }
                    else if ($rootScope.curTab === "SequenceStratTops") {
                        $rootScope.intersequencestrattop();

                    }
                    else if ($rootScope.curTab === "Showtops") {
                        $rootScope.interShowtop();

                    }
                    else if ($rootScope.curTab === "VisualMaceralTops") {
                        $rootScope.intervisualmaceraltop();

                    }
                }

                if (angular.element('.mapappliedgrp').hasClass('hide'))
                    $('.mapappliedgrp').removeClass('hide');
                $rootScope.showAppliedtxt();
                return;
            }

            var geoJson = Terraformer.ArcGIS.parse(polygonGeometry);
            var wkt = geometryToWKT(polygonGeometry);
            var geodata = JSON.stringify(geoJson.toJSON().coordinates);
            window.drawPolygon = true;
            window.geocoorinates = geodata;
            window.polygon = { wkt: wkt, geometry: polygonGeometry, geoJson: geodata };
            if (angular.element('.mapappliedgrp').hasClass('hide'))
                $('.mapappliedgrp').removeClass('hide');
            $ctrl.totalRequests = 2;
            $rootScope.$broadcast("event:surveyPolygonDraw", {});
            $rootScope.$broadcast("event:wellPolygonDraw", {});
            isDrawing = false;
            $rootScope.showAppliedtxt();

        };

        // Adds polygon on map.
        function createPolygonGraphic(evt) {
            $ctrl.map.graphics.clear();

            var graphic = new $ctrl.Graphic(evt.geometry, new $ctrl.SimpleFillSymbol($ctrl.polygonSymbol));
            graphic.setAttributes({ "Id": "SearchPolygon" });

            $ctrl.map.graphics.add(graphic);

            return evt.geographicGeometry;
        };

        // Toggles the state of button. 
        function setActive(isActive, elementId) {
            $scope.$applyAsync(function () {
                elementId = "#" + elementId;

                if (isActive) {
                    // element.classList.add("polyactive");
                    angular.element(document).find(elementId).addClass("polyactive");
                }
                else {
                    // element.classList.remove("polyactive");
                    angular.element(document).find(elementId).removeClass("polyactive");
                }
            });
        }

        // Removes polygon graphic from map.
        $ctrl.removePolygonFromMap = function () {
            if (idDetail == true && $rootScope.filterNameGroup == "Seismic")
                angular.element('.mapSidepanel').hide();

            if (document.getElementById("viewDiv_container"))
                document.getElementById("viewDiv_container").style.cursor = "default";
            ClearPolyGonFilterGraphics();
            polygonFilterGeometry = undefined;
            window.drawPolygon = false;
            window.geocoorinates = "";
            window.polygon = { wkt: "", geoJson: "" };
            if (!angular.element('.mapappliedgrp').hasClass('hide'))
                $('.mapappliedgrp').addClass('hide');

            if (idDetail == true && $rootScope.curTab !== undefined && $rootScope.curTab !== "") {
                if ($rootScope.isResetAllFilter) {
                    $rootScope.showAppliedtxt();
                    setActive(false, "resetBtn");
                    $rootScope.isResetAllFilter = false;
                    return;
                }
                if ($rootScope.curTab == "SEGY") {

                    $rootScope.seismicSegYtab();
                }
                if ($rootScope.curTab == "Horizon") {

                    $rootScope.seismicHorizontab();
                }
                else if ($rootScope.curTab === "Velocity") {
                    $rootScope.seismicVelocitytab();

                }
                else if ($rootScope.curTab === "GravMag") {
                    $rootScope.seismicGravMagtab();
                }
                else if ($rootScope.curTab === "AeroMag") {
                    $rootScope.seismicAeroMagtab();
                }
                else if ($rootScope.curTab == "Spec Sheets") {

                    $rootScope.seismicSpecSheettab();
                }
                else if ($rootScope.curTab == "LAS") {

                    $rootScope.wellLastab();
                }
                else if ($rootScope.curTab == "Production") {

                    $rootScope.welproductiontab();
                }
                else if ($rootScope.curTab == "Raster") {

                    $rootScope.wellRastertab();
                }
                else if ($rootScope.curTab == "VWH") {

                    $rootScope.wellVWHtab();
                }
                else if ($rootScope.curTab === "WellFile") {
                    $rootScope.wellWFtab();

                }
                else if ($rootScope.curTab === "InterpretiveDocLibrary") {
                    $rootScope.interdoclibtab();

                }
                else if ($rootScope.curTab === "interpretivePWA") {
                    $rootScope.interpretivePWATab();

                }
                else if ($rootScope.curTab === "InterpretiveLas") {
                    $rootScope.interpretiveLasTab();

                }
                else if ($rootScope.curTab === "interpretiveDSDP") {
                    $rootScope.interpretiveDSDPTab();
                }

                else if ($rootScope.curTab === "BioStratTops") {
                    $rootScope.interbiostrattop();

                }
                else if ($rootScope.curTab === "ChronoStratTops") {
                    $rootScope.interchronostrattop();

                }
                else if ($rootScope.curTab === "CoreTops") {
                    $rootScope.interCoreTops();

                }
                else if ($rootScope.curTab === "EnvFaciesTops") {
                    $rootScope.interEnvFaciesTops();
                }
                else if ($rootScope.curTab === "LithoStratTops") {
                    $rootScope.interLithoStratTops();

                }
                else if ($rootScope.curTab === "LithologyTops") {
                    $rootScope.interLithologyTops();

                }
                else if ($rootScope.curTab === "MaturityTypeTops") {
                    $rootScope.interMaturitytypetop();

                }
                else if ($rootScope.curTab === "RockEvaluationTops") {
                    $rootScope.interrockevaluationtop();

                }
                else if ($rootScope.curTab === "SequenceStratTops") {
                    $rootScope.intersequencestrattop();

                }
                else if ($rootScope.curTab === "Showtops") {
                    $rootScope.interShowtop();

                }
                else if ($rootScope.curTab === "VisualMaceralTops") {
                    $rootScope.intervisualmaceraltop();

                }
                $rootScope.showAppliedtxt();
                setActive(false, "resetBtn");
                return;
            }

            $rootScope.$broadcast("event:surveyPolygonDraw", {});
            $rootScope.$broadcast("event:wellPolygonDraw", {});

            applyWellFilters({ filterInfo: $rootScope.selectedFieldsDetails });

            $rootScope.showAppliedtxt();
            setActive(false, "resetBtn");

        }

        // Converts zip file as dataURI to blob
        function dataURIToBlob(dataURI) {
            var array = [];
            if (dataURI instanceof Array) {
                array = dataURI;
            }
            else {
                var binary = atob(dataURI);
                for (var i = 0; i < binary.length; i++) {
                    array.push(binary.charCodeAt(i));
                }
            }
            return new Blob([new Uint8Array(array)], { type: 'application/zip' });
        }

        // Converts ESRI ArcGIS geometry to Well Known Text
        function geometryToWKT(geometry) {
            var geoJson = Terraformer.ArcGIS.parse(geometry);
            var wkt = Terraformer.WKT.convert(geoJson);
            return wkt;
        }

        // Filters Surveys based on shape uploaded or drawn on map
        function getSurveysInPolygon(data) {
            polygonFilterGeometry = window.polygon.geometry;
            var seismicSelectionLayer = WellService.filterMapServiceDetails[WellService.seismicMetadataLayerId][0];
            if (seismicSelectionLayer.layer) {
                require([
                    "esri/tasks/QueryTask",
                    "esri/tasks/query",
                    "esri/SpatialReference",
                    "dojo/promise/all"
                ], function (QueryTask, Query, SpatialReference, PromiseAll) {
                    var queryTasks = [];
                    for (var x = 0; x < seismicSelectionLayer.sublayers.length; x++) {
                        var queryTask = new QueryTask(seismicSelectionLayer.layer.url + "/" + seismicSelectionLayer.sublayers[x].id);
                        var query = new Query();
                        query.where = "1=1";
                        query.returnGeometry = false;
                        query.geometry = window.polygon.geometry;
                        query.outFields = ["SurveyID"];
                        query.outSpatialReference = new SpatialReference({ wkid: 102100 });
                        var currentTime = Common.getCurrentTime();
                        queryTasks.push(queryTask.execute(query));
                    }
                    PromiseAll(queryTasks).then(
                        function (response) {
                            //creating log request
                            var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.GET_SURVEY_IN_POLYGON, seismicSelectionLayer.layer.url, Constants.APPLICATION_NAME, $rootScope.userName
                                , Constants.SUCCESS, null, null, window.polygon.geoJson, null, Common.getCurrentDateTime(),
                                Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), null);

                            $http(logReq); //Logging the success request

                            var surveyList = [];
                            for (var y = 0; y < response.length; y++) {
                                if (response[y].features.length > 0) {
                                    var features = response[y].features;
                                    for (var z = 0; z < features.length; z++) {
                                        surveyList.push(features[z].attributes["SurveyID"]);
                                    }
                                }
                            }
                            if ($rootScope.surveyselectedValArr.length == 0) {
                                data.SurveyNames = surveyList;
                            }
                            else {
                                data.SurveyNames = surveyList.filter(function (n) {
                                    return window.mapallSurveyname.indexOf(n) != -1
                                });
                            }
                            applySeismicFilters(data, false);
                        },
                        function (error) {
                            var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.GET_SURVEY_IN_POLYGON, seismicSelectionLayer.layer.url, Constants.APPLICATION_NAME, $rootScope.userName, Constants.FAILED,
                                null, null, window.polygon.geoJson, null, Common.getCurrentDateTime(),
                                Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), error.message);

                            $http(logReq); //Logging the success request
                        }
                    );
                });
            }
        }



        // Function to find out current Tab and Module in UI
        function getTabAndModuleName() {
            var tabName;
            var moduleName;

            if ($rootScope.filterNameForNavigation == "WELLS") {
                moduleName = "Well";
                if ($rootScope.curTab) {
                    if ($rootScope.curTab == "LAS")
                        tabName = "Las"
                    else
                        tabName = $rootScope.curTab;
                }
                else
                    tabName = "Las";
            }
            else if ($rootScope.filterNameForNavigation == "INTERPRETIVE") {
                moduleName = "Interpretive";

                if ($rootScope.curTab) {
                    if ($rootScope.curTab == "InterpretiveLas")
                        tabName = "FmbLas"
                    else if ($rootScope.curTab == "InterpretiveDocLibrary")
                        tabName = "DocLib"
                    else if ($rootScope.curTab == "interpretiveDSDP")
                        tabName = "DSDP";
                    else if ($rootScope.curTab == "interpretivePWA")
                        tabName = "PWA";
                    else
                        tabName = $rootScope.curTab;
                }
                else
                    tabName = "FmbLas";
            }

            if ($rootScope.curTab == "EnvFaciesTops")
                tabName = "EnvironmentFaciesTops";

            if ($rootScope.curTab == "Showtops")
                tabName = "ShowTops";

            return [tabName, moduleName];
        }

        // This function will get wells count and other data based on bounding box
        function GetWellsCount(gridExtent, extent, wellFilterObject, callback) {

            var tabName;
            var moduleName;
            $rootScope.map = $ctrl.map;

            var vals = getTabAndModuleName();
            tabName = vals[0];
            moduleName = vals[1];

            //  var getWellsCountUrl = WellService.urlValue + "getMapDetailInfo?tabName=" + tabName + "&module=" + moduleName + wellFilter + "&coordinates=" + gridExtent;

            var filterStringInfo = "";
            if (wellFilterObject.metaDataFilter !== "" && wellFilterObject.geoSpaFilter == "")
                filterStringInfo = wellFilterObject.metaDataFilter
            else if (wellFilterObject.metaDataFilter == "" && wellFilterObject.geoSpaFilter !== "") {
                filterStringInfo = wellFilterObject.geoSpaFilter;
            }
            else if (wellFilterObject.geoSpaFilter !== "" && wellFilterObject.metaDataFilter !== "")
                filterStringInfo = wellFilterObject.metaDataFilter + wellFilterObject.geoSpaFilter;

            var paramInfo = {
                tabName: tabName,
                module: moduleName,
                filterStr: filterStringInfo,
                coordinates: gridExtent,
                customerId: wellFilterObject.customFilter,
                pdfFilterStr: wellFilterObject.pdfFilterStr,
                queryBuilderStr: wellFilterObject.qbStr,
                uuid: wellFilterObject.uuid,
                requestTimestamp: Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken

            }
            paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
            paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
            paramInfo.pdfFilterStr == "" || paramInfo.pdfFilterStr == undefined ? delete paramInfo.pdfFilterStr : paramInfo.pdfFilterStr;
            paramInfo.queryBuilderStr == "" || paramInfo.queryBuilderStr == undefined ? delete paramInfo.queryBuilderStr : paramInfo.queryBuilderStr;
            paramInfo.uuid == "" || paramInfo.uuid == undefined ? delete paramInfo.uuid : paramInfo.uuid;
            paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
            paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

            var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent
            var request = {
                method: 'POST',
                url: Common.urlValue + Common.getMapDetailInfo,
                data: paramInfoList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }

            $http(request).
                then(function (response) {

                    if (idDetail == false)
                        return;

                    if ($rootScope.filterNameGroup == "Seismic") {
                        RemoveGraphics();
                        angular.element(document.body).find('.mapoverlay').remove();
                        return;
                    }

                    var wellCount = response.data.wellsCount;
                    addGraphic(response.data, extent, tabName);
                    // RemoveAllLayers(true);

                    setTimeout(function () {
                        angular.element(document.body).find('#overlay').remove();
                    }, 1500);
                }).catch(function (response) {
                    angular.element(document.body).find('#overlay').remove();
                    Common.redirectToCore(response);
                });
        }
        // Function to get actual well coordinates and draw it on map at zoom level greater than 8

        function GetWells(wellFilterObject, callback) {
            $ctrl.map.infoWindow.hide();
            RemoveGraphics();

            var tabName;
            var moduleName;
            $rootScope.map = $ctrl.map;

            var vals = getTabAndModuleName();
            tabName = vals[0];
            moduleName = vals[1];

            // use map extent as base screen to split it
            var extent = $ctrl.map.geographicExtent;

            if (extent.xmin < -180)
                extent.xmin = 360 + extent.xmin;
            else if (extent.xmin > 180)
                extent.xmin = -360 + extent.xmin;

            if (extent.xmax > 180)
                extent.xmax = -360 + extent.xmax;
            else if (extent.xmax < -180)
                extent.xmax = 360 + extent.xmax;

            if (extent.ymin < -90)
                extent.ymin = -90;
            else if (extent.ymin > 90)
                extent.ymin = 90;

            if (extent.ymax > 90)
                extent.ymax = 90;
            else if (extent.ymax < -90)
                extent.ymax = -90;


            // Prepare extent input for web service
            var gridExt = extent.ymax + ',' + extent.xmin + ',' + extent.ymin + ',' + extent.xmax;

            var filterStringInfo = "";
            if (wellFilterObject.metaDataFilter !== "" && wellFilterObject.geoSpaFilter == "")
                filterStringInfo = wellFilterObject.metaDataFilter
            else if (wellFilterObject.metaDataFilter == "" && wellFilterObject.geoSpaFilter !== "") {
                filterStringInfo = wellFilterObject.geoSpaFilter;
            }
            else if (wellFilterObject.geoSpaFilter !== "" && wellFilterObject.metaDataFilter !== "")
                filterStringInfo = wellFilterObject.metaDataFilter + wellFilterObject.geoSpaFilter;

            var paramInfo = {
                tabName: tabName,
                module: moduleName,
                filterStr: filterStringInfo,
                boundingMap: "true",
                coordinates: gridExt,
                customerId: wellFilterObject.customFilter,
                queryBuilderStr: wellFilterObject.qbStr,
                uuid: wellFilterObject.uuid,
                requestTimestamp: Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }
            paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
            paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
            paramInfo.queryBuilderStr == "" || paramInfo.queryBuilderStr == undefined ? delete paramInfo.queryBuilderStr : paramInfo.queryBuilderStr;
            paramInfo.uuid == "" || paramInfo.uuid == undefined ? delete paramInfo.uuid : paramInfo.uuid;
            paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
            paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;
            var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent
            var request = {
                method: 'POST',
                url: Common.urlValue + Common.getMapDetailInfo,
                data: paramInfoList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }


            $http(request).
                then(function (response) {
                    var wellData = response.data;
                    var i = 0;

                    if (response.data !== undefined) {
                        angular.forEach(wellData, function (value) {
                            if (i > 100)
                                return;
                            var wellX = value.split(",")[0].replace("[", "");
                            var wellY = value.split(",")[1].replace("]", "");
                            addWellGraphic(wellX, wellY);
                            i++;
                        });
                    }

                    setTimeout(function () {
                        angular.element(document.body).find('#overlay').remove();
                    }, 1500);
                }).catch(function (response) {
                    angular.element(document.body).find('#overlay').remove();
                    Common.redirectToCore(response);
                });
        }
        // This function is being called from all wells controllers for cluster creation
        $rootScope.GenerateGrds = function (metaDataFilter, geoSpaFilter, qbStr, uuid, customFilter, pdfFilterStr) {

            var wellFilterObj = {
                metaDataFilter: metaDataFilter,
                geoSpaFilter: geoSpaFilter,
                qbStr: qbStr,
                uuid: uuid,
                customFilter: customFilter,
                pdfFilterStr: pdfFilterStr
            }
            var wellFilter = wellFilterObj;

            //Hide all seismic layers
            projectLayer.setVisibility(false);
            entAreaLayer.setVisibility(false);
            nonEntAreaLayer.setVisibility(false);
            singleProjectLayer.setVisibility(false);

            allWellUIFilter = wellFilter;
            //&customerId=
            $ctrl.map.infoWindow.hide();
            idDetail = true;
            // $rootScope.isSeismic = false;
            ClearGraphicsExceptPolygonFltr();
            // Remove all sesimic and well layers from home page
            RemoveAllLayers();

            $ctrl.dWellFilter = wellFilter;

            if (metaDataFilter == "" && geoSpaFilter == "" && qbStr == ""
                && uuid == "" && customFilter == "" && pdfFilterStr == "") {
                $ctrl.map.setExtent(initialExtent);
                polygonFilterGeometry = undefined;
                addCountryLevelCluster();
                return;
            }


            if ($rootScope.BBFilter == true) {
                if (angular.element('.mapappliedgrp').hasClass('hide'))
                    $('.mapappliedgrp').removeClass('hide');
                $rootScope.showAppliedtxt();
                $rootScope.BBFilter = false;
            }
            // Else get bounding box for filtered data            
            GetBBForClusters(metaDataFilter, geoSpaFilter, qbStr, uuid, customFilter, pdfFilterStr);
        }

        $rootScope.GetBBForWells = function (wellUrl) {
            GetExtentForWells(wellUrl);
        }
        // This function gets the bounding box for data filtered
        function GetBBForClusters(metaDataFilter, geoSpaFilter, qbStr,
            uuid, customFilter, pdfFilterStr, callback) {
            var tabName;
            var moduleName;
            isCallFromBBService = false;

            var filterStringInfo = "";
            if (metaDataFilter !== "" && geoSpaFilter == "")
                filterStringInfo = metaDataFilter
            else if (metaDataFilter == "" && geoSpaFilter !== "") {
                filterStringInfo = geoSpaFilter;
            }
            else if (geoSpaFilter !== "" && metaDataFilter !== "")
                filterStringInfo = metaDataFilter + geoSpaFilter;


            var wellFilterObj = {
                metaDataFilter: metaDataFilter,
                geoSpaFilter: geoSpaFilter,
                qbStr: qbStr,
                uuid: uuid,
                customFilter: customFilter,
                pdfFilterStr: pdfFilterStr
            }

            var vals = getTabAndModuleName();
            tabName = vals[0];
            moduleName = vals[1];

            var paramInfo = {
                tabName: tabName,
                module: moduleName,
                filterStr: filterStringInfo,
                queryBuilderStr: qbStr,
                uuid: uuid,
                pdfFilterStr: pdfFilterStr,
                // customerId: customFilter,  //Remove customer Filter for boungingbox                 
                customerId: "",
                pdfFilterStr: pdfFilterStr,
                boundingCoordinates: "true",
                requestTimestamp: Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }
            paramInfo.filterStr == "" || paramInfo.filterStr == undefined ? delete paramInfo.filterStr : paramInfo.filterStr;
            paramInfo.queryBuilderStr == "" || paramInfo.queryBuilderStr == undefined ? delete paramInfo.queryBuilderStr : paramInfo.queryBuilderStr;
            paramInfo.uuid == "" || paramInfo.uuid == undefined ? delete paramInfo.uuid : paramInfo.uuid;
            paramInfo.customerId == "" || paramInfo.customerId == undefined ? delete paramInfo.customerId : paramInfo.customerId;
            paramInfo.pdfFilterStr == "" || paramInfo.pdfFilterStr == undefined ? delete paramInfo.pdfFilterStr : paramInfo.pdfFilterStr;
            paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
            paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;


            var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent
            var request = {
                method: 'POST',
                url: Common.urlValue + Common.getMapDetailInfo,
                data: paramInfoList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }

            $http(request).then(function (response) {

                if (response.data == "") {
                    angular.element(document.body).find('#overlay').remove();
                    return;
                }

                if (response.data.Xmin == '0.0' && response.data.Xmax == '0.0'
                    && response.data.Ymin == '0.0' && response.data.Ymax == '0.0')
                    return;

                var extent;
                var circlePoint;
                // handling single wells returned from service
                if ((response.data.Xmin == response.data.Xmax)
                    && (response.data.Ymin == response.data.Ymax)) {

                    circlePoint = new $ctrl.Point();
                    circlePoint.setLatitude(response.data.Xmin);
                    circlePoint.setLongitude(response.data.Ymin);

                    $ctrl.map.centerAndZoom(circlePoint, 9);
                }
                else {
                    extent = new $ctrl.Extent(response.data.Ymax, response.data.Xmin,
                        response.data.Ymin, response.data.Xmax,
                        new $ctrl.SpatialReference({ wkid: 4326 }));
                    extent = $ctrl.webMercatorUtils.geographicToWebMercator(extent);
                    $ctrl.map.setExtent(extent.offset(-10, 0), true);
                }

                if (customFilter != "" && extent == undefined && circlePoint == undefined) {
                    GenerateGrids(wellFilterObj);
                    return;
                }

                //if ((wellFilterObj) == "")
                if (metaDataFilter == "" && geoSpaFilter == "" && qbStr == ""
                    && uuid == "" && customFilter == "" && pdfFilterStr == "")
                    // && uuid == "" && pdfFilterStr == "")
                    GenerateGrids(wellFilterObj);

                setTimeout(function () {
                    angular.element(document.body).find('#overlay').remove();
                }, 1500);
            }).catch(function (response) {
                angular.element(document.body).find('#overlay').remove();
                Common.redirectToCore(response);
            });
        }
        // Function to split the screen in rectangles and call service to get wells data

        function GenerateGrids(wellFilterObject) {
            $ctrl.map.infoWindow.hide();
            RemoveGraphics();
            RemoveAllLayers();

            if ($ctrl.map.getLevel() == 2 && (wellFilterObject.metaDataFilter == "" && wellFilterObject.geoSpaFilter == "" && wellFilterObject.qbStr == ""
                && wellFilterObject.uuid == "" && wellFilterObject.customFilter == "" && wellFilterObject.pdfFilterStr == "")) {
                polygonFilterGeometry = undefined;
                addCountryLevelCluster();
                return;
            }

            // angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            // Use map width and hieight to find number of grids
            var gridWidth = 128; // Greater this value lesser the number of grids
            var gridXCount = parseInt($ctrl.map.width / gridWidth);
            if ($ctrl.map.width % gridWidth > 0)
                gridXCount += 1;

            var gridYCount = parseInt($ctrl.map.height / gridWidth);
            if ($ctrl.map.height % gridWidth > 0)
                gridYCount += 1;

            for (var x = 0; x < gridXCount; x++) {
                for (var y = 0; y < gridYCount; y++) {
                    var screenExt = new $ctrl.Extent(x * gridWidth, (y + 1) * gridWidth, (x + 1) * gridWidth, y * gridWidth);
                    var extent = $ctrl.ScreenUtils.toMapGeometry($ctrl.map.geographicExtent, $ctrl.map.width, $ctrl.map.height, screenExt);

                    if (extent.xmin < -180)
                        extent.xmin = 360 + extent.xmin;
                    else if (extent.xmin > 180)
                        extent.xmin = -360 + extent.xmin;

                    if (extent.xmax > 180)
                        extent.xmax = -360 + extent.xmax;
                    else if (extent.xmax < -180)
                        extent.xmax = 360 + extent.xmax;

                    if (extent.ymin < -90)
                        extent.ymin = -90;
                    else if (extent.ymin > 90)
                        extent.ymin = 90;

                    if (extent.ymax > 90)
                        extent.ymax = 90;
                    else if (extent.ymax < -90)
                        extent.ymax = -90;

                    var gridExt = extent.ymax + ',' + extent.xmin + ',' + extent.ymin + ',' + extent.xmax;

                    GetWellsCount(gridExt, extent, wellFilterObject, function (wellCount) {
                        //WellCnt = wellCount;
                    });
                }
            }
            // angular.element(document.body).find('.mapoverlay').remove();
        }

        // Function to add well graphics to map
        function addWellGraphic(x, y) {
            var wellSymbol = new esri.symbol.SimpleMarkerSymbol(
                esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
                15,
                new esri.symbol.SimpleLineSymbol(
                    esri.symbol.SimpleLineSymbol.STYLE_NULL,
                    new dojo.Color([0, 0, 0, 1]),
                    1
                ),
                new dojo.Color([255, 69, 0, 0.65]));

            var wellPnt = new $ctrl.Point();
            wellPnt.setLatitude(y);
            wellPnt.setLongitude(x);

            var wellGraphic = new $ctrl.Graphic(wellPnt);
            wellGraphic.setSymbol(wellSymbol);
            $ctrl.map.graphics.add(wellGraphic);
        }

        // Function to add cluster graphics to map
        function addGraphic(data, extent, tabName) {

            var wellCount = data.wellsCount;

            var clusterPnt = new $ctrl.Point();
            clusterPnt.setLatitude(data.centroid_Latitude);
            clusterPnt.setLongitude(data.centroid_Longitude);

            // if (polygonFilterGeometry != undefined && polygonFilterGeometry.contains(clusterPnt) == false)
            //     return;

            if (wellCount == 0)
                return;

            var symbolUrl = "img/";

            //Below is the symbol bank based on number of wells
            var symbolBank = {
                "single": new esri.symbol.SimpleMarkerSymbol(
                    esri.symbol.SimpleMarkerSymbol.STYLE_CIRCLE,
                    15,
                    new esri.symbol.SimpleLineSymbol(
                        esri.symbol.SimpleLineSymbol.STYLE_NULL,
                        new dojo.Color([0, 0, 0, 1]),
                        1
                    ),
                    new dojo.Color([255, 69, 0, 0.65])),
                "less100": new esri.symbol.PictureMarkerSymbol({
                    "url": symbolUrl + "c1.png",
                    "contentType": "image/png",
                    "width": 25,
                    "height": 25
                }),
                "less500": new esri.symbol.PictureMarkerSymbol({
                    "url": symbolUrl + "c2.png",
                    "contentType": "image/png",
                    "width": 30,
                    "height": 30
                }),
                "less5000": new esri.symbol.PictureMarkerSymbol({
                    "url": symbolUrl + "c3.png",
                    "contentType": "image/png",
                    "width": 35,
                    "height": 35
                }),
                "less10000": new esri.symbol.PictureMarkerSymbol({
                    "url": symbolUrl + "c4.png",
                    "contentType": "image/png",
                    "width": 40,
                    "height": 40
                }),
                "over10000": new esri.symbol.PictureMarkerSymbol({
                    "url": symbolUrl + "c5.png",
                    "contentType": "image/png",
                    "width": 45,
                    "height": 45
                })
            };

            // Text label for cluster
            var textGraphics = []
            var font = new esri.symbol.Font();
            font.setSize("8pt");
            font.setFamily("DIN OT");
            font.setWeight(esri.symbol.Font.WEIGHT_BOLD);

            var symbol;
            if (wellCount < 1000 && wellCount > 0)
                symbol = symbolBank.less100;
            else if (wellCount < 10000 && wellCount >= 1000)
                symbol = symbolBank.less500;
            else if (wellCount < 50000 && wellCount >= 10000)
                symbol = symbolBank.less5000;
            else if (wellCount < 100000 && wellCount >= 50000)
                symbol = symbolBank.less10000;
            else if (wellCount >= 100000)
                symbol = symbolBank.over10000;

            // Saving attributes in graphics for clusters
            var attr;

            if (tabName == "VWH")
                attr = { "TabName": tabName, "WellFileCount": data.wellFileCount };
            else if (tabName == "WellFile")
                attr = { "TabName": tabName, "WellFileCount": data.wellFileCount, "WellJSONCount": data.wellJSONCount };
            else if (tabName == "Las")
                attr = { "TabName": tabName, "LasCount": data.lasCount, "LasCurveCount": data.lasCurveCount };
            else if (tabName == "Raster")
                attr = { "TabName": tabName, "SRCount": data.srCount, "RasterCount": data.rasterCount };
            else if (tabName == "Production")
                attr = {
                    "TabName": tabName, "ActiveWellCount": data.activeWellsCount,
                    "cum3MoOil": data.cum3MoOil, "cum3MoGas": data.cum3MoGas,
                    "cum3MoWater": data.cum3MoWater
                };
            else
                attr = { "TabName": tabName, "wellsCount": data.wellsCount };

            if (wellCount > 9999)
                wellCount = (wellCount / 1000000).toString().substring(0, 4) + "m";

            var grphs = new esri.Graphic(clusterPnt, new esri.symbol.TextSymbol(wellCount).setOffset(0, -5).setColor(new esri.Color([255, 255, 255, 1])).setFont(font), attr);
            textGraphics.push(grphs);

            var cGraphic = new $ctrl.Graphic(clusterPnt, symbol, attr);

            $ctrl.map.graphics.add(cGraphic);
            $ctrl.map.graphics.add(grphs);
        }

        // This function is called when user clicks a cluster to see more data in pop-up.
        function getGraphics(evt) {
            isCallFromBBService = false;

            if (isDrawing == true)
                return;

            if (evt.graphic == undefined) {
                $ctrl.map.infoWindow.hide();
                return;
            }

            if ($rootScope.filterNameGroup == "Seismic")
                return;

            var tabName = evt.graphic.attributes["TabName"]

            if (tabName == undefined)
                return;

            if (tabName == "VWH") {
                $ctrl.map.infoWindow.setTitle("VWH Details");
                $ctrl.map.infoWindow.setContent("<span> Well Count :</span> <br/>" + Number(evt.graphic.attributes["WellFileCount"]).toLocaleString('en'));
            }
            else if (tabName == "WellFile") {
                $ctrl.map.infoWindow.setTitle("Well File Details");
                $ctrl.map.infoWindow.setContent("<span> Well Count with PDF : </span> <br/>" + Number(evt.graphic.attributes["WellFileCount"]).toLocaleString('en') +
                    "<br><span>Well Count with OCR : </span><br/>" + Number(evt.graphic.attributes["WellJSONCount"]).toLocaleString('en'));
            }
            else if (tabName == "Las") {
                $ctrl.map.infoWindow.setTitle("LAS Details");
                $ctrl.map.infoWindow.setContent("<span> Las Count : </span> <br/>" + Number(evt.graphic.attributes["LasCount"]).toLocaleString('en') +
                    "<br><span>Las Curve Count : </span><br/>" + Number(evt.graphic.attributes["LasCurveCount"]).toLocaleString('en'));

            }
            else if (tabName == "Raster") {
                $ctrl.map.infoWindow.setTitle("Raster Details");
                $ctrl.map.infoWindow.setContent("<span> SR Count : </span><br/>" + Number(evt.graphic.attributes["SRCount"]).toLocaleString('en') +
                    "<br><span>Raster Count :</span><br/>" + Number(evt.graphic.attributes["RasterCount"]).toLocaleString('en'));
            }
            else if (tabName == "Production") {
                $ctrl.map.infoWindow.setTitle("Production Details");
                $ctrl.map.infoWindow.setContent("<span> Active Well Count : </span><br/>" + Number(evt.graphic.attributes["ActiveWellCount"]).toLocaleString('en') +
                    "<br><span>Cum 3 Month Oil : </span><br/>" + Number(parseFloat(evt.graphic.attributes["cum3MoOil"]).toFixed(3)).toLocaleString('en') + " bbls" +
                    "<br><span>Cum 3 Month Gas : </span><br/>" + Number(parseFloat(evt.graphic.attributes["cum3MoGas"]).toFixed(3)).toLocaleString('en') + " mcf" +
                    "<br><span>Cum 3 Month Water : </span><br/>" + Number(parseFloat(evt.graphic.attributes["cum3MoWater"]).toFixed(3)).toLocaleString('en') + " bbls");
            }
            else {
                $ctrl.map.infoWindow.setTitle("Formation Details");
                $ctrl.map.infoWindow.setContent("<span> Well Count : </span><br/>" + Number(evt.graphic.attributes["wellsCount"]).toLocaleString('en'));
            }

            $ctrl.map.infoWindow.show(evt.mapPoint, $ctrl.map.getInfoWindowAnchor(evt.screenPoint));
        }

        // Function to remove all home page related layers while switching to detail page
        function RemoveAllLayers(isOn) {

            var mapLayers = $ctrl.map.layerIds.length
            for (var j = mapLayers - 1; j >= 0; j--) {

                var layer = $ctrl.map.getLayer($ctrl.map.layerIds[j]);
                if (layer.id != 'layer0' && layer.id != 'layer1' && layer.id != 'projectlayer' && layer.id != 'entAreaLayers' && layer.id != 'singleproject' && layer.id != 'nonEntAreaLayers') {
                    $ctrl.map.removeLayer(layer);;
                }
            }
        }

        // Function to remove Project layers
        function RemoveProjectLayers() {

            var mapLayers = $ctrl.map.layerIds.length
            for (var j = mapLayers - 1; j >= 0; j--) {

                var layer = $ctrl.map.getLayer($ctrl.map.layerIds[j]);
                if (layer.id == 'projectlayer' || layer.id == 'entAreaLayers' || layer.id == 'singleproject' || layer.id == 'nonEntAreaLayers') {
                    $ctrl.map.removeLayer(layer);
                }
            }
        }

        // This function is getting called from well las tab while switching to wells section
        $rootScope.hideProjectLayer = function () {
            projectLayer.setVisibility(false);
            entAreaLayer.setVisibility(false);
            nonEntAreaLayer.setVisibility(false);
            singleProjectLayer.setVisibility(false);
        }


        // This function is used to clear graphics
        function RemoveGraphics() {
            var graphicCnt = $ctrl.map.graphics.graphics.length

            for (var j = graphicCnt - 1; j >= 0; j--) {

                var graphic = $ctrl.map.graphics.graphics[j];

                if (graphic.geometry.type != 'polygon') {
                    $ctrl.map.graphics.remove(graphic);
                }
            }
        }


        // Clear graphics except polygon shape
        function ClearGraphicsExceptPolygonFltr() {
            if ($ctrl.map == null || $ctrl.map.graphics == null)
                return;

            var graphicCnt = $ctrl.map.graphics.graphics.length

            for (var j = graphicCnt - 1; j >= 0; j--) {

                var graphic = $ctrl.map.graphics.graphics[j];

                if (graphic.attributes != undefined) {
                    if (graphic.attributes["Id"] != "SearchPolygon") {
                        $ctrl.map.graphics.remove(graphic);
                    }
                }
                else
                    $ctrl.map.graphics.remove(graphic);
            }
        }

        // Remove only polygon filter shape from map
        function ClearPolyGonFilterGraphics() {
            var graphicCnt = $ctrl.map.graphics.graphics.length

            for (var j = graphicCnt - 1; j >= 0; j--) {

                var graphic = $ctrl.map.graphics.graphics[j];

                if (graphic.attributes != undefined) {
                    if (graphic.attributes["Id"] == "SearchPolygon") {
                        $ctrl.map.graphics.remove(graphic);
                    }
                }
            }
        }

        // Function to add country level clustering on default map extent
        function addCountryLevelCluster(tabName, callback) {
            // console.log('country level clustering');
            var tabName;
            var moduleName;

            var vals = getTabAndModuleName();
            tabName = vals[0];
            moduleName = vals[1];

            var paramInfo = {
                tabName: tabName,
                module: moduleName,
                requestTimestamp: Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }

            paramInfo.token == "" ? delete paramInfo.token : paramInfo.token;
            paramInfo.access_token == "" ? delete paramInfo.access_token : paramInfo.access_token;

            var paramInfoList = $.param(paramInfo);  // For Serialization and  encodeURIComponent
            var request = {
                method: 'POST',
                url: Common.urlValue + Common.getMapCentroidForCountry,
                data: paramInfoList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }


            $http(request).
                then(function (response) {
                    if (idDetail == false)
                        return;
                    if ($rootScope.filterNameGroup == "Seismic") {
                        RemoveGraphics();
                        angular.element(document.body).find('.mapoverlay').remove();
                        return;
                    }
                    if (response.data !== undefined) {
                        angular.forEach(response.data, function (value) {
                            addGraphic(value, "ext", tabName);
                        });
                    }
                    setTimeout(function () {
                        angular.element(document.body).find('#overlay').remove();
                    }, 1500);
                }).catch(function (response) {
                    angular.element(document.body).find('#overlay').remove();
                });
        }

        //Launch4 changes
        // This function gets executed when user clicks on survey shapes in map
        function selectSurveysOnMap(evt) {

            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            var symbolUrl = "img/";
            ClearGraphicsExceptPolygonFltr();
            var flagSymbol = new esri.symbol.PictureMarkerSymbol({
                "url": symbolUrl + "flag.png",
                "contentType": "image/png",
                "width": 28,
                "height": 28,
                "yoffset": 12
            });

            var flagGraphic = new $ctrl.Graphic(evt.mapPoint, flagSymbol);
            flagGraphic.setAttributes({ "Id": "SurveyFlag" });

            $ctrl.map.graphics.add(flagGraphic);

            turnOffSeismicHighlightLayer();
            var surveySelectionLayer = $ctrl.map.getLayer("SeismicSelectionService_0");
            // angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');

            var circle;
            $scope.result = [];

            // creating circle shaped buffer
            if (evt != undefined) {
                circle = new $ctrl.Circle({
                    center: evt.mapPoint,
                    geodesic: true,
                    radius: 10,
                    radiusUnit: "esriMiles"
                });

                // ClearGraphicsExceptPolygonFltr();
            }

            require([
                "esri/tasks/QueryTask",
                "esri/tasks/query",
                "esri/SpatialReference",
                "dojo/promise/all"
            ], function (QueryTask, Query, SpatialReference, PromiseAll) {
                var queryTasks = [];
                var surveyUrls = [];

                surveyUrls[0] = WellService.surveyUrl + "0";
                surveyUrls[1] = WellService.surveyUrl + "1";

                for (var y = 0; y < surveyUrls.length; y++) {
                    // Query definition for project filter
                    var queryTask = new QueryTask(surveyUrls[y]);
                    var query = new Query();
                    query.where = "ShowOnMap = 1";

                    if (circle != undefined)
                        query.geometry = circle;
                    query.returnGeometry = true;
                    //query.num = 5;
                    query.outFields = ["SurveyID,SurveyName"];
                    query.outSpatialReference = new SpatialReference({ wkid: 102100 });
                    var currentTime = Common.getCurrentTime();
                    queryTasks.push(queryTask.execute(query));
                }
                PromiseAll(queryTasks).then(
                    function (response) {
                        //creating log request
                        var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.APPLY_PROJECT_FILTERS, WellService.projectShapeServiceUrl, Constants.APPLICATION_NAME, $rootScope.userName
                            , Constants.SUCCESS, projectFilter[1], null, null, null, Common.getCurrentDateTime(),
                            Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), null);

                        $http(logReq); //Logging the success request                                              
                        var srvyExtent;
                        var layerDefs = "SurveyID IN (";
                        for (var z = 0; z < response.length; z++) {
                            var result = response[z];
                            if (result.features.length > 0) {
                                if (srvyExtent == null)
                                    srvyExtent = $ctrl.graphicsUtils.graphicsExtent(result.features);
                                else
                                    srvyExtent = srvyExtent.union($ctrl.graphicsUtils.graphicsExtent(result.features));
                            }
                        }

                        if (srvyExtent == undefined || srvyExtent == null) {
                            angular.element(document.body).find('.mapoverlay').remove();
                            angular.element('.surveySummaryPanel').hide();
                            return;
                        }
                        // $ctrl.map.setExtent(srvyExtent.offset(-10, 0), true);
                        var polygonGeometry = $ctrl.Polygon.fromExtent(srvyExtent);
                        var graphic = new $ctrl.Graphic(polygonGeometry, new $ctrl.SimpleFillSymbol($ctrl.polygonSymbol));
                        // $ctrl.map.graphics.add(graphic);

                        $ctrl.map.setExtent(srvyExtent);

                        for (var z = 0; z < response.length; z++) {
                            var result = response[z];
                            if (result.features.length > 0) {
                                var surveyType = "";
                                // Populate $scope.result to show data in side panel
                                for (var j = 0; j < result.features.length; j++) {
                                    var surveyID = result.features[j].attributes["SurveyID"];


                                    if (z == 0 && j == 0)
                                        layerDefs = layerDefs + "'" + surveyID;
                                    else
                                        layerDefs = layerDefs + "','" + surveyID;

                                    if (result.features[j].geometry.type == "polyline") {
                                        surveyType = "2D";
                                    }
                                    else {
                                        surveyType = "3D";
                                    }
                                    if ($scope.result.filter(p => p.ProjectID == surveyID).length == 0)
                                        surveyType = "3D";
                                    $scope.result.push({ surveyId: result.features[j].attributes["SurveyID"], SurveyName: result.features[j].attributes["SurveyName"] });
                                }

                            }
                            else {
                                if ($scope.result.length == 0) {
                                    angular.element(document.body).find('.mapoverlay').remove();
                                    angular.element('.surveySummaryPanel').hide();
                                }
                            }
                        }
                        if ($scope.result.length > 0) {
                            var res = $scope.result;
                            $rootScope.$broadcast("event:surveyShapeClick", { res, count: 1 });
                            angular.element(document.body).find('.mapoverlay').remove();
                        }

                        var layerDefinitions = [];
                        layerDefs = layerDefs + "')";
                        layerDefinitions[0] = layerDefs;
                        layerDefinitions[1] = layerDefs;
                        angular.element(document.body).find('.mapoverlay').remove();
                    },
                    function (error) {
                        var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.APPLY_PROJECT_FILTERS, WellService.projectShapeServiceUrl, Constants.APPLICATION_NAME, $rootScope.userName, Constants.FAILED,
                            projectFilter[1], null, null, null, Common.getCurrentDateTime(),
                            Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), error.message);

                        $http(logReq); //Logging the success request
                    }
                );
            });
        };

        $rootScope.resetHighlightedSurvey = function () {
            var layer = $ctrl.map.getLayer("SeismicHighlightService_0");
            if (layer) {
                var layerDefinitions = [];
                for (var j = 0; j < layer.visibleLayers.length; j++) {
                    layerDefinitions[layer.visibleLayers[j]] = "SurveyID IN ('000000')";
                }
                layer.setLayerDefinitions(layerDefinitions);
                $scope.$applyAsync(function () {
                    layer.setVisibility(false);
                });
            }
        }

        $rootScope.highlightSurvey = function (SurveyId) {

            var surveyString = "SurveyID IN ('" + SurveyId + "')";
            var layer = $ctrl.map.getLayer("SeismicHighlightService_0");

            var labelClass = new esri.layers.LabelClass({
                labelExpression: '[' + "SURVEYNAME" + ']',
                labelPlacement: 'esriServerPolygonPlacementAlwaysHorizontal',
                verticalAlignment: "bottom",
                horizontalAlignment: "left",
                angle: 0,
                symbol: WellService.getTextSymbolJson([255, 255, 255, 217], 1, [128, 128, 128, 255], 9),
                minScale: 53957190.948944
            });

            if (layer) {
                layer.layerDrawingOptions[0].labelingInfo = [labelClass];
                layer.layerDrawingOptions[1].labelingInfo = [labelClass];
                layer.layerDrawingOptions[0].showLabels = true;
                layer.layerDrawingOptions[1].showLabels = true;

                var layerDefinitions = [];
                for (var j = 0; j < layer.visibleLayers.length; j++) {
                    layerDefinitions[layer.visibleLayers[j]] = surveyString;
                }
                layer.setLayerDefinitions(layerDefinitions);
                $scope.$applyAsync(function () {
                    layer.setVisibility(true);
                });
            }
        }

        // This function gets called from all seismic controllers for project shapes rendering
        $rootScope.applyProjectFilterByTab = function (metaDataFilters, geoSpaFilter, qbStr, uuid, surveyEntitlementUrl, surveyType, pdfFilterStr) {
            // $rootScope.isSeismic = true;
            allSurveyUIFilter = metaDataFilters + geoSpaFilter + qbStr + uuid + surveyEntitlementUrl + surveyType + pdfFilterStr;

            RemoveProjectLayers();
            addProjectLayer();

            entAreaLayer.setVisibility(false);
            nonEntAreaLayer.setVisibility(false);
            singleProjectLayer.setVisibility(false);
            $ctrl.map.infoWindow.hide();
            idDetail = true;
            ClearGraphicsExceptPolygonFltr();

            RemoveAllLayers();
            if ($rootScope.curTab !== "LAS")
                loadProjectShapesByTab(metaDataFilters, geoSpaFilter, qbStr, uuid, surveyEntitlementUrl, surveyType, pdfFilterStr);
        }

        // This function gets executed when user clicks on project shapes in map
        function applyProjectFilters(evt) {
            // Hide layers to clear screen
            entAreaLayer.setVisibility(false);
            nonEntAreaLayer.setVisibility(false);
            singleProjectLayer.setVisibility(false);
            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');

            var circle;
            $scope.result = [];

            // creating circle shaped buffer
            if (evt != undefined) {
                circle = new $ctrl.Circle({
                    center: evt.mapPoint,
                    geodesic: true,
                    radius: 10,
                    radiusUnit: "esriMiles"
                });

                ClearGraphicsExceptPolygonFltr();
            }

            require([
                "esri/tasks/QueryTask",
                "esri/tasks/query",
                "esri/SpatialReference",
                "dojo/promise/all"
            ], function (QueryTask, Query, SpatialReference, PromiseAll) {
                var queryTasks = [];
                var projectUrls = [];

                var customerID = getCustomerID();
                var projectShapeUrl = WellService.projectShapeServiceUrl + $rootScope.accessToken + "/" + customerID + "/Seismic/mapserver?token=" + $rootScope.sessionToken;

                projectUrls[0] = projectShapeUrl.replace("mapserver", "mapserver/1");
                projectUrls[1] = projectShapeUrl.replace("mapserver", "mapserver/9");

                for (var y = 0; y < projectUrls.length; y++) {
                    var layer = projectLayer;
                    // Query definition for project filter
                    var queryTask = new QueryTask(projectUrls[y]);
                    var query = new Query();
                    query.where = projectFilter[1];
                    if (circle != undefined)
                        query.geometry = circle;
                    query.returnGeometry = true;
                    //query.num = 5;
                    query.outFields = ["PROJECTID,PROJECT"];
                    query.outSpatialReference = new SpatialReference({ wkid: 102100 });
                    var currentTime = Common.getCurrentTime();
                    queryTasks.push(queryTask.execute(query));
                }
                PromiseAll(queryTasks).then(
                    function (response) {
                        //creating log request
                        var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.APPLY_PROJECT_FILTERS, WellService.projectShapeServiceUrl, Constants.APPLICATION_NAME, $rootScope.userName
                            , Constants.SUCCESS, projectFilter[1], null, null, null, Common.getCurrentDateTime(),
                            Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), null);

                        $http(logReq); //Logging the success request                                              
                        var prjExtent;
                        for (var z = 0; z < response.length; z++) {
                            var result = response[z];
                            if (result.features.length > 0) {
                                if (prjExtent == null)
                                    prjExtent = $ctrl.graphicsUtils.graphicsExtent(result.features);
                                else
                                    prjExtent = prjExtent.union($ctrl.graphicsUtils.graphicsExtent(result.features));
                            }
                        }

                        if (prjExtent == undefined || prjExtent == null) {
                            angular.element(document.body).find('.mapoverlay').remove();
                            angular.element('.mapSidepanel').hide();
                            $ctrl.resetProjectLayer();
                            projectLayer.hide();
                            projectLayer.show();
                            return;
                        }

                        // when user is not clicking the map, just changing the tab
                        if (circle == undefined) {
                            angular.element(document.body).find('.mapoverlay').remove();
                            $ctrl.map.setExtent(prjExtent.offset(-10, 0), true);
                            return;
                        }
                        else
                            $ctrl.resetProjectLayer();

                        for (var z = 0; z < response.length; z++) {
                            var result = response[z];
                            var layer = projectLayer;
                            if (result.features.length > 0) {
                                var projectType = "";
                                // Populate $scope.result to show data in side panel
                                for (var j = 0; j < result.features.length; j++) {
                                    var projID = result.features[j].attributes["ProjectID"];
                                    if (result.features[j].geometry.type == "polyline") {
                                        projectLayer.layerDrawingOptions[1].renderer.infos.filter(p => p.value == projID)[0].symbol.setWidth(1);
                                        projectType = "2D";
                                        //projectLayer.layerDrawingOptions[1].renderer.infos.filter(p => p.value == projID)[0].symbol.setColor(new $ctrl.Color([249, 160, 27]));
                                    }
                                    else {
                                        projectLayer.layerDrawingOptions[9].renderer.infos.filter(p => p.value == projID)[0].symbol.setOutline(selectedPrjSymbol);
                                        projectType = "3D";
                                    }
                                    if ($scope.result.filter(p => p.ProjectID == projID).length == 0)
                                        $scope.result.push({ ProjectID: result.features[j].attributes["ProjectID"], ProjectName: result.features[j].attributes["Project"], ProjectType: projectType });
                                }
                                projectLayer.hide();
                                projectLayer.show();
                                $ctrl.map.setExtent(prjExtent.offset(-10, 0), true);
                                var result = $scope.result;
                                angular.element(document.body).find('.mapoverlay').remove();
                                $rootScope.$broadcast("event:projectShapeClick", { result, count: 1 });

                            }
                            else {
                                if ($scope.result.length == 0) {
                                    angular.element(document.body).find('.mapoverlay').remove();
                                    angular.element('.mapSidepanel').hide();
                                }
                            }
                        }
                    },
                    function (error) {
                        var logReq = Common.createUILog(Constants.MAP_CTRL, Constants.APPLY_PROJECT_FILTERS, WellService.projectShapeServiceUrl, Constants.APPLICATION_NAME, $rootScope.userName, Constants.FAILED,
                            projectFilter[1], null, null, null, Common.getCurrentDateTime(),
                            Common.getTimeDifferenceInSeconds(currentTime, Common.getCurrentTime()), error.message);

                        $http(logReq); //Logging the success request
                    }
                );
            });
        };

        // Reset project shapes borders on clicking elsewhere 
        $ctrl.resetProjectLayer = function () {
            for (var j = 0; j < projectLayer.layerDrawingOptions[9].renderer.infos.length; j++) {

                projectLayer.layerDrawingOptions[9].renderer.infos[j].symbol.setOutline(new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                    new $ctrl.Color([104, 0, 84]), 1));
            }

            for (var j = 0; j < projectLayer.layerDrawingOptions[1].renderer.infos.length; j++) {

                projectLayer.layerDrawingOptions[1].renderer.infos[j].symbol.setWidth(1); //Color(new $ctrl.Color([104, 0, 84]), 1);
            }
        }

        // Function to load project shapes when user changes the tabs
        function loadProjectShapesByTab(metaDataFilter, geoSpaFilter, qbStr, uuid, surveyEntitlementUrl, surveyType, pdfFilterStr, callback) {

            singleProjectLayer.setVisibility(false);
            var tabName = $rootScope.curTab;
            if (tabName == 'Spec Sheets')
                tabName = "SpecSheet";

            if (tabName == "LAS") {
                var moduleName = "Well";
            }
            else {
                var moduleName = "Seismic";
            }

            angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');
            var projectsUrl = "getMapDetailInfo";
            var filterStringInfo = "";
            if (metaDataFilter !== "" && geoSpaFilter == "")
                filterStringInfo = metaDataFilter
            else if (metaDataFilter == "" && geoSpaFilter !== "") {
                filterStringInfo = geoSpaFilter;
            }
            else if (geoSpaFilter !== "" && metaDataFilter !== "")
                filterStringInfo = metaDataFilter + geoSpaFilter;

            var projectShapeParams = {
                tabName: tabName,
                module: moduleName,
                filterStr: filterStringInfo,
                queryBuilderStr: qbStr,
                uuid: uuid,
                customerId: surveyEntitlementUrl,
                surveyType: surveyType,
                pdfFilterStr: pdfFilterStr,
                requestTimestamp: Common.getCurrentDateTime(),
                token: $rootScope.sessionToken,
                access_token: $rootScope.accessToken
            }

            projectShapeParams.filterStr == "" || projectShapeParams.filterStr == undefined ? delete projectShapeParams.filterStr : projectShapeParams.filterStr;
            projectShapeParams.queryBuilderStr == "" || projectShapeParams.queryBuilderStr == undefined ? delete projectShapeParams.queryBuilderStr : projectShapeParams.queryBuilderStr;
            projectShapeParams.uuid == "" || projectShapeParams.uuid == undefined ? delete projectShapeParams.uuid : projectShapeParams.uuid;
            projectShapeParams.customerId == "" || projectShapeParams.customerId == undefined ? delete projectShapeParams.customerId : projectShapeParams.customerId;
            projectShapeParams.surveyType == "" || projectShapeParams.surveyType == undefined ? delete projectShapeParams.surveyType : projectShapeParams.surveyType;
            projectShapeParams.pdfFilterStr == "" || projectShapeParams.pdfFilterStr == undefined || projectShapeParams.pdfFilterStr == undefined ? delete projectShapeParams.pdfFilterStr : projectShapeParams.pdfFilterStr;
            projectShapeParams.token == "" ? delete projectShapeParams.token : projectShapeParams.token;
            projectShapeParams.access_token == "" ? delete projectShapeParams.access_token : projectShapeParams.access_token;

            var projectShapeParamsList = $.param(projectShapeParams);  // For Serialization and  encodeURIComponent
            var projectShapeRequest = {
                method: 'POST',
                url: Common.urlValue + projectsUrl,
                data: projectShapeParamsList,
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            }

            $http(projectShapeRequest).
                then(function (response) {

                    var projectIDs = "";
                    var i = 0;

                    //create renderer
                    var defaultSymbol = new $ctrl.SimpleFillSymbol().setStyle(esri.symbol.SimpleFillSymbol.STYLE_NULL);
                    defaultSymbol.outline.setStyle(esri.symbol.SimpleLineSymbol.STYLE_NULL);
                    var lineRenderer = new $ctrl.UniqueValueRenderer(defaultSymbol, "PROJECTID");
                    var polygonRenderer = new $ctrl.UniqueValueRenderer(defaultSymbol, "PROJECTID");

                    if (response.data.content !== undefined) {
                        angular.forEach(response.data.content, function (value) {
                            if (i == 0)
                                projectIDs = value.projectID;
                            else
                                projectIDs = projectIDs + ',' + value.projectID;
                            i++;


                            // Create project shape symbols based on number of traces
                            var projSymbol = new $ctrl.SimpleFillSymbol().setStyle(esri.symbol.SimpleFillSymbol.STYLE_SOLID);
                            projSymbol.setOutline(new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                                new $ctrl.Color([104, 0, 84]), 1));

                            var projLineSymbol = new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                                new $ctrl.Color([104, 0, 84]), 1);

                            if (value.projectType == "3D") {
                                // if (value.projectName.search(" 3D") > -1) {
                                if (value.numOfDocs < 5000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([255, 153, 235, 0.7])));
                                else if (value.numOfDocs < 50000 && value.numOfDocs >= 5000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([244, 148, 211, 0.7])));
                                else if (value.numOfDocs < 100000 && value.numOfDocs >= 50000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([234, 100, 189, 0.7])));
                                else if (value.numOfDocs < 300000 && value.numOfDocs >= 100000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([221, 34, 158, 0.7])));
                                else if (value.numOfDocs < 500000 && value.numOfDocs >= 300000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([193, 33, 139, 0.7])));
                                else if (value.numOfDocs < 800000 && value.numOfDocs >= 500000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([170, 0, 113, 0.7])));
                                else if (value.numOfDocs < 1000000 && value.numOfDocs >= 800000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([131, 17, 93, 0.7])));
                                else if (value.numOfDocs > 1000000)
                                    polygonRenderer.addValue(value.projectID, projSymbol.setColor(new $ctrl.Color([104, 0, 84, 0.7])));
                            }
                            else {
                                if (value.numOfDocs < 5000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([255, 153, 235, 0.7])));
                                else if (value.numOfDocs < 50000 && value.numOfDocs >= 5000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([244, 148, 211, 0.7])));
                                else if (value.numOfDocs < 100000 && value.numOfDocs >= 50000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([234, 100, 189, 0.7])));
                                else if (value.numOfDocs < 300000 && value.numOfDocs >= 100000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([221, 34, 158, 0.7])));
                                else if (value.numOfDocs < 500000 && value.numOfDocs >= 300000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([193, 33, 139, 0.7])));
                                else if (value.numOfDocs < 800000 && value.numOfDocs >= 500000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([170, 0, 113, 0.7])));
                                else if (value.numOfDocs < 1000000 && value.numOfDocs >= 800000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([131, 17, 93, 0.7])));
                                else if (value.numOfDocs > 1000000)
                                    lineRenderer.addValue(value.projectID, projLineSymbol.setColor(new $ctrl.Color([104, 0, 84, 0.7])));
                            }
                        });
                    }

                    var layerDefs = [];
                    if (projectIDs == "")
                        projectIDs = "0";
                    layerDefs[1] = "PROJECTID IN (" + projectIDs + ")";
                    layerDefs[9] = "PROJECTID IN (" + projectIDs + ")";
                    projectFilter = layerDefs;
                    projectLayer.setLayerDefinitions(layerDefs);

                    var layerDrawingOptionLine = new $ctrl.LayerDrawingOptions();
                    layerDrawingOptionLine.renderer = lineRenderer;

                    var layerDrawingOptionPolygon = new $ctrl.LayerDrawingOptions();
                    layerDrawingOptionPolygon.renderer = polygonRenderer;

                    var optionsArray = [];
                    optionsArray[1] = layerDrawingOptionLine;
                    optionsArray[9] = layerDrawingOptionPolygon;

                    projectLayer.setLayerDrawingOptions(optionsArray);

                    if ($rootScope.filterNameGroup != "Seismic") {
                        angular.element(document.body).find('.mapoverlay').remove();
                        return;
                    }

                    projectLayer.setVisibility(true);

                    // Use below function to zoom to the filterd projects                   
                    applyProjectFilters();

                    setTimeout(function () {
                        angular.element(document.body).find('.mapoverlay').remove();
                    }, 1500);
                }).catch(function (response) {
                    angular.element(document.body).find('.mapoverlay').remove();
                    Common.redirectToCore(response);
                });
        }

        // Hide entitlement area layer
        $rootScope.hideEntArea = function () {
            entAreaLayer.setVisibility(false);
        }

        // Hide Non-entitlement area layer
        $rootScope.hideNonEntArea = function () {
            nonEntAreaLayer.setVisibility(false);
        }

        // Show entitlement area on map
        $rootScope.highlightEntArea = function (ProjectID, CustomerID, ProjectType) {

            //angular.element(document).find('#viewDiv').append('<div class="mapoverlay"><div class="spinner"></div></div>');

            var strFilter = "ProjectID='" + ProjectID + "' and ParentFirmID='" + CustomerID + "'";
            var layerDefAry = [];
            if (ProjectType == "2D")
                layerDefAry[0] = strFilter;
            else
                layerDefAry[8] = strFilter;

            entAreaLayer.setLayerDefinitions(layerDefAry);

            if (ProjectType == "2D")
                entAreaLayer.setVisibleLayers([0]);
            else
                entAreaLayer.setVisibleLayers([8]);

            $scope.$applyAsync(function () {
                entAreaLayer.setVisibility(true);
            });
        }

        // Show non-entitlement area on map
        $rootScope.highlightNonEntArea = function (ProjectID) {

            // non ENT layer
            var strFilter = "ProjectID='" + ProjectID + "'";
            var layerDefAry = [];
            layerDefAry[1] = strFilter;
            layerDefAry[9] = strFilter;


            nonEntAreaLayer.setLayerDefinitions(layerDefAry);

            nonEntAreaLayer.setVisibleLayers([1, 9]);

            $scope.$applyAsync(function () {
                nonEntAreaLayer.setVisibility(true);
            });
            setTimeout(function () {
                // angular.element(document.body).find('.mapoverlay').remove();
            }, 1000);

        }

        // Highlight single project on clicking in side panel
        $rootScope.highlightSingleProject = function (ProjectID) {
            entAreaLayer.setVisibility(false);
            nonEntAreaLayer.setVisibility(false);
            var strFilter = "ProjectID='" + ProjectID + "'";

            var layerDefAry = [];
            layerDefAry[1] = strFilter;
            layerDefAry[9] = strFilter;
            singleProjectLayer.setLayerDefinitions(layerDefAry);

            singleProjectLayer.setVisibility(true);
        }

        // Add Project shape layer to map
        function addProjectLayer() {
            var customerID = getCustomerID();
            var projectShapeUrl = WellService.projectShapeServiceUrl + $rootScope.accessToken + "/" + customerID + "/Seismic/mapserver?token=" + $rootScope.sessionToken;

            // var projectLayerURL = WellService.projectShapeServiceUrl;
            var projectLayerURL = projectShapeUrl;
            var projectLayerOptions = {
                "id": "projectlayer",
                "opacity": 1,
                "showAttribution": false
            };

            projectLayer = new $ctrl.MapImageLayer(projectLayerURL, projectLayerOptions);


            projectLayer.setImageFormat("png32");
            projectLayer.setVisibleLayers([1, 9]);
            projectLayer.setVisibility(false);
            $ctrl.map.addLayer(projectLayer);
            addSingleProjectLayer();
            addNonEntAreaLayer();
            addEntAreaLayer();
        }

        // Add Single Project shape layer to map
        function addSingleProjectLayer() {
            var customerID = getCustomerID();
            var projectShapeUrl = WellService.projectShapeServiceUrl + $rootScope.accessToken + "/" + customerID + "/Seismic/mapserver?token=" + $rootScope.sessionToken;
            // var singleProjectLayerURL = WellService.projectShapeServiceUrl;
            var singleProjectLayerURL = projectShapeUrl;
            var singleProjectLayerOptions = {
                "id": "singleproject",
                "opacity": 1,
                "showAttribution": false
            };

            singleProjectLayer = new $ctrl.MapImageLayer(singleProjectLayerURL, singleProjectLayerOptions);

            // Symbol for lines
            $ctrl.spLineSymbol =
                new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                    new $ctrl.Color([23, 171, 171]), 1);

            var layerDrawingOptionLine = new $ctrl.LayerDrawingOptions();
            layerDrawingOptionLine.renderer = new $ctrl.SimpleRenderer($ctrl.spLineSymbol);

            // Symbol for polygons
            var layerDrawingOptionPolygon = new $ctrl.LayerDrawingOptions();
            layerDrawingOptionPolygon.renderer = new $ctrl.SimpleRenderer(singleProjectSymbol);

            var optionsArray = [];
            optionsArray[1] = layerDrawingOptionLine;
            optionsArray[9] = layerDrawingOptionPolygon;

            singleProjectLayer.setLayerDrawingOptions(optionsArray);

            singleProjectLayer.setImageFormat("png32");
            singleProjectLayer.setVisibleLayers([1, 9]);
            singleProjectLayer.setVisibility(false);
            $ctrl.map.addLayer(singleProjectLayer);
        }

        // Add entitlement area shape layer to map
        function addEntAreaLayer() {
            var customerID = getCustomerID();
            var projectShapeUrl = WellService.projectShapeServiceUrl + $rootScope.accessToken + "/" + customerID + "/Seismic/mapserver?token=" + $rootScope.sessionToken;
            // var entAreaUrl = WellService.projectShapeServiceUrl;
            var entAreaUrl = projectShapeUrl;

            var entProjectLayerOptions = {
                "id": "entAreaLayers",
                "opacity": 1,
                "showAttribution": false
            };

            entAreaLayer = new $ctrl.MapImageLayer(entAreaUrl, entProjectLayerOptions);

            // Symbol for lines

            $ctrl.entLineSymbol =
                new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                    new $ctrl.Color([230, 0, 0]), 1);

            var layerDrawingOptionLine = new $ctrl.LayerDrawingOptions();
            layerDrawingOptionLine.renderer = new $ctrl.SimpleRenderer($ctrl.entLineSymbol);

            // Symbol for polygons

            $ctrl.entAreaSymbol = new $ctrl.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
                new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_NULL,
                    new $ctrl.Color([255, 0, 0]), 1), new $ctrl.Color([255, 0, 0, 1])
            );

            var layerDrawingOptionPolygon = new $ctrl.LayerDrawingOptions();
            layerDrawingOptionPolygon.renderer = new $ctrl.SimpleRenderer($ctrl.entAreaSymbol);

            var optionsArray = [];
            optionsArray[0] = layerDrawingOptionLine;
            optionsArray[8] = layerDrawingOptionPolygon;

            entAreaLayer.setLayerDrawingOptions(optionsArray);

            var layerDefAry = [];
            layerDefAry[0] = "ProjectID='1123' and ParentName='Oxy Inc. (Parent)'";
            layerDefAry[8] = "ProjectID='1123' and ParentName='Oxy Inc. (Parent)'";

            entAreaLayer.setImageFormat("png32");
            entAreaLayer.setLayerDefinitions(layerDefAry);
            entAreaLayer.setVisibility(false);
            $ctrl.map.addLayer(entAreaLayer);
        }

        // Add non-entitlement area shape layer to map
        function addNonEntAreaLayer() {
            var customerID = getCustomerID();
            var projectShapeUrl = WellService.projectShapeServiceUrl + $rootScope.accessToken + "/" + customerID + "/Seismic/mapserver?token=" + $rootScope.sessionToken;
            // var nonEntAreaUrl = WellService.projectShapeServiceUrl;
            var nonEntAreaUrl = projectShapeUrl;
            var nonEntProjectLayerOptions = {
                "id": "nonEntAreaLayers",
                "opacity": 1,
                "showAttribution": false
            };

            nonEntAreaLayer = new $ctrl.MapImageLayer(nonEntAreaUrl, nonEntProjectLayerOptions);

            // Line symbol           

            $ctrl.nonEntLineSymbol =
                new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                    new $ctrl.Color([102, 102, 102, 255]), 1);

            var layerDrawingOptionLine = new $ctrl.LayerDrawingOptions();
            layerDrawingOptionLine.renderer = new $ctrl.SimpleRenderer($ctrl.nonEntLineSymbol);

            // Polygon symbol

            $ctrl.nonEntAreaSymbol = new $ctrl.SimpleFillSymbol(esri.symbol.SimpleFillSymbol.STYLE_SOLID,
                new esri.symbol.SimpleLineSymbol(esri.symbol.SimpleLineSymbol.STYLE_SOLID,
                    new $ctrl.Color([20, 55, 105, 255]), 1), new $ctrl.Color([177, 203, 227, 1])
            );

            var layerDrawingOptionPolygon = new $ctrl.LayerDrawingOptions();
            layerDrawingOptionPolygon.renderer = new $ctrl.SimpleRenderer($ctrl.nonEntAreaSymbol);

            var optionsArray = [];
            optionsArray[1] = layerDrawingOptionLine;
            optionsArray[9] = layerDrawingOptionPolygon;

            nonEntAreaLayer.setLayerDrawingOptions(optionsArray);

            var whereClause = "ProjectID='1123'"
            var layerDefAry = [];
            layerDefAry[1] = whereClause;
            layerDefAry[9] = whereClause;

            nonEntAreaLayer.setImageFormat("png32");
            nonEntAreaLayer.setLayerDefinitions(layerDefAry);
            nonEntAreaLayer.setVisibility(false);
            $ctrl.map.addLayer(nonEntAreaLayer);
        }

        //Get customer id
        function getCustomerID() {
            var customerID = Common.getSurveyEntUserForMap();
            if (customerID == "" && $rootScope.projShapeEntitlementUrl) {
                customerID = $rootScope.projShapeEntitlementUrl;
            }
            if (customerID == "" || customerID == undefined)
                customerID = "null";
            return customerID;
        }

        // Switching from details page to home page
        $rootScope.refreshWells = function () {
            $ctrl.map.infoWindow.hide();
            ClearGraphicsExceptPolygonFltr();
            RemoveProjectLayers();
            addLayersToMap();
            idDetail = false;
            // $rootScope.isSeismic = false;
            if (allSurveyUIFilter == "" && allWellUIFilter == "")
                $ctrl.map.setExtent(initialExtent);

        }
    }

    mapViewController.$inject = [
        '$q',
        '$scope',
        '$rootScope',
        'WellService',
        'SurveyService',
        '$http',
        'Common',
        'Constants'
    ];
})(angular.module("TGSApp"));
